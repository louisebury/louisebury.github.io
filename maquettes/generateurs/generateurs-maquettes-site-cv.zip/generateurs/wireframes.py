"""Animation des wireframes Connect (avant / après) : une page HTML autonome.
SVG 1280 x 800 + petite frise temporelle en JavaScript (sans librairie), rejouable et « seekable »."""
import json, sys
from html import escape

# ---------------------------------------------------------------- couleurs (charte Upply simplifiée) + site
CORAL = "#F25C54"; CORAL_L = "#FDE8E6"; DARKT = "#2B2D33"; MUTED = "#8A8F98"; LINE = "#E3E5EA"
BGAPP = "#F4F5F7"; WHITE = "#FFFFFF"; GREEN = "#2E9E5B"; GREEN_L = "#E3F7EA"; BLUE = "#2F80ED"; BLUE_L = "#E6F0FD"
OLDHEAD = "#2B2B2B"; GREY_L = "#EEEFF2"
NBG = "#0B0B12"; NINK = "#F5F3FF"; NPINK = "#FF4FA0"; NSOL = "#FFC46B"; NLAV = "#C084FC"
FONT = "Nunito, Inter, Arial, sans-serif"

SW, SH = 1280, 800
WX, WY, WW, WH = 40, 88, 1200, 692      # fenêtre de navigateur
HY = WY + 34                            # haut de l'en-tête de l'appli
BY = HY + 56                            # haut du contenu de l'appli
POS = {}                                # positions utiles pour le curseur


# ---------------------------------------------------------------- primitives
def T(x, y, s, size=13, fill=DARKT, w=400, anchor="start", id=None, op=1, ls=0, italic=False):
    i = f' id="{id}"' if id else ""
    it = ' font-style="italic"' if italic else ""
    return (f'<text{i} x="{x}" y="{y}" font-family="{FONT}" font-size="{size}" font-weight="{w}" fill="{fill}" '
            f'fill-opacity="{op}" text-anchor="{anchor}" letter-spacing="{ls}"{it}>{escape(str(s))}</text>')


def R(x, y, w, h, fill=WHITE, stroke=None, rx=6, sw=1, id=None, extra=""):
    i = f' id="{id}"' if id else ""
    st = f' stroke="{stroke}" stroke-width="{sw}"' if stroke else ""
    return f'<rect{i} x="{x}" y="{y}" width="{w}" height="{h}" rx="{rx}" fill="{fill}"{st} {extra}/>'


def G(inner, id=None, hidden=False, extra=""):
    i = f' id="{id}"' if id else ""
    h = ' style="display:none"' if hidden else ""
    return f'<g{i}{h} {extra}>{inner}</g>'


def button(x, y, w, label, kind="plein", id=None, h=36, size=13):
    if kind == "plein":
        s = R(x, y, w, h, CORAL, rx=h / 2) + T(x + w / 2, y + h / 2 + 4.5, label, size, WHITE, 800, "middle")
    else:
        s = R(x, y, w, h, WHITE, CORAL, rx=h / 2, sw=1.4) + T(x + w / 2, y + h / 2 + 4.5, label, size, CORAL, 800, "middle")
    if id:
        POS[id] = (x + w / 2, y + h / 2)
    return G(s, id=id)


def inp(x, y, w, label, id, ph="", val="", h=36):
    """Champ de formulaire : libellé au-dessus, valeur (id) et texte d'aide (id-ph)."""
    s = T(x, y, label, 12, MUTED, 700)
    s += R(x, y + 8, w, h, WHITE, LINE, rx=6, id=f"{id}-box")
    s += T(x + 12, y + 8 + h / 2 + 4.5, ph, 13, "#B5B9C1", id=f"{id}-ph")
    s += T(x + 12, y + 8 + h / 2 + 4.5, val, 13.5, DARKT, 700, id=id)
    POS[id] = (x + min(w - 20, 60), y + 8 + h / 2)
    return s


def chip(x, y, label, id=None, on=False, h=30, size=12.5):
    w = int(len(label) * size * 0.58) + 26
    s = R(x, y, w, h, CORAL_L if on else WHITE, CORAL if on else LINE, rx=h / 2, sw=1.3, id=f"{id}-bg" if id else None)
    s += T(x + w / 2, y + h / 2 + 4.3, label, size, CORAL if on else DARKT, 700, "middle", id=f"{id}-t" if id else None)
    if id:
        POS[id] = (x + w / 2, y + h / 2)
    return s, w


# ---------------------------------------------------------------- icônes
def pin(x, y, c=CORAL):
    return f'<path d="M{x} {y+7} C{x-6} {y} {x-5} {y-7} {x} {y-7} C{x+5} {y-7} {x+6} {y} {x} {y+7} Z" fill="none" stroke="{c}" stroke-width="1.5"/><circle cx="{x}" cy="{y-2}" r="1.8" fill="{c}"/>'


def flag(x, y, c=CORAL):
    return f'<path d="M{x-4} {y+7} V{y-7} H{x+5} L{x+3} {y-3} L{x+5} {y+1} H{x-4}" fill="none" stroke="{c}" stroke-width="1.5" stroke-linejoin="round"/>'


def truck(x, y, c="#9AA0A9"):
    return (f'<g fill="none" stroke="{c}" stroke-width="1.6" stroke-linejoin="round">'
            f'<rect x="{x}" y="{y}" width="30" height="16" rx="2"/><path d="M{x+30} {y+5} H{x+38} L{x+43} {y+11} V{y+16} H{x+30}"/>'
            f'<circle cx="{x+8}" cy="{y+19}" r="3" fill="{WHITE}"/><circle cx="{x+36}" cy="{y+19}" r="3" fill="{WHITE}"/></g>')


def dup_icon(x, y, c=MUTED):
    return f'<g fill="none" stroke="{c}" stroke-width="1.5"><rect x="{x}" y="{y+4}" width="11" height="12" rx="2"/><rect x="{x+5}" y="{y}" width="11" height="12" rx="2" fill="{WHITE}"/></g>'


def palettes_icon(x, y):
    return (f'<g fill="none" stroke="{DARKT}" stroke-width="1.2"><rect x="{x}" y="{y}" width="9" height="8"/><rect x="{x+10}" y="{y}" width="9" height="8"/>'
            f'<rect x="{x+5}" y="{y-9}" width="9" height="8"/><path d="M{x-2} {y+11} H{x+21} M{x+1} {y+11} v4 M{x+9} {y+11} v4 M{x+18} {y+11} v4"/></g>')


# ---------------------------------------------------------------- composant « lot » (le même partout)
def lot_card(x, y, w, d, right=None, id=None, hl=False):
    """d = dict(av, co, frm, to, km, d1, d2, pal, poids, veh). right = None | ('chargeur', offres) | ('recherche',) | ('offre', prix, statut)."""
    s = R(x, y, w, 78, WHITE, CORAL if hl else LINE, rx=10, sw=1.6 if hl else 1, id=f"{id}-cadre" if id else None)
    if hl:
        s += R(x + 14, y - 9, 62, 18, CORAL, rx=9) + T(x + 45, y + 4, "Nouveau", 10.5, WHITE, 800, "middle")
    cy = y + 39
    s += f'<circle cx="{x+30}" cy="{cy}" r="15" fill="{BLUE}"/>' + T(x + 30, cy + 4.5, d["av"], 11, WHITE, 800, "middle")
    s += T(x + 54, cy - 6, d["co"], 12.5, DARKT, 800)
    s += R(x + 54, cy + 2, 62, 18, GREY_L, rx=9) + T(x + 85, cy + 15, d.get("role", "Chargeur"), 10, MUTED, 700, "middle")
    cx = x + 210
    s += T(cx, cy - 6, d["d1"], 12.5, DARKT, 700) + T(cx, cy + 14, d["d2"], 12.5, DARKT, 700)
    rx_ = x + 300
    s += pin(rx_, cy - 11) + T(rx_ + 12, cy - 6, d["frm"], 12.5, DARKT, 800)
    s += f'<line x1="{rx_}" y1="{cy-2}" x2="{rx_}" y2="{cy+5}" stroke="{LINE}" stroke-width="1.5"/>' + T(rx_ + 12, cy + 3.5, d["km"], 9.5, MUTED)
    s += flag(rx_, cy + 13) + T(rx_ + 12, cy + 18, d["to"], 12.5, DARKT, 800)
    if w > 600:
        px = x + 470
        s += T(px, cy - 6, d["pal"], 12.5, DARKT, 800) + T(px + 20, cy - 6, "palettes 80x120", 11, MUTED)
        s += T(px, cy + 14, d["poids"], 12.5, DARKT, 800) + T(px + 26, cy + 14, "tonne(s)", 11, MUTED)
        vx = x + 620
        s += truck(vx, cy - 14) + T(vx + 22, cy + 22, d["veh"], 10.5, MUTED, 600, "middle")
    if right and right[0] == "chargeur":
        n = right[1]
        bx = x + w - 262
        lab = f"{n} offre" + ("s" if n > 1 else "")
        s += R(bx, cy - 13, 74, 26, GREEN_L if n else GREY_L, rx=13, id=f"{id}-bulle")
        s += T(bx + 37, cy + 4.5, lab, 11.5, GREEN if n else MUTED, 800, "middle", id=f"{id}-bulle-t")
        s += f'<g id="{id}-dup">{dup_icon(x + w - 170, cy - 8)}</g>'
        POS[f"{id}-dup"] = (x + w - 162, cy)
        s += button(x + w - 140, cy - 16, 120, "Voir le détail", "contour", id=f"{id}-voir", h=32, size=12)
    elif right and right[0] == "recherche":
        s += button(x + w - 150, cy - 17, 132, "Faire une offre", "plein", id=f"{id}-offre", h=34, size=12.5)
    elif right and right[0] == "offre":
        prix, statut = right[1], right[2]
        col, bg = {"Envoyée": (BLUE, BLUE_L), "Acceptée": (GREEN, GREEN_L), "Refusée": (MUTED, GREY_L)}[statut]
        s += T(x + w - 250, cy - 4, prix, 14, DARKT, 800) + T(x + w - 250, cy + 13, "HT, proposé", 10.5, MUTED)
        s += R(x + w - 130, cy - 13, 84, 26, bg, rx=13) + T(x + w - 88, cy + 4.5, statut, 11.5, col, 800, "middle")
        s += f'<path d="M{x+w-30} {cy-6} l6 6 l-6 6" fill="none" stroke="{MUTED}" stroke-width="1.8" stroke-linecap="round"/>'
        POS[f"{id}-ligne"] = (x + w - 300, cy)
    return G(s, id=id)


LOTS_CHARGEUR = [
    dict(av="PD", co="Provence Distrib.", frm="FR13 Miramas", to="FR91 Crosne", km="744 km", d1="03/11", d2="10/11", pal="33", poids="1", veh="Semi-remorque"),
    dict(av="PD", co="Provence Distrib.", frm="FR69 Bron", to="FR59 Lille", km="690 km", d1="05/11", d2="06/11", pal="13", poids="15", veh="Semi-remorque"),
    dict(av="PD", co="Provence Distrib.", frm="FR80 Amiens", to="FR33 Libourne", km="720 km", d1="06/11", d2="08/11", pal="33", poids="18", veh="Semi-remorque"),
    dict(av="PD", co="Provence Distrib.", frm="FR13 Miramas", to="FR83 Draguignan", km="160 km", d1="07/11", d2="07/11", pal="25", poids="11,5", veh="Porteur"),
]
LOTS_TOUS = [
    dict(av="LF", co="Lyon Fret", frm="FR69 Bron", to="FR59 Lille", km="690 km", d1="05/11", d2="06/11", pal="13", poids="15", veh="Semi-remorque"),
    dict(av="NE", co="Nord Est Log.", frm="FR75 Paris", to="FR54 Nancy", km="380 km", d1="04/11", d2="05/11", pal="20", poids="8", veh="Porteur"),
    dict(av="AR", co="Ardennes Bois", frm="FR08 Sedan", to="FR51 Reims", km="110 km", d1="06/11", d2="06/11", pal="12", poids="6", veh="Porteur"),
    dict(av="SO", co="Sud Ouest Agri", frm="FR33 Bordeaux", to="FR31 Toulouse", km="245 km", d1="08/11", d2="09/11", pal="30", poids="17", veh="Semi-remorque"),
    dict(av="BR", co="Breizh Food", frm="FR35 Rennes", to="FR44 Nantes", km="110 km", d1="09/11", d2="09/11", pal="18", poids="9", veh="Porteur"),
]
LOTS_FR13 = [
    dict(av="PD", co="Provence Distrib.", frm="FR13 Miramas", to="FR91 Crosne", km="744 km", d1="03/11", d2="10/11", pal="33", poids="1", veh="Semi-remorque"),
    dict(av="MM", co="Marseille Méd.", frm="FR13 Marseille", to="FR69 Lyon", km="315 km", d1="04/11", d2="05/11", pal="26", poids="12", veh="Semi-remorque"),
    dict(av="PD", co="Provence Distrib.", frm="FR13 Miramas", to="FR83 Draguignan", km="160 km", d1="07/11", d2="07/11", pal="25", poids="11,5", veh="Porteur"),
]


# ---------------------------------------------------------------- cadres communs
def fenetre():
    s = R(WX, WY, WW, WH, BGAPP, None, rx=14)
    s += f'<path d="M{WX} {WY+14} a14 14 0 0 1 14 -14 H{WX+WW-14} a14 14 0 0 1 14 14 V{HY} H{WX} Z" fill="#E4E6EB"/>'
    s += "".join(f'<circle cx="{WX+20+i*16}" cy="{WY+17}" r="5" fill="{c}"/>' for i, c in enumerate(["#FF6159", "#FFBD2E", "#28C941"]))
    s += R(WX + 400, WY + 8, 400, 18, WHITE, rx=9)
    return s


def entete_ancien():
    s = R(WX, HY, WW, 56, OLDHEAD, rx=0)
    s += T(WX + 28, HY + 36, "upply", 24, CORAL, 800)
    s += T(WX + 360, HY + 34, "Expédier", 13, WHITE, 700)
    s += R(WX + 450, HY + 25, 110, 7, "#666", rx=3.5) + R(WX + 590, HY + 25, 110, 7, "#666", rx=3.5)
    s += f'<path d="M{WX+WW-330} {HY+56} L{WX+WW-300} {HY} H{WX+WW} V{HY+56} Z" fill="{CORAL}"/>'
    s += R(WX + WW - 230, HY + 25, 110, 7, WHITE, rx=3.5)
    s += f'<path d="M{WX+WW-60} {HY+22} q0 -6 6 -6 q6 0 6 6 v8 l3 3 h-18 l3 -3 z" fill="none" stroke="{WHITE}" stroke-width="1.6"/>'
    return s


def entete_connect(onglets, actif):
    s = R(WX, HY, WW, 56, WHITE, rx=0) + f'<line x1="{WX}" y1="{HY+56}" x2="{WX+WW}" y2="{HY+56}" stroke="{LINE}"/>'
    s += T(WX + 28, HY + 36, "upply", 24, CORAL, 800)
    s += f'<line x1="{WX+104}" y1="{HY+18}" x2="{WX+104}" y2="{HY+38}" stroke="{LINE}" stroke-width="1.5"/>' + T(WX + 116, HY + 34, "Connect", 15, DARKT, 800)
    x = WX + 240
    for o in onglets:
        on = o == actif
        s += T(x, HY + 34, o, 13.5, CORAL if on else DARKT, 800 if on else 600)
        if on:
            s += R(x, HY + 52, len(o) * 7.6, 4, CORAL, rx=2)
        POS["onglet-" + o] = (x + len(o) * 3.8, HY + 30)
        x += len(o) * 7.6 + 40
    s += f'<path d="M{WX+WW-96} {HY+22} q0 -6 6 -6 q6 0 6 6 v8 l3 3 h-18 l3 -3 z" fill="none" stroke="{DARKT}" stroke-width="1.6"/>'
    s += f'<circle cx="{WX+WW-44}" cy="{HY+28}" r="15" fill="{BLUE_L}"/>' + T(WX + WW - 44, HY + 32.5, "LB", 11, BLUE, 800, "middle")
    return s


def corps(inner, sid, h=1600):
    """Contenu défilant d'un écran, découpé à la taille de la fenêtre."""
    return (f'<g clip-path="url(#clipCorps)"><rect x="{WX}" y="{BY}" width="{WW}" height="{h}" fill="{BGAPP}"/>'
            f'<g id="{sid}-defil">{inner}</g></g>')


# ---------------------------------------------------------------- ÉCRANS « AVANT »
OLD_LABELS = ["Raison sociale", "Adresse", "Complément d'adresse", "Code postal", "Ville", "Pays", "Date d'enlèvement",
              "Créneau : début", "Créneau : fin", "Contact sur site", "Téléphone", "E-mail du contact",
              "Type de quai", "Hayon requis", "Rendez-vous obligatoire", "Instructions d'accès", "Horaires du site", "Référence interne",
              "Type de marchandise", "Nombre de palettes", "Type de palettes", "Poids total", "Volume (m³)", "Hauteur max.",
              "Matières dangereuses", "Température dirigée", "Valeur déclarée"]


def stepper_ancien(y, actif):
    s = ""
    labels = ["Enlèvement", "Livraison", "Marchandise", "Véhicule", "Prix & matching"]
    for i, l in enumerate(labels):
        x = WX + 180 + i * 210
        if i:
            s += f'<line x1="{x-180}" y1="{y}" x2="{x-18}" y2="{y}" stroke="{LINE}" stroke-width="2"/>'
        on = i < actif
        s += f'<circle id="old-st-{i+1}" cx="{x}" cy="{y}" r="14" fill="{CORAL if on else WHITE}" stroke="{CORAL if on else LINE}" stroke-width="2"/>'
        s += T(x, y + 4.5, str(i + 1), 12, WHITE if on else MUTED, 800, "middle", id=f"old-st-{i+1}-t")
        s += T(x, y + 34, l, 11.5, DARKT, 700, "middle")
    return s


def ecran_ancien_form():
    s = T(WX + 40, BY + 44, "Poster un lot", 22, DARKT, 800)
    s += T(WX + 40, BY + 66, "Renseignez toutes les informations pour lancer le matching.", 13, MUTED)
    s += stepper_ancien(BY + 104, 1)
    y0 = BY + 170
    s += R(WX + 40, y0, WW - 80, 1260, WHITE, LINE, rx=10)
    secs = [("old-sec-1", "Enlèvement", OLD_LABELS[:12]), (None, "Contraintes du site", OLD_LABELS[12:18]), (None, "Marchandise", OLD_LABELS[18:27])]
    y = y0 + 44
    for sid, titre, labels in secs:
        s += T(WX + 70, y, titre, 16, DARKT, 800, id=sid)
        y += 30
        for i, l in enumerate(labels):
            cx = WX + 70 + (i % 3) * 360; cy = y + (i // 3) * 74
            s += T(cx, cy, l + " *", 11.5, MUTED, 700) + R(cx, cy + 8, 330, 34, WHITE, LINE, rx=4)
        y += ((len(labels) + 2) // 3) * 74 + 34
    s += T(WX + 70, y, "Options", 16, DARKT, 800); y += 28
    for i, l in enumerate(["Assurance complémentaire", "Prise de rendez-vous par Upply", "Bon de livraison papier", "Retour de palettes", "Suivi GPS", "Notification SMS"]):
        cx = WX + 70 + (i % 3) * 360; cy = y + (i // 3) * 34
        s += R(cx, cy - 12, 14, 14, WHITE, "#B5B9C1", rx=3) + T(cx + 24, cy, l, 12.5, DARKT)
    y += 100
    s += button(WX + WW - 300, y, 110, "Précédent", "contour") + button(WX + WW - 176, y, 110, "Suivant", "plein", id="old-suivant")
    return G(corps(s, "s-old-form"), id="s-old-form", hidden=True)


def ecran_ancien_matching():
    s = T(WX + 40, BY + 44, "Poster un lot", 22, DARKT, 800)
    s += T(WX + 40, BY + 66, "Renseignez toutes les informations pour lancer le matching.", 13, MUTED)
    s += stepper_ancien(BY + 104, 5)
    cx, cy = WX + WW / 2, BY + 330
    s += R(WX + 240, BY + 180, WW - 480, 360, WHITE, LINE, rx=12)
    s += f'<circle cx="{cx}" cy="{cy-50}" r="34" fill="none" stroke="{GREY_L}" stroke-width="7"/>'
    s += f'<g id="old-spinner"><path d="M{cx} {cy-84} A34 34 0 0 1 {cx+34} {cy-50}" fill="none" stroke="{CORAL}" stroke-width="7" stroke-linecap="round"/></g>'
    s += T(cx, cy + 22, "Recherche d'un transporteur correspondant…", 18, DARKT, 800, "middle")
    s += T(cx, cy + 50, "Votre lot sera proposé uniquement aux transporteurs", 13.5, MUTED, 400, "middle")
    s += T(cx, cy + 70, "dont les critères correspondent aux vôtres.", 13.5, MUTED, 400, "middle")
    s += R(cx - 120, cy + 100, 240, 30, GREY_L, rx=15) + T(cx, cy + 120, "En attente d'un match", 12.5, MUTED, 700, "middle")
    return G(corps(s, "s-old-match"), id="s-old-match", hidden=True)


def ecran_ancien_lots():
    s = ""
    x0 = WX + 50
    tabs = ["Tableau de bord", "Mes lots", "Mes commandes", "Inactifs"]
    s += R(x0, BY + 28, 4 * 120, 58, "#E8E9ED", rx=4)
    for i, tb in enumerate(tabs):
        tx = x0 + i * 120
        if i == 1:
            s += R(tx, BY + 28, 120, 58, "#BFC2C9", rx=0)
        s += f'<circle cx="{tx+60}" cy="{BY+48}" r="8" fill="none" stroke="{DARKT}" stroke-width="1.3"/>' + T(tx + 60, BY + 76, tb, 11.5, DARKT, 400, "middle")
    s += button(WX + WW - 230, BY + 38, 170, "Poster un lot", "plein", h=34)
    s += R(x0, BY + 106, WW - 100, 38, WHITE, rx=4)
    fx = x0 + 14
    for i, f in enumerate(["Tous", "Semaine à venir (5)", "Matchs (17)", "Réservations reçues (6)", "Messages non lus (8)"]):
        s += f'<circle cx="{fx+6}" cy="{BY+125}" r="6" fill="{CORAL if i==0 else WHITE}" stroke="{DARKT if i else CORAL}" stroke-width="1.2"/>' + T(fx + 18, BY + 129.5, f, 11.5, DARKT)
        fx += len(f) * 6.4 + 50
    s += R(WX + WW - 240, BY + 114, 180, 22, WHITE, CORAL, rx=11)
    cols = [("Statut", 0), ("Fret", 80), ("Origine & destination", 180), ("Enlèvement", 330), ("Prix (HT)", 430),
            ("Matchs", 520), ("Réservations reçues", 640), ("Réservations envoyées", 780), ("Chat", 950)]
    s += R(x0, BY + 160, WW - 100, 44, WHITE, rx=0)
    for c, dx in cols:
        s += T(x0 + 14 + dx, BY + 187, c, 11.5, DARKT, 700)
        s += f'<line x1="{x0+dx+6}" y1="{BY+166}" x2="{x0+dx+6}" y2="{BY+198}" stroke="{LINE}"/>' if dx else ""
    rows = [("13", "15 000", "2.5", "FR69 Bron", "FR59 Lille", "J+1", "1 220 €", "5", "2", "1", "3"),
            ("33", "18 000", "2.2", "FR80 Amiens", "FR33 Libourne", "J+2", "1 200 €", "6", "3", "3", "1"),
            ("25", "11 500", "1.8", "FR13 Miramas", "FR83 Draguignan", "J+4", "405 €", "4", "1", "2", "4")]
    for i, r in enumerate(rows):
        y = BY + 220 + i * 96
        s += R(x0, y, WW - 100, 84, WHITE, rx=0)
        s += palettes_icon(x0 + 24, y + 44)
        s += T(x0 + 94, y + 30, f"{r[0]} 120x80p", 11, DARKT) + T(x0 + 94, y + 46, f"{r[1]} kg", 11, DARKT) + T(x0 + 94, y + 62, f"{r[2]} m", 11, DARKT)
        s += pin(x0 + 200, y + 32) + T(x0 + 212, y + 36, r[3], 11.5, DARKT) + flag(x0 + 200, y + 58) + T(x0 + 212, y + 62, r[4], 11.5, DARKT)
        s += T(x0 + 370, y + 48, r[5], 12, DARKT, 400, "middle") + T(x0 + 470, y + 48, r[6], 12, DARKT, 400, "middle")
        s += R(x0 + 532, y + 31, 96, 24, CORAL, rx=12, id=f"old-match-{i}") + T(x0 + 580, y + 47.5, f"Voir matchs : {r[7]}", 11, WHITE, 700, "middle")
        POS[f"old-match-{i}"] = (x0 + 580, y + 43)
        s += T(x0 + 690, y + 48, r[8], 12, DARKT, 700, "middle") + T(x0 + 840, y + 48, r[9], 12, DARKT, 700, "middle") + T(x0 + 975, y + 48, r[10], 12, DARKT, 700, "middle")
    return G(corps(s, "s-old-lots"), id="s-old-lots", hidden=True)


# ---------------------------------------------------------------- ÉCRANS « APRÈS » : CHARGEUR
# contour simplifié de la France métropolitaine (longitude, latitude), sens horaire depuis Dunkerque
FRANCE = [(2.55, 51.08), (1.85, 50.95), (1.6, 50.72), (1.58, 50.35), (1.37, 50.06), (0.6, 49.86), (0.1, 49.49), (0.25, 49.42),
          (-0.36, 49.3), (-1.1, 49.39), (-1.26, 49.67), (-1.62, 49.64), (-1.94, 49.72), (-1.85, 49.4), (-1.6, 48.84), (-1.51, 48.63),
          (-2.0, 48.65), (-2.76, 48.53), (-3.05, 48.78), (-3.45, 48.82), (-3.98, 48.73), (-4.6, 48.62), (-4.77, 48.33), (-4.5, 48.25),
          (-4.73, 48.04), (-4.37, 47.8), (-3.92, 47.87), (-3.37, 47.73), (-3.12, 47.48), (-2.75, 47.5), (-2.51, 47.29), (-2.2, 47.27),
          (-2.25, 46.95), (-1.78, 46.5), (-1.15, 46.16), (-1.2, 45.8), (-1.03, 45.62), (-1.07, 45.57), (-1.25, 44.65), (-1.3, 44.2),
          (-1.56, 43.48), (-1.78, 43.37), (-1.4, 43.05), (-0.7, 42.92), (0.0, 42.7), (0.7, 42.85), (1.45, 42.6), (1.73, 42.5),
          (2.5, 42.43), (3.17, 42.43), (3.04, 42.7), (3.1, 43.1), (3.2, 43.2), (3.7, 43.4), (3.95, 43.53), (4.25, 43.45), (4.6, 43.35),
          (5.0, 43.38), (5.37, 43.3), (5.6, 43.18), (5.93, 43.1), (6.2, 43.1), (6.64, 43.27), (7.0, 43.55), (7.27, 43.7), (7.5, 43.78),
          (7.7, 44.1), (7.0, 44.25), (6.95, 44.42), (6.95, 44.85), (6.63, 45.1), (7.13, 45.25), (6.8, 45.75), (7.04, 45.92),
          (6.8, 46.13), (6.8, 46.4), (6.2, 46.37), (6.15, 46.2), (5.97, 46.2), (6.1, 46.6), (6.45, 46.95), (6.95, 47.3), (7.0, 47.45),
          (7.55, 47.58), (7.62, 48.0), (7.8, 48.5), (8.23, 48.97), (7.6, 49.05), (6.75, 49.17), (6.37, 49.47), (5.85, 49.5),
          (5.4, 49.62), (4.85, 49.8), (4.85, 50.15), (4.2, 49.97), (3.7, 50.3), (3.3, 50.5), (2.9, 50.7)]
CORSE = [(9.4, 43.0), (9.55, 42.6), (9.4, 42.0), (9.2, 41.37), (8.8, 41.6), (8.6, 41.9), (8.7, 42.4), (9.0, 42.65)]
VILLES = {"Paris": (2.35, 48.86), "Lyon": (4.84, 45.76), "Marseille": (5.37, 43.30), "Bordeaux": (-0.58, 44.84),
          "Lille": (3.06, 50.63), "Toulouse": (1.44, 43.60), "Nantes": (-1.55, 47.22), "Strasbourg": (7.75, 48.58),
          "Rennes": (-1.68, 48.11), "Nice": (7.27, 43.70)}
AUTOROUTES = [[(5.37, 43.30), (4.8, 44.14), (4.89, 44.93), (4.84, 45.76), (4.83, 46.31), (4.84, 47.02), (3.57, 47.8), (2.35, 48.86)],
              [(2.35, 48.86), (2.8, 49.9), (3.06, 50.63)],
              [(2.35, 48.86), (1.9, 47.9), (0.69, 47.39), (0.34, 46.58), (-0.58, 44.84)],
              [(-0.58, 44.84), (0.62, 44.2), (1.44, 43.60), (3.0, 43.18), (3.88, 43.61), (4.36, 43.84), (4.8, 44.14)],
              [(2.35, 48.86), (4.03, 49.26), (6.18, 49.12), (7.75, 48.58)],
              [(2.35, 48.86), (0.2, 48.0), (-0.55, 47.47), (-1.55, 47.22)], [(0.2, 48.0), (-1.68, 48.11)],
              [(5.37, 43.30), (6.2, 43.45), (7.27, 43.70)]]
TRAJET = [(4.99, 43.58), (4.8, 44.14), (4.89, 44.93), (4.84, 45.76), (4.83, 46.31), (4.84, 47.02), (3.57, 47.8), (2.46, 48.72)]


ANGLETERRE = [(-5.3, 49.96), (-4.1, 50.35), (-3.4, 50.6), (-2.4, 50.55), (-1.3, 50.78), (-0.1, 50.8), (0.6, 50.85), (1.3, 51.12), (1.45, 51.3), (-5.3, 51.3)]
ESPAGNE_NORD = [(-1.78, 43.37), (-2.9, 43.35), (-3.8, 43.47), (-5.3, 43.55)]
ESPAGNE_EST = [(3.17, 42.43), (3.32, 42.32), (3.2, 41.9), (2.17, 41.38), (1.6, 41.15)]
ITALIE = [(7.5, 43.78), (7.77, 43.82), (8.2, 43.95), (8.48, 44.3), (8.93, 44.41), (9.4, 44.25), (9.8, 44.05)]
FORETS = [((-0.9, 44.3), 0.55, 0.9), ((6.9, 48.1), 0.35, 0.6), ((4.0, 47.15), 0.35, 0.3), ((6.3, 45.4), 0.6, 0.45), ((2.9, 45.4), 0.6, 0.45),
          ((2.65, 48.4), 0.18, 0.12), ((0.1, 42.85), 0.8, 0.12), ((5.6, 44.0), 0.35, 0.3), ((-3.4, 48.25), 0.35, 0.18), ((1.9, 47.6), 0.45, 0.2),
          ((9.1, 42.2), 0.25, 0.4)]
FLEUVES = [[(2.35, 48.86), (1.9, 49.05), (1.4, 49.3), (0.6, 49.45), (0.2, 49.47)],
           [(4.2, 45.4), (4.0, 46.6), (3.2, 47.1), (2.0, 47.75), (1.0, 47.4), (0.0, 47.25), (-1.5, 47.2), (-2.1, 47.28)],
           [(6.15, 46.2), (5.6, 45.9), (4.84, 45.76), (4.8, 44.9), (4.7, 44.1), (4.6, 43.6), (4.65, 43.4)],
           [(1.44, 43.60), (0.6, 44.2), (-0.2, 44.6), (-0.58, 44.84), (-0.75, 45.2)]]


def carte_france(x, y, w, h):
    """Carte de France façon carte web (Google Maps) : mer, pays voisins, forêts, fleuves, villes, trajet animé."""
    import math
    k = math.cos(math.radians(46.5))
    lo0, lo1, la0, la1 = -5.2, 9.7, 41.2, 51.2
    sc = min((w - 40) / ((lo1 - lo0) * k), (h - 40) / (la1 - la0))
    ox = x + (w - (lo1 - lo0) * k * sc) / 2
    oy = y + (h - (la1 - la0) * sc) / 2
    P = lambda lo, la: (ox + (lo - lo0) * k * sc, oy + (la1 - la) * sc)
    pts_ = lambda pts: " L".join(f"{P(*p)[0]:.1f} {P(*p)[1]:.1f}" for p in pts)
    poly = lambda pts: "M" + pts_(pts) + " Z"
    line = lambda pts: "M" + pts_(pts)
    TERRE, MER, FORET, BORD = "#F2EFE9", "#AAD3DF", "#CDE6C3", "#B5AEB9"
    E = 8  # marge hors cadre, en degrés
    s = f'<g clip-path="url(#clipCarte)"><rect x="{x}" y="{y}" width="{w}" height="{h}" fill="{TERRE}"/>'
    # mer : Atlantique + Manche, puis Méditerranée
    i_dk = 0; i_he = FRANCE.index((-1.78, 43.37)); i_ce = FRANCE.index((3.17, 42.43)); i_me = FRANCE.index((7.5, 43.78))
    atl = FRANCE[i_dk:i_he + 1] + ESPAGNE_NORD + [(-5.3 - E, 43.55), (-5.3 - E, 49.96)] + ANGLETERRE + [(3.3, 51.3), (3.0, 51.2)]
    med = FRANCE[i_ce:i_me + 1] + ITALIE + [(9.8 + E, 44.05), (9.8 + E, 41.2 - E), (1.6, 41.2 - E)] + list(reversed(ESPAGNE_EST))
    s += f'<path d="{poly(atl)}" fill="{MER}"/><path d="{poly(med)}" fill="{MER}"/>'
    # France : forêts et parcs (verts), lac, fleuves
    s += f'<clipPath id="clipFrance"><path d="{poly(FRANCE)}"/><path d="{poly(CORSE)}"/></clipPath>'
    s += f'<path d="{poly(CORSE)}" fill="{TERRE}"/>'
    s += '<g clip-path="url(#clipFrance)">'
    for (lo, la), rx, ry in FORETS:
        cx, cy = P(lo, la)
        s += f'<ellipse cx="{cx:.1f}" cy="{cy:.1f}" rx="{rx*k*sc:.1f}" ry="{ry*sc:.1f}" fill="{FORET}"/>'
    s += '</g>'
    lx, ly = P(6.5, 46.42)
    s += f'<ellipse cx="{lx:.1f}" cy="{ly:.1f}" rx="{0.32*k*sc:.1f}" ry="{0.07*sc:.1f}" fill="{MER}" transform="rotate(-8 {lx:.1f} {ly:.1f})"/>'
    for pts in FLEUVES:
        s += f'<path d="{line(pts)}" fill="none" stroke="{MER}" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>'
    # frontières terrestres en pointillés (le littoral n'a pas de trait)
    for a_, b_ in [(i_he, i_ce), (i_me, len(FRANCE) - 1)]:
        s += f'<path d="{line(FRANCE[a_:b_ + 1])}" fill="none" stroke="{BORD}" stroke-width="1.4" stroke-dasharray="4 3"/>'
    s += f'<path d="{line([FRANCE[-1], FRANCE[0]])}" fill="none" stroke="{BORD}" stroke-width="1.4" stroke-dasharray="4 3"/>'
    for nom, (lo, la) in VILLES.items():
        cx, cy = P(lo, la)
        s += f'<circle cx="{cx:.1f}" cy="{cy:.1f}" r="2.6" fill="#7A7F87"/>' + T(cx + 6, cy + 4, nom, 10.5, "#5F6368", 700)
    for nom, lo, la in [("Manche", -2.6, 49.95), ("Océan Atlantique", -4.6, 46.0), ("Mer Méditerranée", 4.6, 42.4)]:
        cx, cy = P(lo, la)
        s += T(cx, cy, nom, 10, "#5E8FA3", 600, italic=True)
    s += f'<path id="route" d="{line(TRAJET)}" pathLength="1" fill="none" stroke="{CORAL}" stroke-width="4" stroke-linecap="round" stroke-linejoin="round" stroke-dasharray="1" stroke-dashoffset="1"/>'
    ax, ay = P(*TRAJET[0]); bx, by = P(*TRAJET[-1])
    s += G(f'<circle cx="{ax:.0f}" cy="{ay:.0f}" r="9" fill="{CORAL}"/><circle cx="{ax:.0f}" cy="{ay:.0f}" r="3.5" fill="{WHITE}"/>'
           + R(ax - 132, ay - 13, 112, 26, WHITE, LINE, rx=13) + T(ax - 76, ay + 4, "Miramas (13)", 11.5, DARKT, 700, "middle"), id="pin-a", hidden=True)
    s += G(f'<circle cx="{bx:.0f}" cy="{by:.0f}" r="9" fill="{CORAL}"/>' + flag(bx, by, WHITE).replace('stroke-width="1.5"', 'stroke-width="1.8"')
           + R(bx - 124, by - 13, 104, 26, WHITE, LINE, rx=13) + T(bx - 72, by + 4, "Crosne (91)", 11.5, DARKT, 700, "middle"), id="pin-b", hidden=True)
    s += G(R(x + 16, y + 16, 150, 50, WHITE, LINE, rx=10) + T(x + 32, y + 37, "Distance", 11, MUTED, 700)
           + T(x + 32, y + 56, "744 km · ≈ 7 h", 14, DARKT, 800), id="km", hidden=True)
    zx, zy = x + w - 46, y + 16
    s += R(zx, zy, 30, 60, WHITE, LINE, rx=6) + f'<line x1="{zx+4}" y1="{zy+30}" x2="{zx+26}" y2="{zy+30}" stroke="{LINE}"/>'
    s += T(zx + 15, zy + 21, "+", 16, DARKT, 700, "middle") + T(zx + 15, zy + 51, "−", 16, DARKT, 700, "middle")
    return s + "</g>"


def ecran_poster():
    s = T(WX + 40, BY + 46, "Publier un lot", 22, DARKT, 800)
    st1, w1 = chip(WX + 210, BY + 26, "1  Enlèvement et livraison", id="pst1", on=True)
    st2, w2 = chip(WX + 210 + w1 + 10, BY + 26, "2  Fret et véhicule", id="pst2")
    s += st1 + st2
    lx, ly, lw, lh = WX + 40, BY + 80, 540, 500
    s += R(lx, ly, lw, lh, WHITE, LINE, rx=12)
    e1 = T(lx + 28, ly + 40, "Enlèvement", 15, DARKT, 800)
    e1 += inp(lx + 28, ly + 70, 300, "Adresse", "p-adr1", "Ville ou code postal")
    e1 += inp(lx + 344, ly + 70, 168, "Date", "p-date1", "jj/mm")
    e1 += T(lx + 28, ly + 160, "Livraison", 15, DARKT, 800)
    e1 += inp(lx + 28, ly + 190, 300, "Adresse", "p-adr2", "Ville ou code postal")
    e1 += inp(lx + 344, ly + 190, 168, "Date", "p-date2", "jj/mm")
    e1 += T(lx + 28, ly + 290, "Les adresses se complètent automatiquement.", 12, MUTED, 400, italic=True)
    e1 += button(lx + lw - 180, ly + lh - 64, 152, "Continuer", "plein", id="p-continuer")
    dd1 = (R(lx + 28, ly + 120, 300, 78, WHITE, LINE, rx=6, extra='filter="url(#ombre)"')
           + R(lx + 32, ly + 124, 292, 34, CORAL_L, rx=4, id="dd1-hl") + T(lx + 44, ly + 146, "Miramas, 13140", 13, DARKT, 700)
           + T(lx + 44, ly + 182, "Miramont-de-Guyenne, 47800", 13, DARKT))
    POS["dd1-1"] = (lx + 120, ly + 141)
    dd2 = (R(lx + 28, ly + 240, 300, 78, WHITE, LINE, rx=6, extra='filter="url(#ombre)"')
           + R(lx + 32, ly + 244, 292, 34, CORAL_L, rx=4) + T(lx + 44, ly + 266, "Crosne, 91560", 13, DARKT, 700)
           + T(lx + 44, ly + 302, "Crosnes, 73100", 13, DARKT))
    POS["dd2-1"] = (lx + 120, ly + 261)
    e1 += G(dd1, id="dd1", hidden=True) + G(dd2, id="dd2", hidden=True)
    s += G(e1, id="p-etape1")
    e2 = T(lx + 28, ly + 40, "Fret", 15, DARKT, 800)
    e2 += inp(lx + 28, ly + 70, 150, "Nombre de palettes", "p-pal", "0")
    e2 += T(lx + 200, ly + 70, "Type de palettes", 12, MUTED, 700)
    c1, w = chip(lx + 200, ly + 80, "80x120", id="p-c80"); c2, _ = chip(lx + 200 + w + 8, ly + 80, "100x120", id="p-c100")
    e2 += c1 + c2
    e2 += inp(lx + 28, ly + 150, 150, "Poids total (tonnes)", "p-poids", "0")
    e2 += T(lx + 28, ly + 250, "Véhicule", 15, DARKT, 800)
    vx = lx + 28
    for k, lab in [("semi", "Semi-remorque"), ("porteur", "Porteur"), ("fourgon", "Fourgon")]:
        c, w = chip(vx, ly + 268, lab, id=f"p-{k}", h=34); e2 += c; vx += w + 10
    e2 += T(lx + 28, ly + 340, "Les autres critères sont facultatifs.", 12, MUTED, 400, italic=True)
    e2 += button(lx + lw - 180, ly + lh - 64, 152, "Publier le lot", "plein", id="p-publier")
    s += G(e2, id="p-etape2", hidden=True)
    mx, my, mw, mh = WX + 600, BY + 80, 560, 500
    s += R(mx - 1, my - 1, mw + 2, mh + 2, LINE, rx=13)
    s += carte_france(mx, my, mw, mh)
    return G(corps(s, "s-post"), id="s-post", hidden=True)


def ecran_mes_lots():
    s = T(WX + 40, BY + 46, "Mes lots", 22, DARKT, 800)
    x = WX + 40
    for i, lab in enumerate(["Tous (4)", "Avec offres (3)", "Expirés"]):
        c, w = chip(x, BY + 64, lab, on=i == 0); s += c; x += w + 8
    s += R(WX + WW - 420, BY + 26, 220, 34, WHITE, LINE, rx=17) + T(WX + WW - 400, BY + 48, "Rechercher un lot", 12.5, "#B5B9C1")
    s += button(WX + WW - 186, BY + 25, 146, "Poster un lot", "plein")
    for i, d in enumerate(LOTS_CHARGEUR):
        n = [0, 3, 1, 2][i]
        s += lot_card(WX + 40, BY + 120 + i * 92, WW - 80, d, ("chargeur", n), id=f"ml-{i}", hl=i == 0)
    s += G(R(0, 0, 118, 28, DARKT, rx=6) + T(59, 18.5, "Dupliquer ce lot", 11.5, WHITE, 700, "middle"), id="tip-dup", hidden=True,
           extra=f'transform="translate({POS["ml-1-dup"][0]-59:.0f} {POS["ml-1-dup"][1]-50:.0f})"')
    s += f'<circle id="ml-0-pulse" cx="{WX+40+WW-80-262+37}" cy="{BY+120+39}" r="13" fill="none" stroke="{GREEN}" stroke-width="2" opacity="0"/>'
    return G(corps(s, "s-lots"), id="s-lots", hidden=True)


# ---------------------------------------------------------------- ÉCRANS « APRÈS » : TRANSPORTEUR
def panneau_recherche():
    px, py, pw, ph = WX + 30, BY + 24, 290, 560
    s = R(px, py, pw, ph, WHITE, LINE, rx=12)
    s += T(px + 22, py + 38, "Rechercher", 17, DARKT, 800)
    s += inp(px + 22, py + 74, pw - 44, "Enlèvement (pickup)", "r-pick", "Département ou ville")
    s += inp(px + 22, py + 150, pw - 44, "Livraison (delivery)", "r-deli", "Département ou ville")
    s += inp(px + 22, py + 226, pw - 44, "Fret", "r-fret", "Palettes, poids…")
    s += button(px + 22, py + 300, pw - 44, "Sauvegarder la recherche", "contour", id="r-sauver")
    s += T(px + 22, py + 362, "Vous recevrez un e-mail dès qu'un", 11.5, MUTED, 400, italic=True)
    s += T(px + 22, py + 378, "nouveau lot correspond.", 11.5, MUTED, 400, italic=True)
    return s


def ecran_recherche():
    s = panneau_recherche()
    lx = WX + 340; lw = WW - 340 - 30
    s += T(lx, BY + 50, "12 lots disponibles", 16, DARKT, 800, id="r-compte")
    s += T(lx + lw, BY + 50, "Trier : date d'enlèvement", 12.5, MUTED, 600, "end")
    s += G("".join(lot_card(lx, BY + 72 + i * 92, lw, d, ("recherche",), id=f"rt-{i}") for i, d in enumerate(LOTS_TOUS)), id="r-liste-tous")
    s += G("".join(lot_card(lx, BY + 72 + i * 92, lw, d, ("recherche",), id=f"rf-{i}") for i, d in enumerate(LOTS_FR13)), id="r-liste-fr13", hidden=True)
    cw = 420
    s += G("".join(lot_card(lx, BY + 72 + i * 92, cw, d, None, id=f"rc-{i}", hl=False) for i, d in enumerate(LOTS_FR13))
           + R(lx - 2, BY + 70, cw + 4, 82, "none", CORAL, rx=11, sw=2), id="r-liste-compacte", hidden=True)
    # drawer intégré (ne recouvre ni les champs ni la liste)
    dx, dy, dw, dh = lx + cw + 20, BY + 24, lw - cw - 20, 560
    d = R(dx, dy, dw, dh, WHITE, CORAL, rx=12, sw=1.4)
    d += T(dx + 24, dy + 38, "Faire une offre", 17, DARKT, 800) + T(dx + dw - 26, dy + 38, "×", 20, MUTED, 400, "middle")
    d += R(dx + 24, dy + 58, dw - 48, 72, BGAPP, rx=8)
    d += pin(dx + 42, dy + 80) + T(dx + 54, dy + 85, "FR13 Miramas", 12.5, DARKT, 800) + flag(dx + 42, dy + 108) + T(dx + 54, dy + 113, "FR91 Crosne", 12.5, DARKT, 800)
    d += T(dx + dw - 40, dy + 85, "03/11 → 10/11", 12, DARKT, 700, "end") + T(dx + dw - 40, dy + 113, "33 pal. · 1 t · Semi", 12, MUTED, 600, "end")
    d += inp(dx + 24, dy + 160, dw - 48, "Votre prix (€ HT)", "o-prix", "0 €")
    d += inp(dx + 24, dy + 236, dw - 48, "Date d'enlèvement proposée", "o-date", "", "03/11")
    d += inp(dx + 24, dy + 312, dw - 48, "Commentaire (facultatif)", "o-com", "Un message pour le chargeur")
    d += button(dx + 24, dy + dh - 64, dw - 48, "Envoyer l'offre", "plein", id="o-envoyer")
    s += f'<g clip-path="url(#clipDrawer1)"><g id="drawer1" transform="translate({dw+40} 0)">{d}</g></g>'
    return G(corps(s, "s-search"), id="s-search", hidden=True)


def ecran_offres():
    s = T(WX + 40, BY + 46, "Mes offres", 22, DARKT, 800)
    x = WX + 40
    for i, lab in enumerate(["Toutes (3)", "Envoyées", "Acceptées", "Refusées"]):
        c, w = chip(x, BY + 64, lab, on=i == 0); s += c; x += w + 8
    offres = [(LOTS_FR13[0], "1 250 €", "Envoyée"), (LOTS_TOUS[1], "680 €", "Acceptée"), (LOTS_TOUS[2], "420 €", "Refusée")]
    for i, (d, prix, st) in enumerate(offres):
        s += lot_card(WX + 40, BY + 120 + i * 92, WW - 80, d, ("offre", prix, st), id=f"of-{i}")
    s += f'<rect id="of-voile" x="{WX}" y="{BY}" width="{WW}" height="620" fill="{DARKT}" opacity="0"/>'
    dw = 400; dx = WX + WW - dw
    d = R(dx, BY, dw, 620, WHITE, rx=0) + f'<line x1="{dx}" y1="{BY}" x2="{dx}" y2="{BY+620}" stroke="{LINE}"/>'
    d += T(dx + 28, BY + 44, "Détail de l'offre", 18, DARKT, 800) + T(dx + dw - 30, BY + 44, "×", 22, MUTED, 400, "middle")
    d += T(dx + 28, BY + 84, "Statut", 12, MUTED, 700) + R(dx + 28, BY + 94, 84, 26, BLUE_L, rx=13) + T(dx + 70, BY + 111.5, "Envoyée", 11.5, BLUE, 800, "middle")
    for i, (k, v) in enumerate([("Chargeur", "Provence Distrib."), ("Date d'enlèvement", "03/11")]):
        d += inp(dx + 28 + i * 176, BY + 150, 160, k, f"od-{i}", "", v)
    for i, (k, v) in enumerate([("Pickup", "FR13 Miramas"), ("Delivery", "FR91 Crosne")]):
        d += inp(dx + 28 + i * 176, BY + 226, 160, k, f"od-{i+2}", "", v)
    d += inp(dx + 28, BY + 302, 160, "Prix proposé", "od-prix", "", "1 250 € HT")
    d += T(dx + 28, BY + 400, "Le chargeur est notifié par e-mail.", 12, MUTED, 400, italic=True)
    d += button(dx + 28, BY + 540, dw - 56, "Modifier l'offre", "contour", id="od-modifier")
    s += f'<g id="drawer2" transform="translate({dw+20} 0)">{d}</g>'
    return G(corps(s, "s-offers"), id="s-offers", hidden=True)


# ---------------------------------------------------------------- calques globaux
def bandeau():
    s = '<g id="bandeau">'
    x = 40
    for i, (k, lab) in enumerate([("ch-avant", "Avant : l'ancienne Marketplace"), ("ch-chargeur", "Connect : chargeur"), ("ch-transp", "Connect : transporteur")]):
        w = len(lab) * 7.4 + 34
        s += R(x, 22, w, 32, NPINK, NPINK, rx=16, id=f"{k}-bg", extra='fill-opacity="0" stroke-opacity="0.45"')
        s += T(x + w / 2, 43, lab, 13, NINK, 700, "middle", id=f"{k}-t", op=0.55)
        x += w + 10
    s += T(SW - 40, 43, "", 14, NINK, 600, "end", id="legende", op=0.85)
    return s + "</g>"


def carte_titre():
    cx, cy = WX + WW / 2, WY + WH / 2
    s = f'<g id="titre" opacity="0"><rect x="{WX}" y="{WY}" width="{WW}" height="{WH}" rx="14" fill="{NBG}" fill-opacity="0.94"/>'
    s += T(cx, cy - 26, "", 15, NSOL, 800, "middle", id="titre-k", ls=4)
    s += T(cx, cy + 24, "", 38, NPINK, 700, "middle", id="titre-t")
    s += T(cx, cy + 62, "", 16, NINK, 400, "middle", id="titre-s", op=0.75)
    return s + "</g>"


def toast():
    x, y = WX + WW / 2 - 220, WY + WH - 74
    return (f'<g id="toast" opacity="0"><g id="toast-pos">'
            + R(x, y, 440, 50, DARKT, rx=10, extra='filter="url(#ombre)"')
            + f'<circle cx="{x+26}" cy="{y+25}" r="10" fill="{GREEN}"/><path d="M{x+21} {y+25} l4 4 l7 -8" stroke="{WHITE}" stroke-width="2" fill="none" stroke-linecap="round"/>'
            + T(x + 46, y + 30, "", 13, WHITE, 700, id="toast-t") + "</g></g>")


def curseur():
    return ('<g id="curseur"><circle id="clic" cx="0" cy="0" r="0" fill="#F25C54" fill-opacity="0.25" stroke="#F25C54" stroke-width="2" opacity="0"/>'
            '<path d="M0 0 L0 20 L5.5 15 L9 23 L12.5 21.5 L9 14 L16 14 Z" fill="#FFFFFF" stroke="#111" stroke-width="1.3" stroke-linejoin="round"/></g>')


# ---------------------------------------------------------------- frise temporelle
VITESSE = 0.6   # facteur appliqué à toutes les durées (0.6 = 40 % plus court)


class TL:
    def __init__(self):
        self.t = 0.0
        self.sets, self.types, self.screens, self.clicks = [], [], [], []
        self.tracks = {}
        self.cur = (SW / 2, SH / 2)
        self.chapters = {}
        self.k = VITESSE       # < 1 = plus rapide

    def track(self, name, el, kind, init, **kw):
        self.tracks[name] = dict(el=el, kind=kind, keys=[[0, init]], cur=init, **kw)

    def anim(self, name, to, dur, at=None):
        t0 = self.t if at is None else at
        tr = self.tracks[name]
        dur *= self.k
        tr["keys"] += [[round(t0, 3), tr["cur"]], [round(t0 + dur, 3), to]]
        tr["cur"] = to

    def wait(self, d):
        self.t += d * self.k

    def set(self, el, prop, val, at=None):
        self.sets.append([round(self.t if at is None else at, 3), el, prop, val])

    def show(self, el):
        self.set(el, "display", "")

    def hide(self, el):
        self.set(el, "display", "none")

    def screen(self, sid):
        self.screens.append([round(self.t, 3), sid])

    def move(self, target, dur=0.7):
        dur *= self.k
        x, y = POS[target] if isinstance(target, str) else target
        tr = self.tracks["curseur"]
        tr["keys"] += [[round(self.t, 3), list(self.cur)], [round(self.t + dur, 3), [x, y]]]
        self.cur = (x, y); tr["cur"] = [x, y]
        self.t += dur

    def click(self):
        self.clicks.append([round(self.t, 3), self.cur[0], self.cur[1]])
        self.t += 0.35 * self.k

    def type(self, el, txt, cps=9):
        dur = max(0.25, len(txt) / cps * self.k)
        self.set(el + "-ph", "display", "none")
        self.types.append([round(self.t, 3), round(dur, 3), el, txt])
        self.t += dur + 0.15 * self.k

    def legende(self, txt):
        self.set("legende", "text", txt)

    def chapitre(self, k):
        self.chapters[k] = round(self.t, 3)
        self.set("legende", "text", "")
        for c in ["ch-avant", "ch-chargeur", "ch-transp"]:
            on = c == k
            self.set(f"{c}-bg", "fill-opacity", "0.18" if on else "0")
            self.set(f"{c}-bg", "stroke-opacity", "1" if on else "0.45")
            self.set(f"{c}-t", "fill-opacity", "1" if on else "0.55")

    def titre(self, k, t, sub, d=2.2):
        self.set("titre-k", "text", k); self.set("titre-t", "text", t); self.set("titre-s", "text", sub)
        self.anim("titre", 1, 0.35); self.t += d; self.anim("titre", 0, 0.45, at=self.t)

    def toast(self, txt, d=2.4):
        self.set("toast-t", "text", txt)
        self.anim("toast", 1, 0.3); self.anim("toast-y", 0, 0.3)
        d *= max(self.k, 0.8)   # garder le temps de lire le message
        self.anim("toast", 0, 0.4, at=self.t + d); self.anim("toast-y", 12, 0.01, at=self.t + d + 0.4)
        self.t += 0.3 * self.k


def _frise_base():
    tl = TL()
    tl.track("curseur", "curseur", "cursor", [WX + WW - 220, WY + WH - 120])
    tl.cur = (WX + WW - 220, WY + WH - 120)
    tl.track("toast", "toast", "op", 0)
    tl.track("toast-y", "toast-pos", "y", 12)
    return tl


def frise_avant():
    tl = _frise_base()
    for sid in ["s-old-form", "s-old-lots"]:
        tl.track(sid, f"{sid}-defil", "ty", 0)
    tl.track("spinner", "old-spinner", "rot", 0, cx=WX + WW / 2, cy=BY + 280)
    tl.screen("s-old-form")
    tl.wait(0.4)
    tl.move((WX + 300, BY + 300), 0.8)
    tl.anim("s-old-form", 900, 3.2); tl.wait(3.3)
    p = POS["old-suivant"]; tl.move((p[0], p[1] - 900), 0.6)
    tl.click()
    for i in (1, 2):
        tl.set(f"old-st-{i}", "fill", CORAL); tl.set(f"old-st-{i}", "stroke", CORAL); tl.set(f"old-st-{i}-t", "fill", WHITE)
    tl.set("old-sec-1", "text", "Livraison")
    tl.anim("s-old-form", 0, 0.01); tl.wait(0.3)
    tl.anim("s-old-form", 700, 1.6); tl.wait(1.8)
    tl.screen("s-old-match")
    tl.anim("spinner", 720, 3.2); tl.wait(3.3)
    tl.screen("s-old-lots")
    tl.move("old-match-0", 0.9); tl.wait(0.4)
    tl.move("old-match-2", 0.8); tl.wait(1.6)
    return tl


def frise_chargeur():
    tl = _frise_base()
    for sid in ["s-post", "s-lots"]:
        tl.track(sid, f"{sid}-defil", "ty", 0)
    tl.track("route", "route", "dash", 1)
    tl.track("pulse", "ml-0-pulse", "op", 0)
    tl.track("pulse-r", "ml-0-pulse", "r", 13)
    tl.screen("s-post")
    tl.wait(0.6)
    tl.move("p-adr1", 0.8); tl.click()
    tl.type("p-adr1", "Mira")
    tl.show("dd1"); tl.wait(0.4)
    tl.move("dd1-1", 0.5); tl.click()
    tl.hide("dd1"); tl.set("p-adr1", "text", "Miramas, 13140"); tl.show("pin-a"); tl.wait(0.3)
    tl.move("p-date1", 0.5); tl.click(); tl.type("p-date1", "03/11")
    tl.move("p-adr2", 0.6); tl.click(); tl.type("p-adr2", "Cros")
    tl.show("dd2"); tl.wait(0.4)
    tl.move("dd2-1", 0.5); tl.click()
    tl.hide("dd2"); tl.set("p-adr2", "text", "Crosne, 91560"); tl.show("pin-b")
    tl.anim("route", 0, 1.2); tl.wait(0.7); tl.show("km"); tl.wait(0.5)
    tl.move("p-date2", 0.5); tl.click(); tl.type("p-date2", "10/11")
    tl.move("p-continuer", 0.6); tl.click()
    tl.hide("p-etape1"); tl.show("p-etape2")
    for k, on in [("pst1", False), ("pst2", True)]:
        tl.set(f"{k}-bg", "fill", CORAL_L if on else WHITE); tl.set(f"{k}-bg", "stroke", CORAL if on else LINE); tl.set(f"{k}-t", "fill", CORAL if on else DARKT)
    tl.move("p-pal", 0.6); tl.click(); tl.type("p-pal", "33")
    tl.move("p-c80", 0.5); tl.click()
    tl.set("p-c80-bg", "fill", CORAL_L); tl.set("p-c80-bg", "stroke", CORAL); tl.set("p-c80-t", "fill", CORAL)
    tl.move("p-poids", 0.5); tl.click(); tl.type("p-poids", "1")
    tl.move("p-semi", 0.6); tl.click()
    tl.set("p-semi-bg", "fill", CORAL_L); tl.set("p-semi-bg", "stroke", CORAL); tl.set("p-semi-t", "fill", CORAL)
    tl.move("p-publier", 0.7); tl.click()
    tl.toast("Lot publié : visible par les transporteurs"); tl.wait(1.2)
    tl.screen("s-lots")
    tl.wait(1.2)
    tl.move("ml-1-dup", 0.9); tl.show("tip-dup"); tl.wait(0.8)
    tl.click(); tl.hide("tip-dup")
    tl.toast("Lot dupliqué : il ne reste qu'à changer la date"); tl.wait(2.6)
    tl.set("ml-0-bulle", "fill", GREEN_L); tl.set("ml-0-bulle-t", "fill", GREEN); tl.set("ml-0-bulle-t", "text", "1 offre")
    tl.anim("pulse", 1, 0.05); tl.anim("pulse-r", 28, 0.8, at=tl.t); tl.anim("pulse", 0, 0.8, at=tl.t + 0.05)
    tl.toast("Nouvelle offre reçue : un e-mail vous a été envoyé"); tl.wait(0.9)
    tl.move("ml-0-voir", 0.8); tl.wait(2.2)
    return tl


def frise_transporteur():
    tl = _frise_base()
    for sid in ["s-search", "s-offers"]:
        tl.track(sid, f"{sid}-defil", "ty", 0)
    tl.track("drawer1", "drawer1", "tx", 430)
    tl.track("drawer2", "drawer2", "tx", 420)
    tl.track("voile", "of-voile", "op", 0)
    tl.screen("s-search")
    tl.wait(0.6)
    tl.move("r-pick", 0.8); tl.click(); tl.type("r-pick", "FR13", 6)
    tl.hide("r-liste-tous"); tl.show("r-liste-fr13"); tl.set("r-compte", "text", "3 lots disponibles"); tl.wait(0.6)
    tl.move("r-sauver", 0.7); tl.click()
    tl.toast("Recherche sauvegardée : alerte e-mail activée"); tl.wait(1.8)
    tl.move("rf-0-offre", 0.8); tl.click()
    tl.hide("r-liste-fr13"); tl.show("r-liste-compacte")
    tl.anim("drawer1", 0, 0.5); tl.wait(0.7)
    tl.move("o-prix", 0.6); tl.click(); tl.type("o-prix", "1 250 €", 7)
    tl.move("o-envoyer", 0.7); tl.click()
    tl.toast("Offre envoyée : le chargeur est notifié"); tl.wait(1.6)
    tl.move("onglet-Mes offres", 0.8); tl.click()
    tl.screen("s-offers")
    tl.wait(0.8)
    tl.move("of-0-ligne", 0.8); tl.click()
    tl.anim("voile", 0.35, 0.4); tl.anim("drawer2", 0, 0.45); tl.wait(0.8)
    tl.move("od-modifier", 0.9); tl.wait(2.4)
    return tl


VARIANTES = {
    "avant": dict(titre="Ancienne Marketplace : publier un lot",
                  ecrans=lambda: ecran_ancien_form() + ecran_ancien_matching() + ecran_ancien_lots(),
                  heads=lambda: {"s-old-form": entete_ancien(), "s-old-match": entete_ancien(), "s-old-lots": entete_ancien()},
                  frise=frise_avant),
    "chargeur": dict(titre="Connect, parcours chargeur : publier un lot et suivre ses lots",
                     ecrans=lambda: ecran_poster() + ecran_mes_lots(),
                     heads=lambda: {"s-post": entete_connect(["Mes lots", "Poster un lot"], "Poster un lot"),
                                    "s-lots": entete_connect(["Mes lots", "Poster un lot"], "Mes lots")},
                     frise=frise_chargeur),
    "transporteur": dict(titre="Connect, parcours transporteur : rechercher un lot, faire une offre, suivre ses offres",
                         ecrans=lambda: ecran_recherche() + ecran_offres(),
                         heads=lambda: {"s-search": entete_connect(["Rechercher des lots", "Mes offres"], "Rechercher des lots"),
                                        "s-offers": entete_connect(["Rechercher des lots", "Mes offres"], "Mes offres")},
                         frise=frise_transporteur),
}


def page(kind):
    v = VARIANTES[kind]
    POS.clear()
    ecrans = v["ecrans"]()
    entetes = "".join(G(h, id=f"h-{k}", hidden=True) for k, h in v["heads"]().items())
    tl = v["frise"]()
    total = round(tl.t + 0.3, 2)
    defs = (f'<defs><clipPath id="clipFen"><rect x="{WX}" y="{HY}" width="{WW}" height="{WY+WH-HY}" rx="14"/></clipPath>'
            f'<clipPath id="clipCorps"><rect x="{WX}" y="{BY}" width="{WW}" height="{WY+WH-BY}"/></clipPath>'
            f'<clipPath id="clipDrawer1"><rect x="{WX+340}" y="{BY}" width="{WW-340}" height="{WY+WH-BY}"/></clipPath>'
            f'<clipPath id="clipCarte"><rect x="{WX+600}" y="{BY+80}" width="560" height="500" rx="12"/></clipPath>'
            '<filter id="ombre" x="-20%" y="-20%" width="140%" height="160%"><feDropShadow dx="0" dy="4" stdDeviation="6" flood-opacity="0.18"/></filter></defs>')
    svg = (f'<svg id="wf" viewBox="{WX} {WY} {WW} {WH}" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="{escape(v["titre"])}">{defs}'
           + f'<g id="fenetre">{fenetre()}</g>'
           + f'<g clip-path="url(#clipFen)">{ecrans}{entetes}</g>' + toast() + curseur() + '</svg>')
    data = dict(total=total, sets=tl.sets, types=tl.types, screens=tl.screens, clicks=tl.clicks,
                tracks={k: {**{kk: vv for kk, vv in tr.items() if kk not in ("cur", "keys")}, "keys": sorted(tr["keys"], key=lambda kv: kv[0])} for k, tr in tl.tracks.items()})
    return HTML.replace("__SVG__", svg).replace("__DATA__", json.dumps(data, ensure_ascii=False)).replace("__TITRE__", escape(v["titre"]))


HTML = r"""<!DOCTYPE html>
<html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>__TITRE__</title>
<link rel="preconnect" href="https://fonts.googleapis.com"><link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800&display=swap" rel="stylesheet">
<style>
  body{margin:0;background:#0B0B12;color:#F5F3FF;font-family:Nunito,Inter,Arial,sans-serif;display:flex;flex-direction:column;align-items:center;padding:0;overflow:hidden}
  #scene{width:100%;max-width:1200px}
  #wf{width:100%;height:auto;display:block}
  .barre{width:100%;max-width:1200px;display:flex;gap:10px;align-items:center;margin-top:6px}
  button{font:700 13px Nunito,Inter,Arial,sans-serif;color:#F5F3FF;background:#17171F;border:1px solid rgba(255,79,160,.5);border-radius:999px;padding:8px 16px;cursor:pointer}
  button:hover{background:rgba(255,79,160,.15)}
  #prog{flex:1;height:6px;background:#17171F;border-radius:3px;position:relative;cursor:pointer}
  #prog i{position:absolute;left:0;top:0;bottom:0;background:linear-gradient(90deg,#FFC46B,#FF4FA0,#B23FE0);border-radius:3px}
</style></head><body>
<div id="scene">__SVG__</div>
<div class="barre">
  <button id="lecture" aria-label="Pause">⏸ Pause</button>
  <div id="prog" aria-hidden="true"><i></i></div>
</div>
<script>
const D = __DATA__;
const $ = id => document.getElementById(id);
const ease = p => p < .5 ? 4*p*p*p : 1 - Math.pow(-2*p + 2, 3) / 2;

// --- valeurs initiales de tout ce que la frise modifie (pour pouvoir revenir en arrière)
function lire(id, p){ const e=$(id); if(p==='text') return e.textContent; if(p==='display') return e.style.display; return e.getAttribute(p); }
function ecrire(id, p, v){ const e=$(id); if(!e) return; if(p==='text') e.textContent=v; else if(p==='display') e.style.display=v; else e.setAttribute(p, v); }
const init = {};
D.sets.forEach(([t,id,p]) => { const k=id+'|'+p; if(!(k in init)) init[k]=[id,p,lire(id,p)]; });
D.types.forEach(([s,d,id]) => { const k=id+'|text'; if(!(k in init)) init[k]=[id,'text',lire(id,'text')]; });
const EVTS = [...D.sets.map(([t,id,p,v]) => [t,'set',id,p,v]), ...D.types.map(([s,d,id,txt]) => [s,'type',d,id,txt])].sort((a,b) => a[0]-b[0]);
const ecransIds = [...new Set(D.screens.map(s => s[1]))];

function valeur(keys, t){
  if (t <= keys[0][0]) return keys[0][1];
  for (let i = 1; i < keys.length; i++){
    const [t1, v1] = keys[i];
    if (t <= t1){
      const [t0, v0] = keys[i-1];
      const p = t1 === t0 ? 1 : ease((t - t0) / (t1 - t0));
      return Array.isArray(v0) ? v0.map((a, j) => a + (v1[j] - a) * p) : v0 + (v1 - v0) * p;
    }
  }
  return keys[keys.length-1][1];
}

function rendu(t){
  Object.values(init).forEach(([id,p,v]) => ecrire(id,p,v));
  // écran affiché
  let ecran = null; D.screens.forEach(([ts,id]) => { if (ts <= t) ecran = id; });
  ecransIds.forEach(id => { const on = id === ecran; $(id).style.display = on ? '' : 'none'; $('h-'+id).style.display = on ? '' : 'none'; });
  // changements ponctuels et frappe au clavier, dans l'ordre chronologique
  for (const ev of EVTS){ if (ev[0] > t) break;
    if (ev[1] === 'set') ecrire(ev[2], ev[3], ev[4]);
    else { const [s,, d, id, txt] = ev; ecrire(id, 'text', txt.slice(0, Math.round(Math.min(1, (t - s) / d) * txt.length))); } }
  // pistes animées
  for (const tr of Object.values(D.tracks)){
    const v = valeur(tr.keys, t), e = $(tr.el); if (!e) continue;
    if (tr.kind==='ty') e.setAttribute('transform', `translate(0 ${-v})`);
    else if (tr.kind==='y') e.setAttribute('transform', `translate(0 ${v})`);
    else if (tr.kind==='tx') e.setAttribute('transform', `translate(${v} 0)`);
    else if (tr.kind==='op') e.setAttribute('opacity', v);
    else if (tr.kind==='r') e.setAttribute('r', v);
    else if (tr.kind==='dash') e.setAttribute('stroke-dashoffset', v);
    else if (tr.kind==='rot') e.setAttribute('transform', `rotate(${v} ${tr.cx} ${tr.cy})`);
    else if (tr.kind==='cursor') e.setAttribute('transform', `translate(${v[0]} ${v[1]})`);
  }
  // onde de clic
  const c = $('clic'); c.setAttribute('opacity', 0);
  D.clicks.forEach(([tc]) => { const p = (t - tc) / 0.45; if (p >= 0 && p <= 1){ c.setAttribute('r', 4 + 16*p); c.setAttribute('opacity', 1 - p); } });
  document.querySelector('#prog i').style.width = (100 * t / D.total) + '%';
}

let t = 0, lecture = true, avant = null;
const reduit = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
function boucle(ts){
  if (avant !== null && lecture){ t += (ts - avant) / 1000; if (t > D.total + 0.8) t = 0; }
  avant = ts; rendu(Math.min(t, D.total)); requestAnimationFrame(boucle);
}
function majBouton(){ $('lecture').textContent = lecture ? '⏸ Pause' : '▶ Lecture'; $('lecture').setAttribute('aria-label', lecture ? 'Pause' : 'Lecture'); }
let pauseVisiteur = false;   // le visiteur a mis en pause lui-même : la page ne relance pas
$('lecture').onclick = () => { lecture = !lecture; pauseVisiteur = !lecture; majBouton(); };
$('prog').onclick = e => { const r = e.currentTarget.getBoundingClientRect(); t = D.total * (e.clientX - r.left) / r.width; };
window.seek = s => { t = s; lecture = false; rendu(s); };   // utile pour les tests et l'intégration
if (reduit){ lecture = false; t = D.total; majBouton(); }   // image finale, sans mouvement
// Dans une iframe : on attend que la page dise « lecture » (animation visible à l'écran)
if (window.parent !== window && !reduit){ lecture = false; majBouton(); }
window.addEventListener('message', e => {
  if (e.origin !== location.origin) return;               // seulement les messages de son propre site
  if (e.data === 'pause'){ lecture = false; majBouton(); }
  else if (e.data === 'lecture' && !pauseVisiteur && !reduit){ lecture = true; majBouton(); }
});
requestAnimationFrame(boucle);
</script>
</body></html>
"""

if __name__ == "__main__":
    dossier = sys.argv[1]
    for kind in VARIANTES:
        with open(f"{dossier}/wireframe-{kind}.html", "w", encoding="utf-8") as f:
            f.write(page(kind))
        print("ok", kind)
