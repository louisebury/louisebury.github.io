# Générateurs des maquettes du site CV

Ces scripts Python fabriquent les maquettes et les éléments SVG. Ils ne font pas partie du site. Ils servent seulement si on doit redessiner quelque chose : il suffit alors de joindre ce dossier (zippé) à une conversation avec Claude.

| Fichier | Ce qu'il fabrique |
|---|---|
| scene/ (gen*.py, export_mvp*.py) | La scène d'accueil (bibliothèque, platine, décor, main néon d'origine) |
| storyboard.py | Storyboard de l'animation, planche des éléments, planche « page projet » (a besoin de scene/ et de mains.py) |
| mains.py | La main articulée (poses, phalanges, effet pression) |
| export_assets.py | Les éléments SVG du site : vue-dessus, disque, pochette, main, poses-main.json, main-pointe |
| wireframes.py | Les 3 wireframes animés Connect (avant, chargeur, transporteur) |
| gen_projet.py | La maquette de la page projet Connect |
