"""V6 accueil : bibliothèque et vinyles plus lisibles, décor réduit, sans palmier."""
import os, random
import gen as G
import gen2 as G2
import gen3 as G3
import gen4 as G4
from gen import svg, text, INK, BG, SURF, PINK
from gen2 import COULEURS

def scaled(content, s, ox, oy, id):
    """Réduit un groupe autour d'un point d'ancrage (ox, oy)."""
    return f'<g id="{id}" transform="translate({ox*(1-s):.1f} {oy*(1-s):.1f}) scale({s})">{content}</g>'

def meuble(x0=380, top=540, hover="vinyle-connect", seed=11):
    """Bibliothèque plus lisible : contour néon doux, casiers éclairés, tranches neutres plus sombres,
    vinyles cliquables plus larges avec halo de leur couleur."""
    rnd = random.Random(seed); pos = {}
    body = f'<rect x="{x0+4}" y="{top+14}" width="672" height="226" rx="3"/>'
    s = ('<g id="meuble">' + f'<rect x="{x0}" y="{top}" width="680" height="16" rx="3" fill="#2A1C40"/>'
         + f'<rect x="{x0+4}" y="{top+14}" width="672" height="226" rx="3" fill="#120B1F"/>'
         + G2.neon(f'<path d="M{x0} {top} H{x0+680}"/>' + body, "#C084FC", w=1.8)
         + G.line(f"M{x0+32} {top+240} L{x0+24} {top+262} M{x0+52} {top+240} L{x0+60} {top+262} M{x0+628} {top+240} L{x0+620} {top+262} M{x0+648} {top+240} L{x0+656} {top+262}", op=0.55, w=1.5)
         + '</g><g id="bibliotheque-vinyles">')
    sel = {c: i for c, i, _ in G.SELECTION}
    for c in range(8):
        col, row = c % 4, c // 4
        cx, cy = x0 + 12 + col * 168, top + 24 + row * 112
        s += (f'<g id="casier-{c+1}"><rect x="{cx}" y="{cy}" width="160" height="104" rx="3" fill="#1A1029" stroke="#C084FC" stroke-opacity="0.35"/>'
              f'<rect x="{cx+2}" y="{cy+2}" width="156" height="10" fill="#C084FC" fill-opacity="0.06"/>')
        x, k = cx + 6, 0; target = 3 + rnd.randrange(7) if c in sel else -1; hi = ""
        while x < cx + 150:
            if k == target:
                vid = sel[c]; hov = vid == hover; colr = COULEURS[vid]; y = cy + 6 - (8 if hov else 0)
                hi += (f'<g id="{vid}"><rect x="{x-8}" y="{y-6}" width="32" height="108" rx="10" fill="{colr}" fill-opacity="{0.4 if hov else 0.22}"/>'
                       f'<rect x="{x-3}" y="{y-2}" width="22" height="100" rx="6" fill="{colr}" fill-opacity="{0.35 if hov else 0.2}"/>'
                       f'<rect x="{x}" y="{y}" width="16" height="96" rx="2.5" fill="{colr}"/>'
                       f'<rect x="{x+3}" y="{y+6}" width="2" height="84" rx="1" fill="#FFFFFF" fill-opacity="0.45"/>'
                       + (f'<rect x="{x}" y="{y}" width="16" height="96" rx="2.5" fill="none" stroke="#FFFFFF" stroke-width="1.5"/>' if hov else "") + "</g>")
                pos[vid] = (x + 8, y); x += 18; k += 1; continue
            w = 5 + rnd.randrange(4)
            if x + w > cx + 154: break
            h = 84 + rnd.randrange(12)
            s += f'<rect x="{x}" y="{cy+100-h}" width="{w}" height="{h}" fill="{rnd.choice(["#1B1726", "#211C2E", "#181522", "#25203A"])}"/>'
            x += w + 1; k += 1
        s += "</g>" + hi
    return s + "</g>", pos

def accueil():
    m, pos = meuble()
    tipx, tipy = pos["vinyle-connect"]
    b = G3.mur() + G3.sol() + G3.fenetre(x=1120, y=220, w=150, h=126)
    b += G.lampe()
    b += scaled(G2.enceinte(250, "enceinte-gauche"), 0.78, 305, 780, "enceinte-gauche-reduite")
    b += scaled(G2.enceinte(1080, "enceinte-droite"), 0.78, 1135, 780, "enceinte-droite-reduite")
    b += scaled(G2.plante(185, 700), 0.7, 185, 780, "plante-sol-reduite")
    b += scaled(G2.fauteuil(), 0.75, 1440, 800, "fauteuil-reduit")
    b += scaled(G4.mur_pochettes(), 0.62, 720, 366, "mur-pochettes-reduit")
    b += m + G2.platine_face() + G2.ampli() + G2.casque() + G3.entete() + G.bouton_son() + G3.consigne()
    tx, ty = tipx - 140, tipy - 118
    b += (f'<g id="info-bulle"><rect x="{tx}" y="{ty}" width="290" height="64" rx="12" fill="{SURF}" fill-opacity="0.95" stroke="{PINK}" stroke-opacity="0.8" stroke-width="1.2"/>'
          f'<path d="M{tipx-8} {ty+64} L{tipx} {ty+74} L{tipx+8} {ty+64} Z" fill="{SURF}" stroke="{PINK}" stroke-opacity="0.8" stroke-width="1.2"/>'
          + text(tx + 16, ty + 27, "Lancement du produit Connect", 16, weight=700) + text(tx + 16, ty + 48, "Cliquer pour écouter ce projet", 13, op=0.65) + "</g>")
    b += G3.cursor(tipx, tipy + 4, s=0.32)
    return svg(1440, 900, b)

d = os.path.join(G.OUT, "v6"); os.makedirs(d, exist_ok=True)
open(os.path.join(d, "01-accueil.svg"), "w", encoding="utf-8").write(accueil())
print("v6 ok")
