"""Exporte les fichiers d'intégration du MVP : scène sans textes ni main, et main seule."""
import os
import gen as G, gen2 as G2, gen3 as G3, gen4 as G4, gen5 as G5, gen6 as G6
from gen import svg

def scene():
    m, _ = G5.meuble(hover=None)
    b = G3.mur() + G3.sol() + G3.fenetre(x=1095, y=200, w=190, h=160) + G.lampe()
    b += G5.scaled(G2.enceinte(250, "enceinte-gauche"), 0.78, 305, 780, "enceinte-gauche-reduite")
    b += G5.scaled(G2.enceinte(1080, "enceinte-droite"), 0.78, 1135, 780, "enceinte-droite-reduite")
    b += G5.scaled(G2.plante(185, 700), 0.7, 185, 780, "plante-sol-reduite")
    b += G5.scaled(G2.fauteuil(), 0.75, 1440, 800, "fauteuil-reduit")
    b += f'<g transform="translate(0 -22)">{G5.scaled(G4.mur_pochettes(), 0.66, 720, 366, "mur-pochettes-reduit")}</g>'
    b += m + G2.platine_face() + G2.ampli() + G2.casque()
    out = svg(1440, 900, b)
    for _, vid, titre in G.SELECTION:
        out = out.replace(f'<g id="{vid}">', f'<g id="{vid}" class="vinyle-cliquable" data-titre="{titre}">', 1)
    # les pochettes contiennent de petits textes décoratifs : on les garde, ce sont des images
    return out

def main():
    h = G3.hand(0, 0, s=1, pose="pointe", id="main-pointe")
    return f'<svg width="220" height="250" viewBox="-10 -10 220 250" xmlns="http://www.w3.org/2000/svg">{h}</svg>'

d = os.path.join(G.OUT, "mvp"); os.makedirs(d, exist_ok=True)
open(os.path.join(d, "scene-accueil.svg"), "w", encoding="utf-8").write(scene())
open(os.path.join(d, "main-pointe.svg"), "w", encoding="utf-8").write(main())
print("ok")
