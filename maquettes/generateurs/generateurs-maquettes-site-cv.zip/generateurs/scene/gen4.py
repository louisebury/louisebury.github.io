"""V5 accueil : mur de fausses pochettes sur étagères, plante tombante, lampe à lave animée."""
import os, random
import gen as G
import gen2 as G2
import gen3 as G3
from gen import svg, text, line, INK, BG, SURF, PINK, DARK
from gen2 import SOLEIL, BLEU, VIOLET, VNEON, ORANGE, VERT

G.DEFS = G.DEFS.replace("</defs>", """
<linearGradient id="gBoisClair" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#B98B62"/><stop offset="1" stop-color="#7A5638"/></linearGradient>
<linearGradient id="gVerre" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#FF4FA0"/><stop offset="0.5" stop-color="#FF8A6B"/><stop offset="1" stop-color="#7C5CFF"/></linearGradient>
<linearGradient id="gMetal" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#3B2A8C"/><stop offset="0.5" stop-color="#7C5CFF"/><stop offset="1" stop-color="#3B2A8C"/></linearGradient>
<radialGradient id="gHaloLave" cx="0.5" cy="0.5" r="0.5"><stop offset="0" stop-color="#FF4FA0" stop-opacity="0.45"/><stop offset="0.5" stop-color="#B23FE0" stop-opacity="0.15"/><stop offset="1" stop-color="#B23FE0" stop-opacity="0"/></radialGradient>
<linearGradient id="gNuitBleue" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#1E3A8A"/><stop offset="1" stop-color="#0B0B12"/></linearGradient>
</defs>""")

S = 76  # taille d'une pochette

def cover(i, x, y):
    """10 fausses pochettes : faux artistes, instruments, couleurs de la charte."""
    c = lambda dx, dy: (x + dx, y + dy)
    g = f'<g id="pochette-{i+1}">'
    def bg(fill): return f'<rect x="{x}" y="{y}" width="{S}" height="{S}" fill="{fill}"/>'
    def lab(artist, title, col=INK, op=1):
        return (text(x + 6, y + 12, artist.upper(), 7, fam="Tilt Neon", fill=col, op=op)
                + text(x + 6, y + S - 6, title, 6.5, fill=col, op=op * 0.8))
    if i == 0:   # saxophone
        g += bg("url(#gNuitBleue)")
        g += f'<path d="M{x+44} {y+16} V{y+44} Q{x+44} {y+60} {x+32} {y+60} Q{x+22} {y+60} {x+24} {y+50}" fill="none" stroke="{SOLEIL}" stroke-width="5" stroke-linecap="round"/>'
        g += f'<path d="M{x+44} {y+16} L{x+52} {y+12}" stroke="{SOLEIL}" stroke-width="2.5"/>' + lab("Lumen Ferry", "Nuit Bleue")
    elif i == 1:  # guitare
        g += bg(PINK)
        g += f'<circle cx="{x+32}" cy="{y+50}" r="13" fill="{INK}"/><circle cx="{x+40}" cy="{y+40}" r="10" fill="{INK}"/><circle cx="{x+34}" cy="{y+47}" r="3.5" fill="{PINK}"/>'
        g += f'<path d="M{x+42} {y+38} L{x+60} {y+18}" stroke="{DARK}" stroke-width="4" stroke-linecap="round"/>' + lab("Les Néons", "Électrique", DARK)
    elif i == 2:  # synthé
        g += bg(SURF)
        g += f'<rect x="{x+10}" y="{y+30}" width="56" height="22" rx="3" fill="{SOLEIL}"/>'
        g += "".join(f'<rect x="{x+12+k*6.6:.1f}" y="{y+40}" width="5.4" height="11" fill="{INK}"/>' for k in range(8))
        g += "".join(f'<circle cx="{x+16+k*10}" cy="{y+35}" r="2" fill="{DARK}"/>' for k in range(5)) + lab("Mira Kobalt", "Synthèse", SOLEIL)
    elif i == 3:  # micro
        g += bg(SOLEIL)
        g += f'<rect x="{x+32}" y="{y+18}" width="12" height="20" rx="6" fill="{DARK}"/><path d="M{x+28} {y+32} Q{x+38} {y+46} {x+48} {y+32} M{x+38} {y+42} V{y+58} M{x+30} {y+58} H{x+46}" fill="none" stroke="{DARK}" stroke-width="2.5" stroke-linecap="round"/>'
        g += lab("Odéon Club", "Live 84", DARK)
    elif i == 4:  # trompette
        g += bg(VIOLET)
        g += f'<path d="M{x+12} {y+40} H{x+50}" stroke="{INK}" stroke-width="4"/><path d="M{x+50} {y+32} L{x+64} {y+26} V{y+54} L{x+50} {y+48} Z" fill="{INK}"/>'
        g += "".join(f'<rect x="{x+24+k*7}" y="{y+30}" width="3" height="10" fill="{INK}"/>' for k in range(3)) + lab("Velours Trio", "Cuivres")
    elif i == 5:  # batterie
        g += bg(ORANGE)
        g += f'<circle cx="{x+38}" cy="{y+44}" r="16" fill="none" stroke="{DARK}" stroke-width="3"/><circle cx="{x+38}" cy="{y+44}" r="6" fill="{DARK}"/>'
        g += f'<path d="M{x+16} {y+22} L{x+30} {y+34} M{x+60} {y+22} L{x+46} {y+34}" stroke="{INK}" stroke-width="2.5" stroke-linecap="round"/>' + lab("Kick Club", "Tempo", DARK)
    elif i == 6:  # cassette
        g += bg("#0B0B12")
        g += f'<rect x="{x+12}" y="{y+26}" width="52" height="32" rx="4" fill="none" stroke="{BLEU}" stroke-width="2"/><circle cx="{x+28}" cy="{y+40}" r="5" fill="none" stroke="{PINK}" stroke-width="2"/><circle cx="{x+48}" cy="{y+40}" r="5" fill="none" stroke="{PINK}" stroke-width="2"/><path d="M{x+22} {y+52} H{x+54}" stroke="{BLEU}" stroke-width="1.5"/>'
        g += lab("Rue Pigalle", "Face B", BLEU)
    elif i == 7:  # piano
        g += bg(INK)
        g += "".join(f'<rect x="{x+10+k*8}" y="{y+26}" width="7" height="30" fill="#FFFFFF" stroke="{DARK}" stroke-width="0.8"/>' for k in range(7))
        g += "".join(f'<rect x="{x+15+k*8}" y="{y+26}" width="4" height="18" fill="{DARK}"/>' for k in (0, 1, 3, 4, 5)) + lab("Palais Rose", "Piano Bar", PINK)
    elif i == 8:  # violon / contrebasse
        g += bg("url(#gCiel)")
        g += f'<path d="M{x+38} {y+18} V{y+30}" stroke="{DARK}" stroke-width="3"/><path d="M{x+30} {y+30} Q{x+24} {y+40} {x+30} {y+44} Q{x+24} {y+52} {x+30} {y+60} H{x+46} Q{x+52} {y+52} {x+46} {y+44} Q{x+52} {y+40} {x+46} {y+30} Z" fill="{SOLEIL}"/>'
        g += f'<path d="M{x+38} {y+30} V{y+58}" stroke="{DARK}" stroke-width="1"/>' + lab("Halo Quartet", "Cordes")
    else:         # vinyle
        g += bg(VNEON)
        g += f'<circle cx="{x+40}" cy="{y+42}" r="22" fill="#0B0B12"/><circle cx="{x+40}" cy="{y+42}" r="15" fill="none" stroke="#33334A"/><circle cx="{x+40}" cy="{y+42}" r="7" fill="{SOLEIL}"/>'
        g += lab("Station 33", "Rotations")
    return g + f'<rect x="{x}" y="{y}" width="{S}" height="{S}" fill="none" stroke="#000" stroke-opacity="0.3"/></g>'

def lampe_lave(cx=452, base=366):
    """Lampe à lave : socle et capuchon violets métallisés, verre rose → orange → violet, bulles animées."""
    s = '<g id="lampe-a-lave">'
    s += (f'<ellipse id="halo-lave" cx="{cx}" cy="{base-60}" rx="95" ry="95" fill="url(#gHaloLave)">'
          '<animate attributeName="opacity" values="0.7;1;0.7" dur="4s" repeatCount="indefinite"/></ellipse>')
    s += f'<path id="socle-lave" d="M{cx-22} {base} H{cx+22} L{cx+12} {base-36} H{cx-12} Z" fill="url(#gMetal)"/>'
    s += f'<path id="verre" d="M{cx-14} {base-36} H{cx+14} L{cx+9} {base-96} H{cx-9} Z" fill="url(#gVerre)"/>'
    rnd = random.Random(2)
    s += '<g id="bulles-lave">'
    for k, (col, r, dur) in enumerate([(SOLEIL, 5, 6), (PINK, 4, 7.5), ("#FFE3F1", 3.2, 5), (SOLEIL, 3.6, 8)]):
        y0 = base - 42 - k * 12
        s += (f'<ellipse cx="{cx - 3 + k*2}" cy="{y0}" rx="{r}" ry="{r*1.25:.1f}" fill="{col}" fill-opacity="0.9">'
              f'<animate attributeName="cy" values="{base-42};{base-90};{base-42}" dur="{dur}s" begin="{-k*1.7:.1f}s" repeatCount="indefinite"/>'
              f'<animate attributeName="ry" values="{r*1.3:.1f};{r*0.9:.1f};{r*1.3:.1f}" dur="{dur/2}s" repeatCount="indefinite"/></ellipse>')
    for _ in range(14):
        s += f'<circle cx="{cx-8+rnd.random()*16:.1f}" cy="{base-92+rnd.random()*54:.1f}" r="0.7" fill="#FFFFFF" fill-opacity="0.8"/>'
    s += "</g>"
    s += f'<path id="capuchon-lave" d="M{cx-9} {base-96} H{cx+9} L{cx+5} {base-112} H{cx-5} Z" fill="url(#gMetal)"/>'
    s += f'<path d="M{cx-12} {base-38} L{cx-8} {base-92}" stroke="#FFFFFF" stroke-opacity="0.35" stroke-width="1.5"/>'
    return s + "</g>"

def plante_tombante(x=972, y=262):
    s = f'<g id="plante-tombante"><path d="M{x-16} {y-24} H{x+16} L{x+12} {y} H{x-12} Z" fill="#1A0F24"/>'
    s += G2.neon(f'<path d="M{x-16} {y-24} H{x+16} L{x+12} {y} H{x-12} Z"/>', ORANGE, w=1.6)
    vines = ""
    for k, (dx, ln) in enumerate([(-10, 120), (0, 160), (11, 95), (6, 135)]):
        vx = x + dx; pts = f"M{vx} {y-18} C{vx-14} {y+ln*0.3:.0f} {vx+14} {y+ln*0.6:.0f} {vx+(-4 if k%2 else 4)} {y+ln}"
        vines += f'<path d="{pts}"/>'
        for j in range(1, 7):
            ly = y - 10 + ln * j / 6.5; side = -1 if j % 2 else 1
            vines += f'<ellipse cx="{vx + side*6 + (2 if k%2 else -2)}" cy="{ly:.0f}" rx="5" ry="3" transform="rotate({side*30} {vx + side*6} {ly:.0f})"/>'
    for kx, ky in [(-14, -26), (-4, -32), (8, -30), (16, -24)]:
        vines += f'<ellipse cx="{x+kx}" cy="{y+ky}" rx="7" ry="4" transform="rotate({kx*3} {x+kx} {y+ky})"/>'
    s += f'<g fill="#0E2420">{vines}</g>' + G2.neon(vines, VERT, w=1.3)
    return s + "</g>"

def mur_pochettes():
    x0 = 720 - (5 * S + 4 * 14) / 2
    s = '<g id="mur-pochettes">'
    rows = [(178, x0 - 12, x0 + 5 * S + 4 * 14 + 70), (280, x0 - 90, x0 + 5 * S + 4 * 14 + 12)]
    i = 0
    for ry, lx0, lx1 in rows:
        for k in range(5):
            s += cover(i, x0 + k * (S + 14), ry); i += 1
        s += (f'<rect id="etagere-{ry}" x="{lx0}" y="{ry+S}" width="{lx1-lx0}" height="9" rx="2" fill="url(#gBoisClair)"/>'
              f'<rect x="{lx0}" y="{ry+S+9}" width="{lx1-lx0}" height="3" fill="#000" fill-opacity="0.35"/>')
    s += plante_tombante(x=x0 + 5 * S + 4 * 14 + 38, y=178 + S)
    s += lampe_lave(cx=x0 - 50, base=280 + S)
    return s + "</g>"

def accueil():
    m, pos = G2.meuble()
    tipx, tipy = pos["vinyle-connect"]
    b = G3.mur() + G3.sol() + G3.fenetre()
    b += f'<g id="neon-palmiers-petit" transform="translate(110 250) scale(0.6)">{G2.neon_palmiers(x=0, y=0)}</g>'
    b += G.lampe() + G2.enceinte(250, "enceinte-gauche") + G2.enceinte(1080, "enceinte-droite")
    b += G2.plante(185, 700) + G2.fauteuil() + mur_pochettes()
    b += m + G2.platine_face() + G2.ampli() + G2.casque() + G3.entete() + G.bouton_son() + G3.consigne()
    tx, ty = tipx - 140, tipy - 128
    b += (f'<g id="info-bulle"><rect x="{tx}" y="{ty}" width="290" height="64" rx="12" fill="{SURF}" fill-opacity="0.95" stroke="{PINK}" stroke-opacity="0.8" stroke-width="1.2"/>'
          f'<path d="M{tipx-8} {ty+64} L{tipx} {ty+74} L{tipx+8} {ty+64} Z" fill="{SURF}" stroke="{PINK}" stroke-opacity="0.8" stroke-width="1.2"/>'
          + text(tx + 16, ty + 27, "Lancement du produit Connect", 16, weight=700) + text(tx + 16, ty + 48, "Cliquer pour écouter ce projet", 13, op=0.65) + "</g>")
    b += G3.cursor(tipx, tipy + 4, s=0.4)
    return svg(1440, 900, b)

d = os.path.join(G.OUT, "v5"); os.makedirs(d, exist_ok=True)
open(os.path.join(d, "01-accueil.svg"), "w", encoding="utf-8").write(accueil())
print("v5 ok")
