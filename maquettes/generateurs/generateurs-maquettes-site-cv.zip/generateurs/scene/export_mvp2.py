"""Scène d'accueil avec mur, étoiles et sol prolongés hors du cadre (pour écrans larges)."""
import os, random
import gen as G, gen2 as G2, gen3 as G3, gen4 as G4, gen5 as G5, gen6 as G6
from gen import INK, PINK
import export_mvp as E

X0, W = -1300, 1440 + 2600   # le décor s'étend de -1300 à 2740

def mur_large(h=900, horizon=780):
    rnd = random.Random(21)
    s = f'<g id="mur"><rect x="{X0}" y="0" width="{W}" height="{h}" fill="url(#gMur)"/><g id="etoiles">'
    for _ in range(200):
        s += f'<circle cx="{X0 + rnd.random()*W:.0f}" cy="{rnd.random()*(horizon-80):.0f}" r="{0.5+rnd.random()*1.1:.1f}" fill="{INK}" fill-opacity="{0.2+rnd.random()*0.5:.2f}"/>'
    for cx, cy in [(560, 70), (930, 120), (1380, 60), (300, 430), (1400, 520), (-400, 150), (-900, 380), (1900, 110), (2400, 330)]:
        s += f'<path d="M{cx} {cy-6} V{cy+6} M{cx-6} {cy} H{cx+6}" stroke="{INK}" stroke-opacity="0.6" stroke-width="1.2" stroke-linecap="round"/>'
    return s + "</g></g>"

def sol_large(h=900, horizon=780):
    V = G2.VIOLET
    s = (f'<g id="sol"><linearGradient id="gSol3" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#22103E"/><stop offset="1" stop-color="#0B0B12"/></linearGradient>'
         f'<rect x="{X0}" y="{horizon}" width="{W}" height="{h-horizon}" fill="url(#gSol3)"/>')
    vx, vy = 720, horizon - 120
    s += '<g id="sol-lignes-fuyantes">'
    for x in range(-9000, 10500, 120):
        t = (horizon - vy) / (h - vy); x1 = vx + (x - vx) * t
        if X0 - 2000 < x1 < X0 + W + 2000:
            s += f'<path d="M{x1:.1f} {horizon} L{x} {h}" stroke="{V}" stroke-opacity="0.28" stroke-width="1"/>'
    s += '</g><g id="sol-lignes-defilantes">'
    n, dur = 7, 4
    for i in range(n):
        y = horizon + (i / n) ** 2 * (h - horizon)
        a = "".join(f'<animate attributeName="{att}" values="{horizon};{h}" dur="{dur}s" begin="{-i*dur/n:.2f}s" repeatCount="indefinite" calcMode="spline" keyTimes="0;1" keySplines="0.55 0 1 1"/>' for att in ("y1", "y2"))
        s += f'<line x1="{X0}" y1="{y:.1f}" x2="{X0+W}" y2="{y:.1f}" stroke="{V}" stroke-opacity="0.35" stroke-width="1">{a}</line>'
    s += '</g>' + f'<path d="M{X0} {horizon} H{X0+W}" stroke="{PINK}" stroke-opacity="0.6" stroke-width="1.5"/>'
    return s + "</g>"

G3.mur = mur_large; G3.sol = sol_large
out = E.scene().replace('<svg width="1440" height="900" viewBox="0 0 1440 900"', '<svg width="1440" height="900" viewBox="0 0 1440 900" overflow="visible"', 1)
open(os.path.join(G.OUT, "mvp", "scene-accueil.svg"), "w", encoding="utf-8").write(out)
# aperçu : on élargit le cadre pour vérifier les prolongements
prev = out.replace('viewBox="0 0 1440 900"', 'viewBox="-600 0 2640 900"', 1).replace('width="1440" height="900"', 'width="2640" height="900"', 1)
open("/tmp/prev.svg", "w").write(prev)
print("ok", out.count('class="vinyle-cliquable"'))
