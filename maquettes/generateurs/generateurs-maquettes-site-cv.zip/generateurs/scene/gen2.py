"""V3 des maquettes : plus de couleurs néon, main néon réaliste à 5 doigts, sol animé."""
import math, random, os
import gen as G
from gen import svg, text, line, INK, BG, SURF, PINK, DARK

SOLEIL = "#FFC46B"; BLEU = "#3B82F6"; VIOLET = "#8B5CF6"; VNEON = "#B23FE0"; ORANGE = "#FB8C80"; VERT = "#2DD4BF"

G.DEFS = G.DEFS.replace("</defs>", """
<linearGradient id="gSol2" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#7A2BD0"/><stop offset="0.35" stop-color="#3C1580"/><stop offset="1" stop-color="#14072A"/></linearGradient>
<linearGradient id="gHorizon" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#FF4FA0" stop-opacity="0.55"/><stop offset="1" stop-color="#FF4FA0" stop-opacity="0"/></linearGradient>
<linearGradient id="gCiel" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#2A0E5A"/><stop offset="0.55" stop-color="#7B2FBE"/><stop offset="1" stop-color="#FF4FA0"/></linearGradient>
<linearGradient id="gMer" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#6A24B8"/><stop offset="1" stop-color="#1A0838"/></linearGradient>
</defs>""")
DEFS = G.DEFS

def neon(shapes, color, core="#FFFFFF", w=3, fill="none", fill_op=0):
    """Effet tube néon : halo large + tube coloré + cœur clair. `shapes` = éléments sans attribut stroke."""
    def styled(sw, op, c, f="none", fo=0):
        return f'<g fill="{f}" fill-opacity="{fo}" stroke="{c}" stroke-opacity="{op}" stroke-width="{sw}" stroke-linecap="round" stroke-linejoin="round">{shapes}</g>'
    return (styled(w * 6, 0.12, color) + styled(w * 3, 0.25, color) + styled(w, 1, color, fill, fill_op)
            + styled(max(w * 0.35, 0.8), 0.75, core))

# ============================================================ MAIN néon réaliste (5 doigts)
def finger(bx, by, length, width, angle, knuckles=True):
    """Doigt effilé partant de (bx, by) vers le haut, incliné de `angle` degrés."""
    w0, w1 = width / 2, width * 0.42
    d = (f"M{-w0:.1f} 0 L{-w1:.1f} {-length + w1:.1f} A{w1:.1f} {w1:.1f} 0 0 1 {w1:.1f} {-length + w1:.1f} L{w0:.1f} 0")
    s = f'<path d="{d}"/>'
    if knuckles:
        for t in (0.38, 0.68):
            y = -length * t; k = w0 - (w0 - w1) * t
            s += f'<path d="M{-k*0.5:.1f} {y:.1f} Q0 {y-3:.1f} {k*0.5:.1f} {y:.1f}"/>'
    # ongle
    s += f'<path d="M{-w1*0.55:.1f} {-length + w1*1.1:.1f} Q0 {-length + w1*0.3:.1f} {w1*0.55:.1f} {-length + w1*1.1:.1f}"/>'
    return f'<g transform="translate({bx} {by}) rotate({angle})">{s}</g>'

def tip_of(bx, by, length, angle):
    a = math.radians(angle)
    return bx + length * math.sin(a), by - length * math.cos(a)

POSE = {
    # (doigts : base x, base y, longueur, largeur, angle), paume, poignet
    "ouverte": dict(fingers=[(76, 112, 74, 22, -10), (98, 106, 84, 22, -2), (120, 110, 78, 21, 6), (140, 120, 60, 19, 16), (66, 150, 60, 25, -58)]),
    "pointe": dict(fingers=[(78, 112, 100, 22, -2), (100, 110, 30, 22, 0), (121, 113, 28, 21, 4), (141, 120, 24, 19, 10), (68, 156, 54, 25, -38)]),
    "pince": dict(fingers=[(78, 112, 64, 22, 26), (100, 110, 30, 22, 2), (121, 113, 28, 21, 6), (141, 120, 24, 19, 12), (66, 152, 62, 25, -34)]),
}
PALM = "M66 112 Q60 160 72 196 L80 232 M146 232 L150 196 Q164 160 152 118"

def hand_shapes(pose):
    s = "".join(finger(*f) for f in POSE[pose]["fingers"])
    s += f'<path d="{PALM}"/>'
    s += '<path d="M90 176 Q108 186 128 172"/>'            # pli de la paume
    s += '<path d="M76 214 H150 M78 226 H148"/>'          # bracelet néon
    return s

def hand(x, y, s=0.4, pose="pointe", rot=0, id="main", halo=True, color=PINK):
    r = f" rotate({rot} 110 130)" if rot else ""
    body = ""
    if halo:
        body += f'<ellipse cx="110" cy="130" rx="95" ry="115" fill="{color}" fill-opacity="0.07"/>'
    # fond sombre pour que la main reste lisible devant le décor
    body += f'<g fill="#1A0F24" fill-opacity="0.85" stroke="none">{"".join(finger(*f, knuckles=False) for f in POSE[pose]["fingers"])}<path d="M66 112 Q60 160 72 196 L80 232 H146 L150 196 Q164 160 152 118 Z"/></g>'
    body += neon(hand_shapes(pose), color, core="#FFE3F1", w=3.2)
    return f'<g id="{id}" transform="translate({x} {y}) scale({s}){r}">{body}</g>'

def cursor(tipx, tipy, s=0.4, pose="pointe", id="main-curseur"):
    bx, by, L, _, a = POSE["pointe"]["fingers"][0]
    tx, ty = tip_of(bx, by, L, a)
    return hand(tipx - tx * s, tipy - ty * s, s, pose, id=id)

G.hand = hand; G.cursor = cursor

# ============================================================ NOM en tube néon (police Tilt Neon)
def nom(x, y, size):
    t = lambda extra: (f'<text x="{x}" y="{y}" font-family="Tilt Neon" font-size="{size}" {extra}>Louise Bury</text>')
    return ('<g id="nom">'
            + t(f'fill="none" stroke="{PINK}" stroke-opacity="0.18" stroke-width="{size*0.28:.0f}" stroke-linejoin="round"')
            + t(f'fill="none" stroke="{PINK}" stroke-width="{size*0.09:.1f}" stroke-linejoin="round"')
            + t(f'fill="none" stroke="{SOLEIL}" stroke-width="{size*0.025:.1f}" stroke-linejoin="round"')
            + "</g>")

def entete(nav=False, small=False):
    if small:
        return (nom(60, 66, 34) + text(62, 94, "Product Manager / Product Owner", 14, fam="Tilt Neon", op=0.75, id="sous-titre"))
    return (nom(80, 112, 72)
            + f'<text id="sous-titre" x="84" y="156" font-family="Tilt Neon" font-size="22" fill="{INK}" stroke="{INK}" stroke-opacity="0.15" stroke-width="5">Product Manager / Product Owner</text>')
G.entete = entete

# ============================================================ SOL contrasté et animé
def sol(w=1440, h=900, horizon=780, anim=True):
    s = f'<g id="sol"><rect x="0" y="{horizon}" width="{w}" height="{h-horizon}" fill="url(#gSol2)"/>'
    s += f'<rect x="0" y="{horizon}" width="{w}" height="40" fill="url(#gHorizon)"/>'
    vx, vy = w / 2, horizon - 120
    s += '<g id="sol-lignes-fuyantes">'
    for x in range(-2400, w + 2500, 120):
        t = (horizon - vy) / (h - vy); x1 = vx + (x - vx) * t
        s += f'<path d="M{x1:.1f} {horizon} L{x} {h}" stroke="#D45CFF" stroke-opacity="0.75" stroke-width="1.6"/>'
    s += '</g><g id="sol-lignes-defilantes">'
    n = 7; dur = 3.5
    for i in range(n):
        # position de départ statique (perspective) + animation vers le spectateur
        p = (i / n) ** 2; y = horizon + p * (h - horizon)
        anim_svg = (f'<animate attributeName="y1" values="{horizon};{h}" dur="{dur}s" begin="{-i*dur/n:.2f}s" repeatCount="indefinite" calcMode="spline" keyTimes="0;1" keySplines="0.55 0 1 1"/>'
                    f'<animate attributeName="y2" values="{horizon};{h}" dur="{dur}s" begin="{-i*dur/n:.2f}s" repeatCount="indefinite" calcMode="spline" keyTimes="0;1" keySplines="0.55 0 1 1"/>') if anim else ""
        s += f'<line x1="0" y1="{y:.1f}" x2="{w}" y2="{y:.1f}" stroke="#D45CFF" stroke-opacity="0.8" stroke-width="1.6">{anim_svg}</line>'
    s += '</g>'
    s += neon(f'<path d="M0 {horizon} H{w}"/>', PINK, w=2.5)
    return s + "</g>"

def mur(w=1440, h=900):
    rnd = random.Random(4)
    s = f'<g id="mur"><rect width="{w}" height="{h}" fill="url(#gMur)"/>'
    for _ in range(30):
        s += f'<circle cx="{rnd.random()*w:.0f}" cy="{rnd.random()*300:.0f}" r="{rnd.random()+0.5:.1f}" fill="{INK}" fill-opacity="{0.15+rnd.random()*0.3:.2f}"/>'
    return s + "</g>"

def piece_fond(w=1440, h=900, horizon=780):
    return mur(w, h) + sol(w, h, horizon)
G.piece_fond = piece_fond

# ============================================================ DÉCOR coloré
def fenetre(x=1010, y=190, w=320, h=280):
    cx, cy = x + w / 2, y + h * 0.58
    s = f'<g id="fenetre-sunset"><rect x="{x}" y="{y}" width="{w}" height="{h}" rx="10" fill="url(#gCiel)"/>'
    s += f'<g id="soleil"><circle cx="{cx}" cy="{cy}" r="{h*0.32:.0f}" fill="url(#gSun)"/>'
    for k, (dy, hh) in enumerate([(6, 4), (16, 6), (28, 8)]):
        s += f'<rect x="{cx-h*0.34:.0f}" y="{cy+dy:.0f}" width="{h*0.68:.0f}" height="{hh}" fill="#B23FE0"/>'
    hz = y + h * 0.72
    s += f'</g><rect x="{x}" y="{hz:.0f}" width="{w}" height="{y+h-hz:.0f}" fill="url(#gMer)"/>'
    for yy in [hz + d for d in (0, 8, 20, 38, 62)]:
        if yy < y + h: s += f'<path d="M{x} {yy:.0f} H{x+w}" stroke="{PINK}" stroke-opacity="0.8" stroke-width="1.2"/>'
    for xx in range(-200, w + 220, 40):
        tx, ty = x + xx, y + h + 60
        k = (y + h - hz) / (ty - hz); ex, ey = cx + (tx - cx) * k, y + h
        if ex < x: ey = hz + (ty - hz) * (x - cx) / (tx - cx); ex = x
        if ex > x + w: ey = hz + (ty - hz) * (x + w - cx) / (tx - cx); ex = x + w
        s += f'<path d="M{cx:.0f} {hz:.0f} L{ex:.1f} {ey:.1f}" stroke="{PINK}" stroke-opacity="0.6" stroke-width="1"/>'
    s += neon(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="10"/><path d="M{cx:.0f} {y} V{y+h} M{x} {y+h*0.42:.0f} H{x+w}"/>', "#7C5CFF", w=4)
    s += f'<rect x="{x-14}" y="{y+h}" width="{w+28}" height="10" rx="3" fill="#2A1C40"/>'  # rebord
    return s + "</g>"

def neon_palmiers(x=70, y=210):
    sun = f'<path d="M{x+40} {y+170} A110 110 0 1 1 {x+250} {y+130}"/>'
    lines = f'<path d="M{x+20} {y+200} H{x+120} M{x+170} {y+200} H{x+270} M{x+40} {y+216} H{x+250}"/>'
    def palm(px, py, hgt, sc=1):
        tr = f'<path d="M{px} {py} Q{px+12*sc} {py-hgt*0.5} {px+4*sc} {py-hgt}"/>'
        top = (px + 4 * sc, py - hgt)
        fr = "".join(f'<path d="M{top[0]} {top[1]} Q{top[0]+dx*0.5} {top[1]+dy*0.5-14*sc} {top[0]+dx} {top[1]+dy}"/>'
                     for dx, dy in [(-52*sc, 22*sc), (-40*sc, -18*sc), (0, -30*sc), (42*sc, -16*sc), (54*sc, 24*sc)])
        return tr + fr
    ile = f'<path d="M{x+60} {y+232} Q{x+150} {y+214} {x+240} {y+232}"/>'
    return ('<g id="neon-palmiers">' + neon(sun, ORANGE, w=3.5) + neon(lines, SOLEIL, w=3)
            + neon(palm(x + 110, y + 222, 150) + palm(x + 180, y + 226, 110, 0.75), PINK, w=3.5)
            + neon(ile, BLEU, w=3.5) + "</g>")

def boule_disco(cx=600, cy=200, r=40):
    s = '<g id="neon-boule-disco">' + neon(f'<path d="M{cx} 0 V{cy-r}"/>', INK, w=1.5)
    left = f'<path d="M{cx} {cy-r} A{r} {r} 0 0 0 {cx} {cy+r}"/><path d="M{cx-r} {cy} H{cx}"/><path d="M{cx-r*0.86:.1f} {cy-r*0.5:.1f} H{cx} M{cx-r*0.86:.1f} {cy+r*0.5:.1f} H{cx}"/><path d="M{cx} {cy-r} Q{cx-r*0.55:.1f} {cy} {cx} {cy+r}"/>'
    right = f'<path d="M{cx} {cy-r} A{r} {r} 0 0 1 {cx} {cy+r}"/><path d="M{cx} {cy} H{cx+r}"/><path d="M{cx} {cy-r*0.5:.1f} H{cx+r*0.86:.1f} M{cx} {cy+r*0.5:.1f} H{cx+r*0.86:.1f}"/><path d="M{cx} {cy-r} Q{cx+r*0.55:.1f} {cy} {cx} {cy+r}"/>'
    s += neon(left, BLEU, w=2.6) + neon(right, ORANGE, w=2.6)
    for dx, dy in [(-58, -10), (60, 14), (-46, 40), (52, -34)]:
        s += neon(f'<path d="M{cx+dx} {cy+dy-6} V{cy+dy+6} M{cx+dx-6} {cy+dy} H{cx+dx+6}"/>', SOLEIL, w=1.5)
    return s + "</g>"

def enceinte(x, id, op=None):
    shapes = (f'<rect x="{x}" y="560" width="110" height="220" rx="12"/>')
    s = f'<g id="{id}"><rect x="{x}" y="560" width="110" height="220" rx="12" fill="#120B1E"/>' + neon(shapes, BLEU, w=2.2)
    s += neon(f'<circle cx="{x+55}" cy="600" r="12"/>', SOLEIL, w=2)
    s += neon(f'<circle cx="{x+55}" cy="668" r="36"/>', PINK, w=2.4)
    s += neon(f'<circle cx="{x+55}" cy="668" r="16"/>', PINK, w=1.6)
    s += neon(f'<circle cx="{x+55}" cy="744" r="9"/>', BLEU, w=1.6)
    return s + "</g>"
G.enceinte = enceinte

def plante(cx, base, n=6, length=110, id="plante-sol", op=None, pot=True):
    s = f'<g id="{id}">'
    leaves = ""
    for i in range(n):
        a = -160 + i * (140 / (n - 1)) + 90
        leaves += (f'<g transform="rotate({a:.1f} {cx} {base})"><ellipse cx="{cx}" cy="{base-length/2}" rx="{length*0.2:.1f}" ry="{length/2}"/>'
                   f'<path d="M{cx} {base} V{base-length+10}"/></g>')
    s += f'<g fill="#0E2420">{leaves}</g>' + neon(leaves, VERT, w=2)
    if pot:
        p = f'<path d="M{cx-34} {base} H{cx+34} L{cx+26} {base+80} H{cx-26} Z"/>'
        s += f'<g fill="#1A0F24">{p}</g>' + neon(p, ORANGE, w=2.2)
    return s + "</g>"
G.plante = plante

def fauteuil(op=None):
    sh = ('<rect x="1220" y="600" width="260" height="190" rx="70"/><rect x="1250" y="730" width="230" height="64" rx="28"/>'
          '<rect x="1196" y="692" width="68" height="112" rx="34"/>')
    return f'<g id="fauteuil"><g fill="#1E1035">{sh}</g>' + neon(sh, VIOLET, w=2.2) + "</g>"
G.fauteuil = fauteuil

# ------------------------------------------------------------ fausses pochettes rétro néon (originales)
def pochettes(xc=720, y=290, size=110, gap=24, op=None):
    tot = 4 * size + 3 * gap; x0 = xc - tot / 2
    s = '<g id="mur-pochettes">' + neon(f'<path d="M{x0-30} {y+size+8} H{x0+tot+30}"/>', VIOLET, w=2)
    def cover(i, x):
        S = size; c = f'<g id="pochette-{i+1}"><rect x="{x}" y="{y}" width="{S}" height="{S}" fill="#120A20"/>'
        if i == 0:   # « Néon Riviera » : soleil + grille
            c += (f'<rect x="{x}" y="{y}" width="{S}" height="{S*0.62:.0f}" fill="url(#gCiel)"/><circle cx="{x+S/2}" cy="{y+S*0.55:.0f}" r="{S*0.24:.0f}" fill="url(#gSun)"/>'
                  f'<rect x="{x}" y="{y+S*0.62:.0f}" width="{S}" height="{S*0.38:.0f}" fill="#1A0838"/>')
            for k in range(1, 4): c += f'<path d="M{x} {y+S*0.62+k*k*3.5:.0f} H{x+S}" stroke="{PINK}" stroke-width="1"/>'
            for k in range(-3, 4): c += f'<path d="M{x+S/2} {y+S*0.62:.0f} L{x+S/2+k*30} {y+S}" stroke="{PINK}" stroke-width="1"/>'
            c += text(x + 8, y + 18, "NÉON RIVIERA", 11, fam="Tilt Neon", fill=INK)
        elif i == 1:  # « Disco Lune » : cercles concentriques
            c += f'<rect x="{x}" y="{y}" width="{S}" height="{S}" fill="{SOLEIL}"/>'
            for r in (40, 30, 20, 10): c += f'<circle cx="{x+S/2}" cy="{y+S/2+6}" r="{r}" fill="none" stroke="{PINK}" stroke-width="3"/>'
            c += text(x + 8, y + 18, "DISCO LUNE", 11, fam="Tilt Neon", fill=DARK)
        elif i == 2:  # « Pixel Drive » : route en perspective
            c += f'<rect x="{x}" y="{y}" width="{S}" height="{S}" fill="#0B0B12"/>'
            c += f'<path d="M{x+S/2-4} {y+40} L{x+10} {y+S} H{x+S-10} L{x+S/2+4} {y+40} Z" fill="#2A0E5A" stroke="{BLEU}" stroke-width="2"/>'
            for k in range(4): c += f'<rect x="{x+S/2-1.5}" y="{y+50+k*15}" width="3" height="{6+k*2}" fill="{SOLEIL}"/>'
            c += f'<path d="M{x} {y+40} H{x+S}" stroke="{PINK}" stroke-width="2"/>' + text(x + 8, y + 22, "PIXEL DRIVE", 11, fam="Tilt Neon", fill=BLEU)
        else:        # « Ondes FM » : ondes
            c += f'<rect x="{x}" y="{y}" width="{S}" height="{S}" fill="url(#gCiel)"/>'
            for k, col in enumerate([SOLEIL, ORANGE, PINK, INK]):
                yy = y + S*0.4 + k*S*0.13; c += f'<path d="M{x+S*0.07:.1f} {yy:.1f} Q{x+S*0.27:.1f} {yy-S*0.15:.1f} {x+S*0.5:.1f} {yy:.1f} T{x+S*0.93:.1f} {yy:.1f}" fill="none" stroke="{col}" stroke-width="3"/>'
            c += text(x + 8, y + 22, "ONDES FM", 11, fam="Tilt Neon", fill=INK)
        return c + f'<rect x="{x}" y="{y}" width="{S}" height="{S}" fill="none" stroke="{INK}" stroke-opacity="0.25"/></g>'
    for i in range(4):
        s += cover(i, x0 + i * (size + gap))
    return s + "</g>"
G.pochettes = pochettes

# ------------------------------------------------------------ meuble : un néon par vinyle
COULEURS = {"vinyle-connect": PINK, "vinyle-indice-prix": SOLEIL, "vinyle-benchmarks": BLEU,
            "vinyle-checkout-picard": VNEON, "vinyle-experiences": ORANGE, "vinyle-formations": VIOLET, "vinyle-contact": INK}

def meuble(x0=380, top=540, hover="vinyle-connect", seed=11):
    rnd = random.Random(seed); pos = {}
    s = ('<g id="meuble">' + f'<rect x="{x0}" y="{top}" width="680" height="16" rx="3" fill="#24173A"/>'
         + neon(f'<path d="M{x0} {top} H{x0+680}"/>', PINK, w=2)
         + f'<rect x="{x0+4}" y="{top+14}" width="672" height="226" fill="#100A1A" stroke="{INK}" stroke-opacity="0.3" stroke-width="1.5"/>'
         + line(f"M{x0+32} {top+240} L{x0+24} {top+262} M{x0+52} {top+240} L{x0+60} {top+262} M{x0+628} {top+240} L{x0+620} {top+262} M{x0+648} {top+240} L{x0+656} {top+262}", op=0.5, w=1.5)
         + '</g><g id="bibliotheque-vinyles">')
    sel = {c: i for c, i, _ in G.SELECTION}
    for c in range(8):
        col, row = c % 4, c // 4
        cx, cy = x0 + 12 + col * 168, top + 24 + row * 112
        s += f'<g id="casier-{c+1}"><rect x="{cx}" y="{cy}" width="160" height="104" rx="3" fill="none" stroke="{INK}" stroke-opacity="0.15"/>'
        x, k = cx + 6, 0; target = 3 + rnd.randrange(8) if c in sel else -1; hi = ""
        while x < cx + 150:
            if k == target:
                vid = sel[c]; hov = vid == hover; colr = COULEURS[vid]; y = cy + 6 - (8 if hov else 0)
                hi += (f'<g id="{vid}"><rect x="{x-5}" y="{y-5}" width="22" height="106" rx="7" fill="{colr}" fill-opacity="{0.35 if hov else 0.16}"/>'
                       f'<rect x="{x}" y="{y}" width="12" height="96" rx="2" fill="{colr}"/>'
                       + (f'<rect x="{x}" y="{y}" width="12" height="96" rx="2" fill="none" stroke="#FFFFFF" stroke-width="1.5"/>' if hov else "") + "</g>")
                pos[vid] = (x + 6, y); x += 14; k += 1; continue
            w = 5 + rnd.randrange(4)
            if x + w > cx + 154: break
            h = 84 + rnd.randrange(12)
            s += f'<rect x="{x}" y="{cy+100-h}" width="{w}" height="{h}" fill="{rnd.choice(["#221E30", "#2A2539", "#1D1A29", "#2F2940"])}"/>'
            x += w + 1; k += 1
        s += "</g>" + hi
    return s + "</g>", pos
G.meuble = meuble

# ------------------------------------------------------------ platine mise en valeur (vue 3/4, disque visible)
def platine_face(x=600, y=514):
    cx, cy = x + 100, y - 20
    s = f'<g id="platine-meuble"><ellipse cx="{x+120}" cy="{y+26}" rx="190" ry="14" fill="{PINK}" fill-opacity="0.22"/>'
    s += f'<path id="capot-meuble" d="M{x+12} {y-36} L{x+24} {y-90} L{x+216} {y-90} L{x+228} {y-36} Z" fill="{INK}" fill-opacity="0.05" stroke="{INK}" stroke-opacity="0.45" stroke-width="1.5"/>'
    top = f'<path d="M{x+10} {y-36} H{x+230} L{x+240} {y} H{x} Z"/>'
    s += f'<g fill="#241A36">{top}</g>' + neon(top, PINK, w=2)
    front = f'<rect x="{x}" y="{y}" width="240" height="26" rx="4"/>'
    s += f'<g fill="#1A1426">{front}</g>' + neon(front, PINK, w=2)
    s += f'<g id="vinyle-platine"><ellipse cx="{cx}" cy="{cy}" rx="84" ry="15" fill="#0E0E16" stroke="{PINK}" stroke-opacity="0.9" stroke-width="2"/>'
    for r in (72, 60, 48): s += f'<ellipse cx="{cx}" cy="{cy}" rx="{r}" ry="{r*15/84:.1f}" fill="none" stroke="#3A3A52" stroke-width="1"/>'
    s += f'<ellipse cx="{cx}" cy="{cy}" rx="28" ry="5" fill="url(#gSun)"/><circle cx="{cx}" cy="{cy}" r="1.6" fill="{INK}"/></g>'
    s += neon(f'<path d="M{x+212} {y-28} L{x+196} {y-14} L{x+160} {y-20}"/>', INK, w=1.8)
    s += f'<circle cx="{x+212}" cy="{y-28}" r="5" fill="{SOLEIL}"/><circle cx="{x+22}" cy="{y+13}" r="4" fill="{BLEU}"/>'
    s += f'<rect x="{x+180}" y="{y+8}" width="20" height="10" rx="2" fill="{PINK}"/><rect x="{x+206}" y="{y+8}" width="20" height="10" rx="2" fill="none" stroke="{PINK}"/>'
    return s + "</g>"
G.platine_face = platine_face

def ampli(x=868, y=508):
    return (f'<g id="ampli"><rect x="{x}" y="{y}" width="92" height="32" rx="4" fill="#120B1E"/>' + neon(f'<rect x="{x}" y="{y}" width="92" height="32" rx="4"/>', SOLEIL, w=1.6)
            + f'<rect x="{x+10}" y="{y+8}" width="28" height="16" rx="2" fill="{SOLEIL}" fill-opacity="0.85"/>'
            + f'<circle cx="{x+56}" cy="{y+16}" r="6" fill="none" stroke="{SOLEIL}"/><circle cx="{x+76}" cy="{y+16}" r="6" fill="none" stroke="{SOLEIL}"/></g>')
G.ampli = ampli

def casque(x=1012, y=488):
    sh = (f'<path d="M{x} {y} V{y+52} M{x-10} {y+52} H{x+10}"/><path d="M{x-22} {y+28} A22 22 0 0 1 {x+22} {y+28}"/>'
          f'<rect x="{x-30}" y="{y+20}" width="12" height="22" rx="5"/><rect x="{x+18}" y="{y+20}" width="12" height="22" rx="5"/>')
    return '<g id="casque">' + neon(sh, BLEU, w=2) + "</g>"
G.casque = casque

def consigne():
    t = "Survolez un vinyle lumineux pour découvrir un projet"
    return (f'<g id="consigne"><rect x="430" y="828" width="580" height="46" rx="23" fill="#0B0B12" fill-opacity="0.75" stroke="{PINK}" stroke-opacity="0.5"/>'
            f'<text x="720" y="858" font-family="Tilt Neon" font-size="22" text-anchor="middle" fill="none" stroke="{PINK}" stroke-opacity="0.3" stroke-width="6">{t}</text>'
            f'<text x="720" y="858" font-family="Tilt Neon" font-size="22" text-anchor="middle" fill="{INK}">{t}</text></g>')

# ============================================================ ACCUEIL v3
def accueil():
    m, pos = meuble()
    tipx, tipy = pos["vinyle-connect"]
    b = piece_fond() + fenetre() + neon_palmiers() + boule_disco() + G.lampe()
    b += enceinte(250, "enceinte-gauche") + enceinte(1080, "enceinte-droite")
    b += plante(185, 700) + fauteuil() + pochettes()
    b += m + platine_face() + ampli() + casque() + entete() + G.bouton_son() + consigne()
    tx, ty = tipx - 140, tipy - 128
    b += (f'<g id="info-bulle"><rect x="{tx}" y="{ty}" width="290" height="64" rx="12" fill="{SURF}" fill-opacity="0.95" stroke="{PINK}" stroke-width="1.5"/>'
          f'<path d="M{tipx-8} {ty+64} L{tipx} {ty+74} L{tipx+8} {ty+64} Z" fill="{SURF}" stroke="{PINK}" stroke-width="1.5"/>'
          + text(tx + 16, ty + 27, "Lancement du produit Connect", 16, weight=700) + text(tx + 16, ty + 48, "Cliquer pour écouter ce projet", 13, op=0.65) + "</g>")
    b += cursor(tipx, tipy + 4, s=0.42)
    return svg(1440, 900, b)

def curseurs():
    b = f'<rect width="640" height="260" fill="{BG}"/>'
    for i, (pose, lbl) in enumerate([("pointe", "repos / survol"), ("pince", "clic, saisie"), ("ouverte", "scratch")]):
        x = 40 + i * 200
        b += hand(x + 20, 20, s=0.75, pose=pose, id=f"curseur-{pose}", halo=True)
        b += text(x + 102, 240, lbl, 13, op=0.75, anchor="middle")
    return svg(640, 260, b)

FILES = {
    "01-accueil.svg": accueil(),
    "02-projet-contexte.svg": G.projet_contexte(),
    "03-projet-problematique.svg": G.projet_problematique(),
    "04-projet-realisations.svg": G.projet_realisations(),
    "05-storyboard-main.svg": G.storyboard(),
    "06-main-neon.svg": curseurs(),
}
os.makedirs(os.path.join(G.OUT, "v3"), exist_ok=True)
for n, c in FILES.items():
    with open(os.path.join(G.OUT, "v3", n), "w", encoding="utf-8") as f:
        f.write(c)
print("ok")
