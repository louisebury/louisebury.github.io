"""V4 : accueil plus sobre, main blanche cerclée de néon, écrans projet vus du dessus."""
import os, random
import gen as G
import gen2 as G2
from gen import svg, text, line, INK, BG, SURF, PINK, DARK
from gen2 import SOLEIL, BLEU, VIOLET, VNEON, ORANGE, VERT, POSE, finger, tip_of

# ---------------------------------------------------------------- néons plus doux
def neon(shapes, color, core="#FFFFFF", w=3, fill="none", fill_op=0):
    def st(sw, op, c):
        return f'<g fill="none" stroke="{c}" stroke-opacity="{op}" stroke-width="{sw}" stroke-linecap="round" stroke-linejoin="round">{shapes}</g>'
    return st(w * 5, 0.06, color) + st(w * 2.4, 0.14, color) + st(w, 0.95, color) + st(max(w * 0.3, 0.7), 0.5, core)
G2.neon = neon

# ---------------------------------------------------------------- main : gant blanc + contour néon rose
PALM_FILL = "M66 112 Q60 160 72 196 L80 232 H146 L150 196 Q164 160 152 118 Z"
PALM_LINE = "M66 112 Q60 160 72 196 L80 232 M146 232 L150 196 Q164 160 152 118"

def hand(x, y, s=0.4, pose="pointe", rot=0, id="main", halo=True, color=PINK, op=1):
    r = f" rotate({rot} 110 130)" if rot else ""
    fingers_plain = "".join(finger(*f, knuckles=False) for f in POSE[pose]["fingers"])
    outline = fingers_plain + f'<path d="{PALM_LINE}"/><path d="M76 214 H150 M78 226 H148"/>'
    b = ""
    if halo:
        b += f'<ellipse cx="110" cy="130" rx="100" ry="118" fill="{color}" fill-opacity="0.06"/>'
    b += f'<g fill="none" stroke="{color}" stroke-linecap="round" stroke-linejoin="round">'
    b += f'<g stroke-opacity="0.12" stroke-width="26">{outline}</g><g stroke-opacity="0.3" stroke-width="15">{outline}</g><g stroke-width="8">{outline}</g></g>'
    b += f'<path id="paume" d="{PALM_FILL}" fill="{INK}"/>'
    b += f'<g id="doigts" fill="{INK}" stroke="{DARK}" stroke-width="2.5" stroke-linejoin="round">{fingers_plain}</g>'
    det = "".join(finger(*f, knuckles=True) for f in POSE[pose]["fingers"])
    b += f'<g fill="none" stroke="{DARK}" stroke-opacity="0.55" stroke-width="2" stroke-linecap="round">{det}<path d="M90 176 Q108 186 128 172"/></g>'
    b += f'<path d="{PALM_LINE}" fill="none" stroke="{DARK}" stroke-width="2.5"/>'
    b += f'<g id="bracelet"><rect x="78" y="208" width="70" height="24" rx="6" fill="{color}"/><path d="M84 220 H142" stroke="{INK}" stroke-opacity="0.8" stroke-width="2"/></g>'
    return f'<g id="{id}" opacity="{op}" transform="translate({x} {y}) scale({s}){r}">{b}</g>'

def cursor(tipx, tipy, s=0.4, pose="pointe", id="main-curseur"):
    bx, by, L, _, a = POSE["pointe"]["fingers"][0]
    tx, ty = tip_of(bx, by, L, a)
    return hand(tipx - tx * s, tipy - ty * s, s, pose, id=id)
G.hand = G2.hand = hand; G.cursor = G2.cursor = cursor

# ---------------------------------------------------------------- nom en Monoton
def nom(x, y, size):
    t = lambda extra: f'<text x="{x}" y="{y}" font-family="Monoton" font-size="{size}" {extra}>Louise Bury</text>'
    return ('<g id="nom">' + t(f'fill="none" stroke="{PINK}" stroke-opacity="0.15" stroke-width="{size*0.12:.0f}"')
            + t('fill="url(#gNom)"') + "</g>")

def entete(nav=False, small=False):
    if small:
        return nom(56, 66, 30) + text(58, 92, "Product Manager / Product Owner", 14, fam="Tilt Neon", op=0.7, id="sous-titre")
    return nom(76, 112, 64) + text(80, 154, "Product Manager / Product Owner", 22, fam="Tilt Neon", op=0.9, id="sous-titre")
G.entete = G2.entete = entete

# ---------------------------------------------------------------- fond étoilé + sol sobre
def mur(w=1440, h=900, horizon=780):
    rnd = random.Random(21)
    s = f'<g id="mur"><rect width="{w}" height="{h}" fill="url(#gMur)"/><g id="etoiles">'
    for _ in range(70):
        s += f'<circle cx="{rnd.random()*w:.0f}" cy="{rnd.random()*(horizon-80):.0f}" r="{0.5+rnd.random()*1.1:.1f}" fill="{INK}" fill-opacity="{0.2+rnd.random()*0.5:.2f}"/>'
    for cx, cy in [(560, 70), (930, 120), (1380, 60), (300, 430), (1400, 520)]:
        s += f'<path d="M{cx} {cy-6} V{cy+6} M{cx-6} {cy} H{cx+6}" stroke="{INK}" stroke-opacity="0.6" stroke-width="1.2" stroke-linecap="round"/>'
    return s + "</g></g>"

def sol(w=1440, h=900, horizon=780):
    s = (f'<g id="sol"><linearGradient id="gSol3" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#22103E"/><stop offset="1" stop-color="#0B0B12"/></linearGradient>'
         f'<rect x="0" y="{horizon}" width="{w}" height="{h-horizon}" fill="url(#gSol3)"/>')
    vx, vy = w / 2, horizon - 120
    s += '<g id="sol-lignes-fuyantes">'
    for x in range(-2400, w + 2500, 120):
        t = (horizon - vy) / (h - vy); x1 = vx + (x - vx) * t
        s += f'<path d="M{x1:.1f} {horizon} L{x} {h}" stroke="{VIOLET}" stroke-opacity="0.28" stroke-width="1"/>'
    s += '</g><g id="sol-lignes-defilantes">'
    n, dur = 7, 4
    for i in range(n):
        y = horizon + (i / n) ** 2 * (h - horizon)
        a = "".join(f'<animate attributeName="{att}" values="{horizon};{h}" dur="{dur}s" begin="{-i*dur/n:.2f}s" repeatCount="indefinite" calcMode="spline" keyTimes="0;1" keySplines="0.55 0 1 1"/>' for att in ("y1", "y2"))
        s += f'<line x1="0" y1="{y:.1f}" x2="{w}" y2="{y:.1f}" stroke="{VIOLET}" stroke-opacity="0.35" stroke-width="1">{a}</line>'
    s += '</g>' + f'<path d="M0 {horizon} H{w}" stroke="{PINK}" stroke-opacity="0.6" stroke-width="1.5"/>'
    return s + "</g>"

# ---------------------------------------------------------------- pochettes sobres (originales)
def pochettes(xc=720, y=200, size=104, gap=28):
    tot = 4 * size + 3 * gap; x0 = xc - tot / 2
    s = '<g id="mur-pochettes">' + line(f"M{x0-30} {y+size+8} H{x0+tot+30}", op=0.45, w=1.5)
    for i in range(4):
        x = x0 + i * (size + gap); S = size; cx, cy = x + S / 2, y + S / 2
        c = f'<g id="pochette-{i+1}"><rect x="{x}" y="{y}" width="{S}" height="{S}" fill="{SURF}" stroke="{INK}" stroke-opacity="0.18"/>'
        if i == 0:   # anneaux fins
            for r in (34, 26, 18, 10): c += f'<circle cx="{cx}" cy="{cy+4}" r="{r}" fill="none" stroke="{PINK}" stroke-opacity="{0.4+r/80:.2f}" stroke-width="1.2"/>'
            lbl, col = "ANNEAUX", PINK
        elif i == 1:  # trois diagonales
            for k in range(3): c += f'<path d="M{x+20+k*18} {y+S-18} L{x+S-40+k*18} {y+30}" stroke="{SOLEIL}" stroke-width="2"/>'
            lbl, col = "TRIO", SOLEIL
        elif i == 2:  # carré dans carré
            c += f'<rect x="{cx-28}" y="{cy-22}" width="56" height="56" fill="none" stroke="{BLEU}" stroke-width="1.5"/><rect x="{cx-14}" y="{cy-8}" width="28" height="28" fill="{BLEU}" fill-opacity="0.8"/>'
            lbl, col = "CADRE", BLEU
        else:         # une onde
            c += f'<path d="M{x+12} {cy+6} Q{x+S*0.3:.0f} {cy-22} {cx} {cy+6} T{x+S-12} {cy+6}" fill="none" stroke="{VIOLET}" stroke-width="2"/>'
            lbl, col = "ONDE", VIOLET
        c += text(x + 10, y + 18, lbl, 10, fam="Tilt Neon", fill=col, op=0.9)
        s += c + "</g>"
    return s + "</g>"

# ---------------------------------------------------------------- décor allégé
def fenetre(x=1090, y=200, w=200, h=170):
    cx, cy = x + w / 2, y + h * 0.6
    s = f'<g id="fenetre-sunset"><rect x="{x}" y="{y}" width="{w}" height="{h}" rx="8" fill="url(#gCiel)"/>'
    s += f'<g id="soleil"><circle cx="{cx}" cy="{cy}" r="{h*0.3:.0f}" fill="url(#gSun)"/>'
    for dy, hh in [(5, 3), (12, 4), (21, 5)]:
        s += f'<rect x="{cx-h*0.32:.0f}" y="{cy+dy:.0f}" width="{h*0.64:.0f}" height="{hh}" fill="#B23FE0"/>'
    hz = y + h * 0.74
    s += f'</g><rect x="{x}" y="{hz:.0f}" width="{w}" height="{y+h-hz:.0f}" fill="url(#gMer)"/>'
    for yy in (hz, hz + 7, hz + 18, hz + 34):
        if yy < y + h: s += f'<path d="M{x} {yy:.0f} H{x+w}" stroke="{PINK}" stroke-opacity="0.6" stroke-width="1"/>'
    s += f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="8" fill="none" stroke="#7C5CFF" stroke-width="3"/>'
    s += f'<path d="M{cx:.0f} {y} V{y+h} M{x} {y+h*0.42:.0f} H{x+w}" stroke="#7C5CFF" stroke-width="2.5"/>'
    s += f'<rect x="{x-10}" y="{y+h}" width="{w+20}" height="8" rx="3" fill="#2A1C40"/>'
    return s + "</g>"

def palmiers():
    return f'<g id="neon-palmiers-petit" transform="translate(40 200) scale(0.6)">{G2.neon_palmiers(x=0, y=0)}</g>'

def consigne():
    t = "Survolez un vinyle lumineux pour découvrir un projet"
    return (f'<g id="consigne"><rect x="440" y="830" width="560" height="44" rx="22" fill="{BG}" fill-opacity="0.8" stroke="{INK}" stroke-opacity="0.2"/>'
            f'<text x="720" y="859" font-family="Tilt Neon" font-size="21" text-anchor="middle" fill="{INK}">{t}</text></g>')

# ================================================================ ACCUEIL v4
def accueil():
    m, pos = G2.meuble()
    tipx, tipy = pos["vinyle-connect"]
    b = mur() + sol() + fenetre() + palmiers() + G.lampe()
    b += G2.enceinte(250, "enceinte-gauche") + G2.enceinte(1080, "enceinte-droite")
    b += G2.plante(185, 700) + G2.fauteuil() + pochettes()
    b += m + G2.platine_face() + G2.ampli() + G2.casque() + entete() + G.bouton_son() + consigne()
    tx, ty = tipx - 140, tipy - 128
    b += (f'<g id="info-bulle"><rect x="{tx}" y="{ty}" width="290" height="64" rx="12" fill="{SURF}" fill-opacity="0.95" stroke="{PINK}" stroke-opacity="0.8" stroke-width="1.2"/>'
          f'<path d="M{tipx-8} {ty+64} L{tipx} {ty+74} L{tipx+8} {ty+64} Z" fill="{SURF}" stroke="{PINK}" stroke-opacity="0.8" stroke-width="1.2"/>'
          + text(tx + 16, ty + 27, "Lancement du produit Connect", 16, weight=700) + text(tx + 16, ty + 48, "Cliquer pour écouter ce projet", 13, op=0.65) + "</g>")
    b += cursor(tipx, tipy + 4, s=0.6)
    return svg(1440, 900, b)

# ================================================================ PROJET v4 : vue du dessus, platine en fond
def support_dessus(w=1440, h=900):
    """Le dessus du meuble vu d'en haut : plateau sombre, fines veines, bord avant néon."""
    rnd = random.Random(8)
    s = f'<g id="support-meuble"><rect width="{w}" height="{h}" fill="#0E0A16"/>'
    for i in range(28):
        y = 20 + i * 32 + rnd.random() * 10
        s += f'<path d="M0 {y:.0f} C{w*0.3:.0f} {y-6:.0f} {w*0.6:.0f} {y+8:.0f} {w} {y:.0f}" stroke="#2A1F3D" stroke-opacity="0.5" stroke-width="1" fill="none"/>'
    s += f'<rect x="0" y="0" width="{w}" height="{h}" fill="url(#gVignette)"/>'
    return s + "</g>"

VIGNETTE = ('<radialGradient id="gVignette" cx="0.3" cy="0.5" r="0.9"><stop offset="0.4" stop-color="#0B0B12" stop-opacity="0"/>'
            '<stop offset="1" stop-color="#0B0B12" stop-opacity="0.85"/></radialGradient>'
            '<linearGradient id="gVoile" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#0B0B12" stop-opacity="0"/>'
            '<stop offset="0.35" stop-color="#0B0B12" stop-opacity="0.55"/><stop offset="1" stop-color="#0B0B12" stop-opacity="0.8"/></linearGradient>')
G.DEFS = G.DEFS.replace("</defs>", VIGNETTE + "</defs>")

def projet_fond(hand_state="scratch", plat_op=0.42):
    b = support_dessus()
    px, py, sc = -60, 150, 1.32          # grande platine, coupée à gauche : elle sert de décor
    cx, cy = px + 240 * sc, py + 220 * sc
    b += f'<g id="platine-fond" opacity="{plat_op}">{G.platine(px, py, sc, capot="aucun", bras="pose")}</g>'
    if hand_state == "scratch":
        b += hand(cx + 120, cy - 60, s=0.55, pose="ouverte", rot=-30, id="main", op=0.6)
        b += f'<path d="M{cx+160} {cy-210} A250 250 0 0 1 {cx+250} {cy-40}" stroke="{PINK}" stroke-opacity="0.45" stroke-width="2" fill="none"/>'
    else:
        b += hand(cx - 300, cy + 170, s=0.5, pose="ouverte", rot=-20, id="main", op=0.35)
    b += f'<rect width="1440" height="900" fill="url(#gVoile)"/>'   # voile pour faire passer le texte devant
    b += entete(small=True) + G.bouton_son()
    b += text(56, 122, "↑ Remonter tout en haut pour revenir à la bibliothèque", 12, op=0.5, id="retour")
    return b

def progression(active):
    s = '<g id="progression">'
    for i, lbl in enumerate(["Contexte", "Problématique", "Réalisations"]):
        y = 66 + i * 0; x = 1000 + i * 130; on = i == active
        s += f'<circle cx="{x}" cy="60" r="{4.5 if on else 3.5}" fill="{PINK if on else INK}" fill-opacity="{1 if on else 0.35}"/>'
        s += text(x + 12, 65, lbl, 13, weight=700 if on else 400, op=1 if on else 0.45)
    return s + "</g>"

CX = 560; CW = 800    # colonne de contenu, plus large

def titre(y=200):
    return (text(CX, y, "Face A · 33 tours", 26, fam="Neonderthaw", fill=SOLEIL, id="face")
            + text(CX, y + 54, "Lancement du produit Connect", 46, fam="Tilt Neon", id="titre-projet")
            + text(CX, y + 86, "[Entreprise] · [Années] · [Rôle]", 15, op=0.6))

def para(x, y, lines, size=18, lh=30, op=0.88):
    return "".join(text(x, y + i * lh, l, size, op=op) for i, l in enumerate(lines))

def projet_contexte():
    b = projet_fond() + progression(0) + titre()
    b += text(CX, 360, "Contexte", 28, fam="Tilt Neon", fill=PINK)
    b += para(CX, 404, ["[2 à 3 phrases : l'entreprise, le produit, l'équipe.",
                        "Pourquoi ce projet existait, pour quels utilisateurs.",
                        "Ton rôle et ton périmètre en une phrase.]",
                        "",
                        "[Paragraphe 2 si besoin : le marché, la cible, le calendrier.]"])
    for i, t in enumerate(["B2B Transport", "Lancement produit", "Discovery"]):
        x = CX + i * 170
        b += f'<rect x="{x}" y="580" width="156" height="34" rx="17" fill="{BG}" fill-opacity="0.6" stroke="{INK}" stroke-opacity="0.3"/>' + text(x + 78, 602, t, 13, op=0.8, anchor="middle")
    b += text(CX, 846, "Défiler ↓ pour la problématique", 13, op=0.5)
    return svg(1440, 900, b)

def carte(x, y, w, h, inner):
    return (f'<g><rect x="{x}" y="{y}" width="{w}" height="{h}" rx="18" fill="{SURF}" fill-opacity="0.72" stroke="{INK}" stroke-opacity="0.14"/>'
            f'<rect x="{x}" y="{y}" width="4" height="{h}" rx="2" fill="{PINK}" fill-opacity="0.8"/>{inner}</g>')

def projet_problematique():
    b = projet_fond() + progression(1) + titre(y=150)
    x, y, w, h = CX, 290, CW, 470
    inner = text(x + 36, y + 58, "Problématique", 30, fam="Tilt Neon", fill=PINK)
    inner += para(x + 36, y + 102, ["[Le problème métier à résoudre, en 2 à 3 phrases.]",
                                    "[Ce que ça coûtait : temps perdu, clients, chiffre d'affaires…]",
                                    "[Les contraintes : délais, technique, organisation.]"])
    for i, (val, lbl) in enumerate([("[XX] %", "indicateur 1"), ("[X] sem.", "indicateur 2"), ("[X] k", "indicateur 3")]):
        bx = x + 36 + i * 250
        inner += (f'<rect x="{bx}" y="{y+250}" width="226" height="150" rx="14" fill="{BG}" fill-opacity="0.5" stroke="{INK}" stroke-opacity="0.15"/>'
                  + text(bx + 22, y + 318, val, 40, fam="Tilt Neon", fill="url(#gNom)")
                  + text(bx + 22, y + 352, lbl, 14, op=0.7) + text(bx + 22, y + 374, "chiffre autorisé uniquement", 11, op=0.4))
    b += f'<g id="carte-problematique">{carte(x, y, w, h, inner)}</g>'
    return svg(1440, 900, b)

def projet_realisations():
    b = projet_fond(hand_state="pause") + progression(2) + titre(y=150)
    b += text(CX, 300, "Réalisations", 28, fam="Tilt Neon", fill=PINK)
    b += para(CX, 340, ["[Ce que tu as livré, en 2 phrases : fonctionnalités, méthode, résultats.]"])
    for i, (lbl, x) in enumerate([("visuel-1 · avant", CX), ("visuel-2 · après", CX + 412)]):
        inner = (f'<rect x="{x+20}" y="{410}" width="348" height="250" rx="8" fill="{BG}" fill-opacity="0.5" stroke="{INK}" stroke-opacity="0.25" stroke-dasharray="6 5"/>'
                 + text(x + 194, 540, "capture de la page", 13, op=0.45, anchor="middle") + text(x + 20, 692, lbl, 15, weight=700, op=0.9))
        b += f'<g id="{lbl.split(" ")[0]}">{carte(x, 390, 388, 324, inner)}</g>'
    b += text(CX, 760, "La main se met en pause pendant que vous consultez les visuels. Ils suivent le défilement.", 13, op=0.5)
    return svg(1440, 900, b)

def curseurs():
    b = f'<rect width="640" height="270" fill="{BG}"/>'
    for i, (pose, lbl) in enumerate([("pointe", "repos / survol"), ("pince", "clic, saisie"), ("ouverte", "scratch")]):
        x = 40 + i * 200
        b += hand(x + 20, 14, s=0.75, pose=pose, id=f"curseur-{pose}")
        b += text(x + 102, 252, lbl, 13, op=0.75, anchor="middle")
    return svg(640, 270, b)

FILES = {
    "01-accueil.svg": accueil(),
    "02-projet-contexte.svg": projet_contexte(),
    "03-projet-problematique.svg": projet_problematique(),
    "04-projet-realisations.svg": projet_realisations(),
    "05-storyboard-main.svg": G.storyboard(),
    "06-main-neon.svg": curseurs(),
}
d = os.path.join(G.OUT, "v4"); os.makedirs(d, exist_ok=True)
for n, c in FILES.items():
    open(os.path.join(d, n), "w", encoding="utf-8").write(c)
print("v4 ok")
