"""V7 accueil : pochettes plus hautes et un peu plus grandes, lampe à lave plus grande,
fenêtre agrandie, consigne en néon lavande, poste en capitales."""
import os
import gen as G, gen2 as G2, gen3 as G3, gen4 as G4, gen5 as G5
from gen import svg, text, INK, BG, PINK

LAVANDE = "#C084FC"
_lave = G4.lampe_lave
def lampe_lave(cx=452, base=366):
    s = 1.4
    return f'<g id="lampe-a-lave-agrandie" transform="translate({cx*(1-s):.1f} {base*(1-s):.1f}) scale({s})">{_lave(cx, base)}</g>'
G4.lampe_lave = lampe_lave

def entete():
    poste = "PRODUCT MANAGER / PRODUCT OWNER"
    return (G3.nom(76, 112, 64)
            + f'<g id="sous-titre"><text x="80" y="150" font-family="Tilt Neon" font-size="18" letter-spacing="2.5" fill="none" stroke="{LAVANDE}" stroke-opacity="0.35" stroke-width="6">{poste}</text>'
            + f'<text x="80" y="150" font-family="Tilt Neon" font-size="18" letter-spacing="2.5" fill="{INK}">{poste}</text></g>')

def consigne():
    t = "Survolez un vinyle lumineux pour découvrir un projet"
    pill = '<rect x="465" y="832" width="510" height="40" rx="20"/>'
    return ('<g id="consigne">' + f'<rect x="465" y="832" width="510" height="40" rx="20" fill="{BG}" fill-opacity="0.85"/>'
            + G2.neon(pill, LAVANDE, w=2.4)
            + f'<text x="720" y="858" font-family="Tilt Neon" font-size="18" text-anchor="middle" fill="none" stroke="{LAVANDE}" stroke-opacity="0.22" stroke-width="5">{t}</text>'
            + f'<text x="720" y="858" font-family="Tilt Neon" font-size="18" text-anchor="middle" fill="#FFFFFF">{t}</text></g>')

def accueil():
    m, pos = G5.meuble()
    tipx, tipy = pos["vinyle-connect"]
    b = G3.mur() + G3.sol() + G3.fenetre(x=1095, y=200, w=190, h=160) + G.lampe()
    b += G5.scaled(G2.enceinte(250, "enceinte-gauche"), 0.78, 305, 780, "enceinte-gauche-reduite")
    b += G5.scaled(G2.enceinte(1080, "enceinte-droite"), 0.78, 1135, 780, "enceinte-droite-reduite")
    b += G5.scaled(G2.plante(185, 700), 0.7, 185, 780, "plante-sol-reduite")
    b += G5.scaled(G2.fauteuil(), 0.75, 1440, 800, "fauteuil-reduit")
    b += f'<g transform="translate(0 -22)">{G5.scaled(G4.mur_pochettes(), 0.66, 720, 366, "mur-pochettes-reduit")}</g>'
    b += m + G2.platine_face() + G2.ampli() + G2.casque() + entete() + G.bouton_son() + consigne()
    tx, ty = tipx - 140, tipy - 118
    from gen import SURF
    b += (f'<g id="info-bulle"><rect x="{tx}" y="{ty}" width="290" height="64" rx="12" fill="{SURF}" fill-opacity="0.95" stroke="{PINK}" stroke-opacity="0.8" stroke-width="1.2"/>'
          f'<path d="M{tipx-8} {ty+64} L{tipx} {ty+74} L{tipx+8} {ty+64} Z" fill="{SURF}" stroke="{PINK}" stroke-opacity="0.8" stroke-width="1.2"/>'
          + text(tx + 16, ty + 28, "Lancement du produit Connect", 18, fam="Tilt Neon") + text(tx + 16, ty + 48, "Cliquer pour écouter ce projet", 13, op=0.65) + "</g>")
    b += G3.cursor(tipx, tipy + 4, s=0.32)
    return svg(1440, 900, b)

d = os.path.join(G.OUT, "v7"); os.makedirs(d, exist_ok=True)
open(os.path.join(d, "01-accueil.svg"), "w", encoding="utf-8").write(accueil())
print("v7 ok")
