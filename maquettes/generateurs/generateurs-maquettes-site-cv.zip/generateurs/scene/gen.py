"""Génère les maquettes SVG (version épurée) du site CV de Louise Bury."""
import random, os

OUT = os.path.dirname(os.path.abspath(__file__))
INK = "#F5F3FF"; BG = "#0B0B12"; SURF = "#17171F"; PINK = "#FF4FA0"; DARK = "#2A0E5A"

DEFS = f"""<defs>
<linearGradient id="gNom" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#FFC46B"/><stop offset="0.25" stop-color="#FF8A6B"/><stop offset="0.5" stop-color="#FF4FA0"/><stop offset="0.75" stop-color="#B23FE0"/><stop offset="1" stop-color="#4B1FA0"/></linearGradient>
<linearGradient id="gSun" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#FFC46B"/><stop offset="0.5" stop-color="#FF8A6B"/><stop offset="1" stop-color="#FF4FA0"/></linearGradient>
<linearGradient id="gMur" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#0B0B12"/><stop offset="1" stop-color="#160C26"/></linearGradient>
<linearGradient id="gLumiere" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#FFC46B" stop-opacity="0.22"/><stop offset="1" stop-color="#FFC46B" stop-opacity="0"/></linearGradient>
</defs>"""

def svg(w, h, body):
    return f'<svg width="{w}" height="{h}" viewBox="0 0 {w} {h}" xmlns="http://www.w3.org/2000/svg">{DEFS}{body}</svg>'

def text(x, y, s, size=16, fam="Nunito", weight=400, fill=INK, op=1, anchor="start", id=None):
    i = f' id="{id}"' if id else ""
    return (f'<text{i} x="{x}" y="{y}" font-family="{fam}" font-size="{size}" font-weight="{weight}" '
            f'fill="{fill}" fill-opacity="{op}" text-anchor="{anchor}">{s}</text>')

def line(d, op=0.35, w=1.5, c=INK, glow=False):
    g = f'<path d="{d}" stroke="{c}" stroke-opacity="{op*0.3}" stroke-width="{w*6}" fill="none" stroke-linecap="round" stroke-linejoin="round"/>' if glow else ""
    return g + f'<path d="{d}" stroke="{c}" stroke-opacity="{op}" stroke-width="{w}" fill="none" stroke-linecap="round" stroke-linejoin="round"/>'

# ---------------------------------------------------------------- main (gant)
ST = f'stroke="{DARK}" stroke-width="5" stroke-linejoin="round"'
W = f'fill="{INK}"'
PALM = f'<rect id="paume" x="56" y="92" width="88" height="92" rx="34" {W} {ST}/>'
SEAMS = f'<path id="coutures" d="M82 128 V152 M100 124 V152 M118 128 V152" stroke="{DARK}" stroke-width="4" stroke-linecap="round"/>'
CUFF = f'<g id="manchette"><rect x="52" y="176" width="96" height="56" rx="16" fill="{PINK}" {ST}/><path d="M60 194 H140 M60 210 H140" stroke="#FFC46B" stroke-width="4" stroke-linecap="round"/></g>'
POSES = {
    "ouverte": f'<rect id="index" x="58" y="26" width="30" height="86" rx="15" {W} {ST}/><rect id="majeur" x="85" y="14" width="30" height="96" rx="15" {W} {ST}/><rect id="annulaire" x="112" y="26" width="30" height="86" rx="15" {W} {ST}/>{PALM}<rect id="pouce" x="14" y="104" width="64" height="30" rx="15" {W} {ST} transform="rotate(-38 46 119)"/>',
    "pince": f'<rect id="majeur" x="86" y="62" width="30" height="50" rx="15" {W} {ST}/><rect id="annulaire" x="113" y="70" width="30" height="44" rx="15" {W} {ST}/><rect id="index" x="50" y="28" width="30" height="86" rx="15" {W} {ST} transform="rotate(22 65 110)"/>{PALM}<rect id="pouce" x="8" y="64" width="70" height="30" rx="15" {W} {ST} transform="rotate(-62 60 92)"/>',
    "pointe": f'<rect id="majeur" x="86" y="74" width="30" height="40" rx="15" {W} {ST}/><rect id="annulaire" x="113" y="78" width="30" height="38" rx="15" {W} {ST}/><rect id="index" x="58" y="4" width="30" height="108" rx="15" {W} {ST}/>{PALM}<rect id="pouce" x="30" y="112" width="62" height="30" rx="15" {W} {ST} transform="rotate(-14 61 127)"/>',
}
HALO = f'<ellipse cx="100" cy="120" rx="92" ry="112" fill="{PINK}" fill-opacity="0.10"/>'

def hand(x, y, s=0.4, pose="pointe", rot=0, id="main", halo=True):
    """x,y = position du coin haut-gauche de la boîte 200x240 une fois mise à l'échelle."""
    r = f" rotate({rot} 100 120)" if rot else ""
    return (f'<g id="{id}" transform="translate({x} {y}) scale({s}){r}">'
            f'{HALO if halo else ""}{POSES[pose]}{SEAMS}{CUFF}</g>')

def cursor(tipx, tipy, s=0.4, pose="pointe", id="main-curseur"):
    # pointe : bout de l'index en (73, 4) dans la boîte
    return hand(tipx - 73 * s, tipy - 4 * s, s, pose, id=id)

# ---------------------------------------------------------------- platine (vue de dessus)
def disc(cx, cy, id="vinyle"):
    g = "".join(f'<circle cx="{cx}" cy="{cy}" r="{r}" fill="none" stroke="#33334A" stroke-width="1.2"/>' for r in range(86, 176, 12))
    return (f'<g id="{id}"><circle cx="{cx}" cy="{cy}" r="182" fill="#0E0E16"/>{g}'
            f'<path d="M{cx-120} {cy-110} A163 163 0 0 1 {cx+20} {cy-162}" stroke="#FFF" stroke-opacity="0.12" stroke-width="16" fill="none"/>'
            f'<g id="etiquette"><circle cx="{cx}" cy="{cy}" r="62" fill="url(#gSun)"/>'
            f'<rect x="{cx-58}" y="{cy+14}" width="116" height="4" fill="{DARK}" fill-opacity="0.45"/>'
            f'<rect x="{cx-54}" y="{cy+26}" width="108" height="4" fill="{DARK}" fill-opacity="0.45"/>'
            f'<rect x="{cx-46}" y="{cy+38}" width="92" height="4" fill="{DARK}" fill-opacity="0.45"/></g>'
            f'<circle id="axe" cx="{cx}" cy="{cy}" r="5" fill="{INK}"/></g>')

def platine(x, y, s=1.0, capot="ferme", bras="pose", disque=True, rpm33=True, dim=1.0):
    capot_svg = ""
    if capot == "ferme":
        capot_svg = f'<g id="capot"><rect x="4" y="4" width="552" height="432" rx="28" fill="{INK}" fill-opacity="0.05" stroke="{INK}" stroke-opacity="0.4" stroke-width="2"/><path d="M36 30 L220 30" stroke="#FFF" stroke-opacity="0.3" stroke-width="6" stroke-linecap="round"/></g>'
    elif capot == "ouvert":  # relevé : vu en raccourci au-dessus du socle
        capot_svg = f'<g id="capot"><path d="M4 4 L24 -96 L536 -96 L556 4 Z" fill="{INK}" fill-opacity="0.05" stroke="{INK}" stroke-opacity="0.4" stroke-width="2"/></g>'
    if bras == "pose":
        arm = f'<path d="M480 86 L466 246 L366 300" stroke="#D9D6E8" stroke-width="8" fill="none" stroke-linecap="round" stroke-linejoin="round"/><rect id="cellule" x="330" y="290" width="44" height="26" rx="5" fill="{INK}" transform="rotate(-24 352 303)"/>'
    else:  # au repos
        arm = f'<path d="M480 86 L500 250 L506 300" stroke="#D9D6E8" stroke-width="8" fill="none" stroke-linecap="round" stroke-linejoin="round"/><rect id="cellule" x="490" y="292" width="30" height="40" rx="5" fill="{INK}"/>'
    a33 = (PINK, "#2A2A36") if rpm33 else ("#2A2A36", PINK)
    return (f'<g id="platine" transform="translate({x} {y}) scale({s})" opacity="{dim}">'
            f'<g id="socle"><rect x="4" y="4" width="552" height="432" rx="28" fill="#1A1426" stroke="{PINK}" stroke-opacity="0.25" stroke-width="12"/>'
            f'<rect x="4" y="4" width="552" height="432" rx="28" fill="none" stroke="{PINK}" stroke-width="2.5"/></g>'
            f'<g id="plateau"><circle cx="240" cy="220" r="192" fill="#1F1F29" stroke="{INK}" stroke-opacity="0.2" stroke-width="2"/></g>'
            f'{disc(240, 220) if disque else ""}'
            f'<g id="bouton-start"><circle cx="56" cy="384" r="22" fill="#24242F" stroke="{INK}" stroke-opacity="0.4" stroke-width="2"/><circle cx="56" cy="384" r="7" fill="{PINK}"/></g>'
            f'<g id="selecteur-rpm"><rect id="rpm-33" x="420" y="372" width="50" height="32" rx="8" fill="{a33[0]}" stroke="{PINK}" stroke-width="2"/><rect id="rpm-45" x="478" y="372" width="50" height="32" rx="8" fill="{a33[1]}" stroke="{PINK}" stroke-width="2"/>'
            f'{text(445, 394, "33", 15, weight=700, anchor="middle")}{text(503, 394, "45", 15, weight=700, anchor="middle")}</g>'
            f'<g id="bras-platine"><rect x="496" y="128" width="26" height="62" rx="7" fill="#2C2C3A"/>{arm}'
            f'<circle cx="480" cy="86" r="30" fill="#24242F" stroke="{INK}" stroke-opacity="0.4" stroke-width="2"/><circle cx="480" cy="86" r="11" fill="#D9D6E8"/></g>'
            f'{capot_svg}</g>')

# ---------------------------------------------------------------- éléments de pièce (trait épuré)
def piece_fond(w=1440, h=900, horizon=780):
    s = f'<g id="mur"><rect width="{w}" height="{h}" fill="url(#gMur)"/></g><g id="sol">'
    s += line(f"M0 {horizon} H{w}", op=0.55, w=1.5, c=PINK, glow=True)
    vx, vy = w / 2, horizon - 90
    for x in range(-1600, w + 1700, 160):
        t = (horizon - vy) / (h - vy); x1 = vx + (x - vx) * t
        s += f'<path d="M{x1:.1f} {horizon} L{x} {h}" stroke="{PINK}" stroke-opacity="0.10" stroke-width="1"/>'
    for y in (800, 828, 866):
        s += f'<path d="M0 {y} H{w}" stroke="{PINK}" stroke-opacity="0.08" stroke-width="1"/>'
    return s + "</g>"

def sparkles(x0, y0, w, n=26, seed=3):
    rnd = random.Random(seed)
    s = '<g id="sparkles">' + line(f"M{x0+40} {y0} H{x0+w-40}", op=0.5, w=1, c=INK)
    for i in range(n):
        s += f'<circle cx="{x0 + rnd.random()*w:.1f}" cy="{y0 + 4 + rnd.random()*22:.1f}" r="{0.6 + rnd.random()*1.3:.1f}" fill="{INK}" fill-opacity="{0.25 + rnd.random()*0.6:.2f}"/>'
    return s + "</g>"

def lampe(op=0.35):
    return ('<g id="lampe-arc">'
            '<path id="cone-lumiere" d="M1112 200 L1010 540 L1230 540 L1150 200 Z" fill="url(#gLumiere)"/>'
            + line("M1300 780 V360 Q1300 160 1150 168", op=op, w=2)
            + line("M1272 780 H1328", op=op, w=2)
            + f'<path d="M1106 198 L1122 158 L1164 172 L1160 208 Z" fill="none" stroke="#FFC46B" stroke-width="2"/><circle cx="1134" cy="202" r="7" fill="#FFC46B"/></g>')

def enceinte(x, id, op=0.3):
    return (f'<g id="{id}"><rect x="{x}" y="560" width="110" height="220" rx="12" fill="{BG}" stroke="{INK}" stroke-opacity="{op}" stroke-width="1.5"/>'
            f'<circle cx="{x+55}" cy="600" r="12" fill="none" stroke="{INK}" stroke-opacity="{op}" stroke-width="1.5"/>'
            f'<circle cx="{x+55}" cy="668" r="36" fill="none" stroke="{INK}" stroke-opacity="{op}" stroke-width="1.5"/>'
            f'<circle cx="{x+55}" cy="668" r="18" fill="none" stroke="{INK}" stroke-opacity="{op*0.7}" stroke-width="1.5"/>'
            f'<circle cx="{x+55}" cy="744" r="9" fill="none" stroke="{INK}" stroke-opacity="{op}" stroke-width="1.5"/></g>')

def plante(cx, base, n=6, length=110, id="plante-sol", op=0.35, pot=True):
    s = f'<g id="{id}">'
    for i in range(n):
        a = -160 + i * (140 / (n - 1))
        s += f'<ellipse cx="{cx}" cy="{base - length/2}" rx="{length*0.2:.1f}" ry="{length/2}" fill="{BG}" stroke="#5EEAD4" stroke-opacity="{op}" stroke-width="1.5" transform="rotate({a+90:.1f} {cx} {base})"/>'
        s += f'<path d="M{cx} {base} L{cx} {base-length+8}" stroke="#5EEAD4" stroke-opacity="{op*0.6}" stroke-width="1" transform="rotate({a+90:.1f} {cx} {base})"/>'
    if pot:
        s += f'<path d="M{cx-34} {base} H{cx+34} L{cx+26} {base+80} H{cx-26} Z" fill="{BG}" stroke="{INK}" stroke-opacity="{op}" stroke-width="1.5"/>'
    return s + "</g>"

def fauteuil(op=0.3):
    return (f'<g id="fauteuil"><rect x="1220" y="600" width="260" height="190" rx="70" fill="{BG}" stroke="{INK}" stroke-opacity="{op}" stroke-width="1.5"/>'
            f'<rect x="1250" y="730" width="230" height="64" rx="28" fill="{BG}" stroke="{INK}" stroke-opacity="{op}" stroke-width="1.5"/>'
            f'<rect x="1196" y="692" width="68" height="112" rx="34" fill="{BG}" stroke="{INK}" stroke-opacity="{op}" stroke-width="1.5"/></g>')

SELECTION = [  # (casier, id, titre)
    (0, "vinyle-connect", "Lancement du produit Connect"),
    (1, "vinyle-indice-prix", "Refonte de la page indice de prix"),
    (2, "vinyle-benchmarks", "Automatisation des benchmarks de masse"),
    (3, "vinyle-checkout-picard", "Refonte du tunnel de checkout Picard"),
    (4, "vinyle-experiences", "Mes expériences"),
    (6, "vinyle-formations", "Formations"),
    (7, "vinyle-contact", "Contact"),
]

def meuble(x0=380, top=540, hover="vinyle-connect", seed=11):
    """Meuble 680 px de large, 8 casiers. Retourne (svg, positions des vinyles sélectionnables)."""
    rnd = random.Random(seed)
    pos = {}
    s = (f'<g id="meuble">' + line(f"M{x0} {top} H{x0+680}", op=0.7, w=2, c=INK)
         + f'<rect x="{x0+4}" y="{top+14}" width="672" height="226" fill="{BG}" stroke="{INK}" stroke-opacity="0.3" stroke-width="1.5"/>'
         + line(f"M{x0+32} {top+240} L{x0+24} {top+262} M{x0+52} {top+240} L{x0+60} {top+262} M{x0+628} {top+240} L{x0+620} {top+262} M{x0+648} {top+240} L{x0+656} {top+262}", op=0.35, w=1.5)
         + '</g><g id="bibliotheque-vinyles">')
    sel = {c: (i, t) for c, i, t in SELECTION}
    for c in range(8):
        col, row = c % 4, c // 4
        cx, cy = x0 + 12 + col * 168, top + 24 + row * 112
        s += f'<g id="casier-{c+1}"><rect x="{cx}" y="{cy}" width="160" height="104" rx="3" fill="none" stroke="{INK}" stroke-opacity="0.15" stroke-width="1"/>'
        x, k = cx + 6, 0
        target = 3 + rnd.randrange(8) if c in sel else -1
        hi = ""
        while x < cx + 150:
            if k == target:
                vid, _ = sel[c]; hov = vid == hover
                lift = 8 if hov else 0
                y = cy + 6 - lift
                hi += f'<g id="{vid}">'
                hi += f'<rect x="{x-4}" y="{y-4}" width="20" height="104" rx="6" fill="{PINK}" fill-opacity="{0.28 if hov else 0.14}"/>'
                hi += f'<rect x="{x}" y="{y}" width="12" height="96" rx="2" fill="{PINK}" fill-opacity="{1 if hov else 0.85}"' + (f' stroke="{INK}" stroke-width="1.5"' if hov else "") + "/></g>"
                pos[vid] = (x + 6, y)
                x += 14; k += 1; continue
            w = 5 + rnd.randrange(4)
            if x + w > cx + 154: break
            h = 84 + rnd.randrange(12)
            s += f'<rect x="{x}" y="{cy+100-h}" width="{w}" height="{h}" fill="{rnd.choice(["#221E30", "#2A2539", "#1D1A29", "#2F2940"])}"/>'
            x += w + 1; k += 1
        s += "</g>" + hi
    return s + "</g>", pos

def pochettes(xc=720, y=290, size=110, gap=24, op=0.35):
    tot = 4 * size + 3 * gap; x0 = xc - tot / 2
    s = f'<g id="mur-pochettes">' + line(f"M{x0-30} {y+size+8} H{x0+tot+30}", op=0.5, w=2)
    for i in range(4):
        x = x0 + i * (size + gap)
        s += (f'<g id="pochette-{i+1}"><rect x="{x}" y="{y}" width="{size}" height="{size}" fill="{SURF}" stroke="{INK}" stroke-opacity="{op}" stroke-width="1.5" stroke-dasharray="6 5"/>'
              + text(x + size/2, y + size/2 - 2, f"pochette-{i+1}", 12, op=0.45, anchor="middle")
              + text(x + size/2, y + size/2 + 16, "image à déposer", 10, op=0.3, anchor="middle") + "</g>")
    return s + "</g>"

def platine_face(x=620, y=508):
    return (f'<g id="platine-meuble"><rect x="{x}" y="{y}" width="200" height="32" rx="6" fill="#1A1426" stroke="{PINK}" stroke-width="2"/>'
            f'<rect x="{x}" y="{y}" width="200" height="32" rx="6" fill="none" stroke="{PINK}" stroke-opacity="0.2" stroke-width="10"/>'
            f'<ellipse cx="{x+80}" cy="{y-4}" rx="68" ry="6" fill="#0E0E16" stroke="{INK}" stroke-opacity="0.3"/><ellipse cx="{x+80}" cy="{y-5}" rx="18" ry="2.5" fill="#FF8A6B"/>'
            + line(f"M{x+170} {y-8} L{x+150} {y-26} L{x+122} {y-10}", op=0.6, w=2)
            + f'<circle cx="{x+20}" cy="{y+16}" r="4" fill="{PINK}"/>'
            f'<path id="capot-meuble" d="M{x+4} {y} L{x+16} {y-42} L{x+184} {y-42} L{x+196} {y} Z" fill="{INK}" fill-opacity="0.04" stroke="{INK}" stroke-opacity="0.4" stroke-width="1.5"/></g>')

def ampli(x=860, y=508):
    return (f'<g id="ampli"><rect x="{x}" y="{y}" width="100" height="32" rx="4" fill="{BG}" stroke="{INK}" stroke-opacity="0.35" stroke-width="1.5"/>'
            f'<rect x="{x+10}" y="{y+8}" width="30" height="16" rx="2" fill="#FFC46B" fill-opacity="0.8"/>'
            f'<circle cx="{x+62}" cy="{y+16}" r="6" fill="none" stroke="{INK}" stroke-opacity="0.4"/><circle cx="{x+84}" cy="{y+16}" r="6" fill="none" stroke="{INK}" stroke-opacity="0.4"/></g>')

def casque(x=1010, y=488):
    return ('<g id="casque">' + line(f"M{x} {y} V{y+52} M{x-10} {y+52} H{x+10}", op=0.4, w=2)
            + line(f"M{x-22} {y+28} A22 22 0 0 1 {x+22} {y+28}", op=0.6, w=3, c=INK)
            + f'<rect x="{x-30}" y="{y+20}" width="12" height="22" rx="5" fill="{BG}" stroke="{INK}" stroke-opacity="0.6" stroke-width="2"/>'
            + f'<rect x="{x+18}" y="{y+20}" width="12" height="22" rx="5" fill="{BG}" stroke="{INK}" stroke-opacity="0.6" stroke-width="2"/></g>')

def entete(nav=True, small=False):
    if small:
        s = text(60, 64, "Louise Bury", 28, fam="Monoton", fill="url(#gNom)", id="nom")
        s += text(60, 92, "Product Manager / Product Owner", 14, op=0.6, id="sous-titre")
    else:
        s = text(80, 112, "Louise Bury", 64, fam="Monoton", fill="url(#gNom)", id="nom")
        s += text(82, 150, "Product Manager / Product Owner", 20, fam="Tilt Neon", op=0.85, id="sous-titre")
        s += sparkles(70, 162, 440)
    if nav:
        s += '<g id="navigation">'
        for i, (lbl, x) in enumerate([("Projets", 1000), ("Expériences", 1086), ("Formations", 1210), ("Contact", 1322)]):
            s += text(x, 72, lbl, 15, weight=600, op=0.75)
        s += "</g>"
    return s

def bouton_son(x=1260, y=846):
    return (f'<g id="bouton-son"><rect x="{x}" y="{y}" width="140" height="34" rx="17" fill="{SURF}" stroke="{INK}" stroke-opacity="0.25"/>'
            f'<path d="M{x+18} {y+13} H{x+24} L{x+31} {y+8} V{y+26} L{x+24} {y+21} H{x+18} Z" fill="{INK}" fill-opacity="0.8"/>'
            + line(f"M{x+36} {y+12} L{x+44} {y+22} M{x+44} {y+12} L{x+36} {y+22}", op=0.8, w=1.5)
            + text(x + 54, y + 22, "Son coupé", 13, weight=600, op=0.8) + "</g>")

# ================================================================= 1. ACCUEIL
def accueil():
    m, pos = meuble()
    tipx, tipy = pos["vinyle-connect"]
    body = piece_fond() + lampe() + enceinte(250, "enceinte-gauche") + enceinte(1080, "enceinte-droite")
    body += plante(185, 700, id="plante-sol") + fauteuil() + pochettes()
    body += m + platine_face() + ampli() + casque()
    body += entete() + bouton_son()
    # info-bulle
    tx, ty = tipx - 140, tipy - 118
    body += (f'<g id="info-bulle"><rect x="{tx}" y="{ty}" width="290" height="64" rx="12" fill="{SURF}" fill-opacity="0.95" stroke="{PINK}" stroke-opacity="0.7" stroke-width="1.5"/>'
             f'<path d="M{tipx-8} {ty+64} L{tipx} {ty+74} L{tipx+8} {ty+64} Z" fill="{SURF}" stroke="{PINK}" stroke-opacity="0.7" stroke-width="1.5"/>'
             + text(tx + 16, ty + 27, "Lancement du produit Connect", 16, weight=700)
             + text(tx + 16, ty + 48, "Cliquer pour écouter ce projet", 13, op=0.6) + "</g>")
    body += cursor(tipx, tipy + 4, s=0.38)
    body += text(720, 868, "Survolez un vinyle lumineux pour découvrir un projet", 14, op=0.5, anchor="middle", id="consigne")
    return svg(1440, 900, body)

# ================================================================= 2. PROJET (3 états)
def projet_base(dim=1.0, hand_pose="ouverte", hand_state="scratch"):
    m, _ = meuble(x0=-20, top=730, hover=None, seed=5)
    body = piece_fond(horizon=940) + f'<g id="decor-flou" opacity="0.5">' + pochettes(xc=330, y=146, size=72, gap=18, op=0.2) + m + "</g>"
    body += platine(60, 250, s=0.95, dim=dim)
    cx, cy = 60 + 240 * 0.95, 250 + 220 * 0.95
    # indicateur de rotation
    body += line(f"M{cx-196} {cy-40} A200 200 0 0 1 {cx-40} {cy-196}", op=0.35 * dim, w=1.5, c=PINK)
    if hand_state == "scratch":
        body += hand(cx + 92, cy - 20, s=0.46, pose="ouverte", rot=-30, id="main")
        body += line(f"M{cx+150} {cy-150} A206 206 0 0 1 {cx+206} {cy-30}", op=0.9, w=2.5, c=PINK, glow=True)
        body += f'<path d="M{cx+200} {cy-40} L{cx+207} {cy-24} L{cx+216} {cy-40} Z" fill="{PINK}"/>'
        body += text(60, 696, "scroll ↓ : la main fait tourner le disque", 12, op=0.55)
        body += text(60, 714, "scroll ↑ : sens inverse", 12, op=0.55)
    else:
        body += hand(cx - 190, cy + 120, s=0.4, pose="ouverte", rot=-15, id="main")
        body += text(60, 696, "main en pause pendant les réalisations", 12, op=0.55)
    body += entete(nav=False, small=True)
    body += text(60, 132, "↑ Remonter tout en haut pour revenir à la bibliothèque", 12, op=0.45, id="retour")
    body += bouton_son()
    return body

def progression(active):
    s = '<g id="progression">'
    for i, lbl in enumerate(["Contexte", "Problématique", "Réalisations"]):
        y = 300 + i * 34; on = i == active
        s += f'<circle cx="1392" cy="{y}" r="{5 if on else 3.5}" fill="{PINK if on else INK}" fill-opacity="{1 if on else 0.35}"/>'
        s += text(1378, y + 5, lbl, 13, weight=700 if on else 400, op=1 if on else 0.4, anchor="end")
    return s + "</g>"

def titre_projet(x=780, y=170):
    return (text(x, y, "Face A · 33 tours", 26, fam="Neonderthaw", fill="#FFC46B", id="face")
            + text(x, y + 52, "Lancement du produit Connect", 40, fam="Tilt Neon", id="titre-projet")
            + text(x, y + 82, "[Entreprise] · [Années] · [Rôle]", 15, op=0.55))

def paragraphe(x, y, lines, size=16, op=0.8, lh=26):
    return "".join(text(x, y + i * lh, l, size, op=op) for i, l in enumerate(lines))

def projet_contexte():
    body = projet_base() + titre_projet() + progression(0)
    body += text(780, 330, "Contexte", 26, fam="Tilt Neon", fill=PINK)
    body += paragraphe(780, 372, [
        "[2 à 3 phrases : l'entreprise, le produit, l'équipe.]",
        "[Pourquoi ce projet existait, pour quels utilisateurs.]",
        "[Ton rôle et ton périmètre en une phrase.]"])
    body += f'<g id="tags">'
    for i, t in enumerate(["B2B Transport", "Lancement produit", "Discovery"]):
        x = 780 + i * 160
        body += f'<rect x="{x}" y="470" width="148" height="32" rx="16" fill="none" stroke="{INK}" stroke-opacity="0.3"/>' + text(x + 74, 491, t, 13, op=0.75, anchor="middle")
    body += "</g>" + text(780, 846, "Défiler ↓ pour la problématique", 13, op=0.45)
    return svg(1440, 900, body)

def projet_problematique():
    body = projet_base(dim=0.55) + titre_projet() + progression(1)
    x, y, w, h = 440, 290, 820, 380
    body += (f'<g id="carte-problematique"><rect x="{x}" y="{y}" width="{w}" height="{h}" rx="20" fill="{PINK}" fill-opacity="0.08"/>'
             f'<rect x="{x+6}" y="{y+6}" width="{w-12}" height="{h-12}" rx="16" fill="{SURF}" fill-opacity="0.92" stroke="{PINK}" stroke-opacity="0.8" stroke-width="1.5"/>'
             + text(x + 40, y + 62, "Problématique", 30, fam="Tilt Neon", fill=PINK)
             + paragraphe(x + 40, y + 104, ["[Le problème métier à résoudre, en 2 phrases.]", "[Ce que ça coûtait : temps perdu, clients, chiffre d'affaires…]"]))
    for i, (val, lbl) in enumerate([("[XX] %", "indicateur 1"), ("[X] sem.", "indicateur 2"), ("[X] k", "indicateur 3")]):
        bx = x + 40 + i * 256
        body += (f'<rect x="{bx}" y="{y+180}" width="230" height="140" rx="14" fill="none" stroke="{INK}" stroke-opacity="0.2"/>'
                 + text(bx + 24, y + 248, val, 38, fam="Tilt Neon", fill="url(#gNom)")
                 + text(bx + 24, y + 282, lbl, 13, op=0.6)
                 + text(bx + 24, y + 302, "chiffre autorisé uniquement", 11, op=0.35))
    body += "</g>"
    return svg(1440, 900, body)

def projet_realisations():
    body = projet_base(dim=0.55, hand_state="pause") + titre_projet() + progression(2)
    body += text(780, 330, "Réalisations", 26, fam="Tilt Neon", fill=PINK)
    body += paragraphe(780, 368, ["[Ce que tu as livré, en 2 phrases.]"])
    for i, (lbl, x, y) in enumerate([("visuel-1 · avant", 440, 410), ("visuel-2 · après", 900, 410)]):
        body += (f'<g id="{lbl.split(" ")[0]}"><rect x="{x-6}" y="{y-6}" width="432" height="292" rx="20" fill="{PINK}" fill-opacity="0.08"/>'
                 f'<rect x="{x}" y="{y}" width="420" height="280" rx="14" fill="{SURF}" stroke="{PINK}" stroke-opacity="0.7" stroke-width="1.5"/>'
                 f'<rect x="{x+20}" y="{y+20}" width="380" height="200" rx="8" fill="none" stroke="{INK}" stroke-opacity="0.25" stroke-dasharray="6 5"/>'
                 + text(x + 210, y + 126, "capture de la page", 13, op=0.4, anchor="middle")
                 + text(x + 20, y + 252, lbl, 14, weight=700, op=0.85) + "</g>")
    body += text(780, 846, "Les visuels suivent le défilement", 13, op=0.45)
    return svg(1440, 900, body)

# ================================================================= 3. STORYBOARD DE LA MAIN
def storyboard():
    W, H = 1440, 900
    body = f'<rect width="{W}" height="{H}" fill="{BG}"/>'
    body += text(48, 64, "La main : curseur au survol, puis elle lance le vinyle", 28, fam="Tilt Neon")
    body += text(48, 94, "Un seul personnage du début à la fin. Calques : main (pose ouverte / pince / pointe), capot, vinyle, bras-platine, selecteur-rpm.", 14, op=0.6)
    pw, ph, gx, gy = 324, 330, 24, 40
    panels = [
        ("1. Survol", "La main remplace le curseur ; le vinyle s'allume."),
        ("2. Clic", "Elle saisit le vinyle (pose pince) et zoome vers la platine."),
        ("3. Ouverture du capot", "Elle soulève le capot."),
        ("4. Pose du disque", "Le disque descend sur le plateau."),
        ("5. Bras de lecture", "Elle amène le bras sur le disque."),
        ("6. Réglage 33 tours", "Elle appuie sur 33 (pose pointe), le disque tourne."),
        ("7. Scratch au scroll", "Scroll ↓ : sens horaire. Scroll ↑ : sens inverse."),
        ("8. Pause", "Pendant les réalisations, la main se retire."),
    ]
    for i, (t, d) in enumerate(panels):
        col, row = i % 4, i // 4
        x, y = 48 + col * (pw + gx), 130 + row * (ph + gy)
        body += f'<g id="etape-{i+1}"><rect x="{x}" y="{y}" width="{pw}" height="{ph-70}" rx="16" fill="{SURF}" stroke="{INK}" stroke-opacity="0.12"/>'
        s = 0.36; px, py = x + (pw - 560 * s) / 2, y + 40
        cx, cy = px + 240 * s, py + 220 * s
        if i == 0:
            m, pos = meuble(x0=0, top=0, hover="vinyle-connect", seed=11)
            body += f'<g transform="translate({x+12} {y+60}) scale(0.44)">{m}</g>'
            tx, ty = pos["vinyle-connect"]
            body += cursor(x + 12 + tx * 0.44, y + 60 + ty * 0.44 + 2, s=0.3)
        elif i == 1:
            body += platine(px, py, s, capot="ferme", disque=False, bras="repos", dim=0.5)
            body += f'<g transform="translate({x+40} {y+70}) scale(0.32)">{disc(190, 190, id="vinyle-saisi")}</g>'
            body += hand(x + 120, y + 120, s=0.38, pose="pince", rot=-20)
        elif i == 2:
            body += platine(px, py + 30, s, capot="ouvert", disque=False, bras="repos")
            body += hand(px + 120, py - 20, s=0.36, pose="pince", rot=180)
            body += line(f"M{px+80} {py+30} V{py-10}", op=0.9, w=2, c=PINK)
        elif i == 3:
            body += platine(px, py + 30, s, capot="ouvert", disque=False, bras="repos")
            body += f'<g transform="translate({cx-240*s*0.8} {py+30+220*s-60-240*s*0.8}) scale({s*0.8*1.0})" opacity="0.95">{disc(240, 240, id="vinyle-descend")}</g>'
            body += hand(cx + 40, py + 10, s=0.34, pose="pince", rot=150)
            body += line(f"M{x+pw-40} {py+40} V{py+110}", op=0.9, w=2, c=PINK)
        elif i == 4:
            body += platine(px, py + 30, s, capot="ouvert", bras="pose")
            body += hand(px + 125, py + 70, s=0.34, pose="pince", rot=200)
        elif i == 5:
            body += platine(px, py + 30, s, capot="ouvert", bras="pose")
            tx, ty = px + 445 * s, py + 30 + 380 * s
            body += cursor(tx, ty, s=0.32)
        elif i == 6:
            body += platine(px, py + 30, s, capot="ouvert", bras="pose")
            c2y = py + 30 + 220 * s
            body += hand(cx + 20, c2y - 60, s=0.34, pose="ouverte", rot=-30)
            body += line(f"M{cx-80} {c2y-40} A86 86 0 0 1 {cx-40} {c2y-78}", op=0.9, w=2, c=PINK)
            body += line(f"M{cx-40} {c2y+78} A86 86 0 0 1 {cx-80} {c2y+40}", op=0.9, w=2, c="#3B82F6")
        else:
            body += platine(px, py + 30, s, capot="ouvert", bras="pose", dim=0.6)
            body += hand(x + pw - 110, y + 150, s=0.32, pose="ouverte", rot=10)
            body += f'<rect x="{x+pw-60}" y="{y+120}" width="6" height="22" rx="2" fill="{PINK}"/><rect x="{x+pw-48}" y="{y+120}" width="6" height="22" rx="2" fill="{PINK}"/>'
        body += text(x, y + ph - 40, t, 17, weight=700) + text(x, y + ph - 18, d, 12, op=0.6) + "</g>"
    return svg(W, H, body)

def curseurs():
    body = f'<rect width="520" height="220" fill="{BG}"/>'
    for i, (pose, lbl) in enumerate([("pointe", "repos"), ("pointe", "survol (halo)"), ("pince", "clic")]):
        x = 40 + i * 160
        body += hand(x + 20, 30, s=0.5, pose=pose, id=f"curseur-{lbl.split(' ')[0]}", halo=(i == 1))
        body += text(x + 70, 190, lbl, 13, op=0.7, anchor="middle")
    return svg(520, 220, body)

FILES = {
    "01-accueil-epure.svg": accueil(),
    "02-projet-contexte.svg": projet_contexte(),
    "03-projet-problematique.svg": projet_problematique(),
    "04-projet-realisations.svg": projet_realisations(),
    "05-storyboard-main.svg": storyboard(),
    "06-main-curseur.svg": curseurs(),
}
for name, content in FILES.items():
    with open(os.path.join(OUT, name), "w", encoding="utf-8") as f:
        f.write(content)
print("ok", list(FILES))
