"""Exporte les éléments SVG de l'animation pour le site (dossier passé en argument)."""
import sys, os, json, re
sys.argv = [sys.argv[0], "/home/claude/scene", sys.argv[1]]
OUT = sys.argv[2]
exec(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "storyboard.py"), encoding="utf-8").read().split('if __name__ == "__main__":')[0])
import mains as M

def ecrire(nom, contenu):
    open(os.path.join(OUT, nom), "w", encoding="utf-8").write(contenu)

DEFS_MIN = (f'<defs><linearGradient id="gPochette" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#FFFFFF" stop-opacity="0.25"/><stop offset="1" stop-color="#000" stop-opacity="0.2"/></linearGradient>'
            f'<radialGradient id="gHaloTop"><stop offset="0" stop-color="{PINK}" stop-opacity="0.25"/><stop offset="1" stop-color="{PINK}" stop-opacity="0"/></radialGradient></defs>')

# 1) vue de dessus : décor + platine (bras au repos), sans disque
vue = (decor_dessus() + pochette(40, 420, 300, rot=-10, id="pochette-posee") + platine_dessus(-30)
       + f'<g id="bras-platine-place" transform="translate({TOP_X} {TOP_Y}) scale({TOP_S})">{bras(-30)}</g>')
ecrire("vue-dessus.svg", f'<svg width="1440" height="900" viewBox="0 0 1440 900" overflow="visible" xmlns="http://www.w3.org/2000/svg">{DEFS_MIN}{vue}</svg>')

# 2) disque, pochette, tranche (couleur = var(--couleur-vinyle))
ecrire("disque.svg", f'<svg width="400" height="400" viewBox="-200 -200 400 400" xmlns="http://www.w3.org/2000/svg">{disque(0, 0, 196)}</svg>')
ecrire("pochette.svg", f'<svg width="200" height="200" viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">{DEFS_MIN}{pochette(0, 0, 200)}</svg>')

# 3) main articulée : silhouette complète + pouce « devant » (masqué par défaut)
def fixe_ids(svg, nom):
    return re.sub(r'main-(dos|pouce)-\d+', lambda m: f'forme-{nom}-{m.group(1)}', svg)
complete = fixe_ids(M.main_svg("ouverte"), "main")
pouce = fixe_ids(M.main_svg("ouverte", partie="pouce"), "main")
dos = fixe_ids(M.main_svg("ouverte", partie="dos"), "main-tenue")
ecrire("main.svg", '<svg width="240" height="260" viewBox="-10 -10 240 260" xmlns="http://www.w3.org/2000/svg">'
       f'<g id="main-complete">{complete}</g>'
       f'<g id="main-tenue" style="display:none"><g id="main-tenue-arriere">{dos}</g><g id="main-tenue-pouce">{pouce}</g></g></svg>')
json.dump({"explication": "Doigt = [base x, base y, phalange 1, phalange 2, largeur, angle, courbure, repli]. Ordre : index, majeur, annulaire, auriculaire, pouce. "
                          "angle = orientation du doigt (0 = vers le haut, + = vers la droite) ; courbure = inclinaison de la 2e phalange ; "
                          "repli = 0 tendu à 90 replié : longueurs visibles = phalange1 × (1 − 0,3 × sin(repli)) et phalange2 × max(0,22 ; cos(repli)). "
                          "Point de pivot de la main pour les rotations : (110, 130). Voir mains.py pour le calcul exact.",
           "paume": M.PAUME, "poses": {k: [list(map(lambda x: round(x, 2), d)) for d in v] for k, v in M.POSES.items()}},
          open(os.path.join(OUT, "poses-main.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)

# 4) main-curseur de l'accueil
tx, ty = bout(POSES_MAIN["pointe"][0])
ecrire("main-pointe.svg", f'<svg width="240" height="260" viewBox="-10 -10 240 260" xmlns="http://www.w3.org/2000/svg"><g id="main-pointe">{fixe_ids(main_svg("pointe"), "main-pointe")}</g></svg>')
print("ok", f"index {(tx+10)/240*100:.1f}% {(ty+10)/260*100:.1f}%", f"plateau vue dessus ({DCX},{DCY}) r={DR}")
