"""Storyboard de l'animation de lancement d'un vinyle (aller + retour) et planche des éléments.
Réutilise la scène d'accueil et la main néon des scripts de Louise (dossier passé en argument)."""
import sys, re, math
SCENE_DIR = sys.argv[1]
sys.path.insert(0, SCENE_DIR)
import export_mvp2  # noqa: F401  (prolonge mur et sol)
import export_mvp as E
import gen5 as G5
import gen3 as G3
from gen2 import POSE, tip_of
from html import escape

INK = "#F5F3FF"; BG = "#0B0B12"; SURF = "#17171F"; PINK = "#FF4FA0"; DARK = "#2A0E5A"
SOLEIL = "#FFC46B"; BLEU = "#3B82F6"; VIOLET = "#8B5CF6"; VNEON = "#B23FE0"; ORANGE = "#FB8C80"; LAV = "#C084FC"
COULEURS = [("Connect", PINK), ("Indice de prix", SOLEIL), ("Benchmarks", BLEU), ("Checkout Picard", VNEON),
            ("Expériences", ORANGE), ("Formations", VIOLET), ("Contact", INK)]
COL = PINK  # couleur du vinyle sélectionné dans le storyboard (Connect)

_, POSV = G5.meuble(hover=None)
SX, SY = POSV["vinyle-connect"]          # haut de la tranche du vinyle Connect (452, 570)
PLX, PLY = 700, 494                      # centre du plateau de la platine (vue de face)


def T(x, y, s, size=16, fill=INK, w=400, anchor="start", op=1, fam="Nunito, Inter, sans-serif", italic=False, ls=0):
    it = ' font-style="italic"' if italic else ""
    return (f'<text x="{x}" y="{y}" font-family="{fam}" font-size="{size}" font-weight="{w}" fill="{fill}" fill-opacity="{op}" '
            f'text-anchor="{anchor}" letter-spacing="{ls}"{it}>{escape(s)}</text>')


# ------------------------------------------------------------------ scène d'accueil (platine vide)
SCENE = E.scene()
SCENE = re.sub(r'<g id="vinyle-platine">.*?</g>',
               f'<g id="plateau-vide"><ellipse cx="{PLX}" cy="{PLY}" rx="84" ry="15" fill="#1F1F29" stroke="{INK}" stroke-opacity="0.25" stroke-width="1.5"/>'
               f'<circle cx="{PLX}" cy="{PLY}" r="1.6" fill="{INK}"/></g>', SCENE, count=1)
SCENE_BODY = SCENE[SCENE.index(">") + 1: SCENE.rindex("</svg>")]


# ------------------------------------------------------------------ éléments dessinés
# ------------------------------------------------------------------ mains (module mains.py)
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from mains import main, main_svg, melange, POSES as POSES_MAIN, bout


def tenue(P, pose, s, rot=0, gauche=False):
    """Main qui tient un objet : (paume + doigts DERRIÈRE l'objet, pouce DEVANT)."""
    return (main(P, pose, s, rot=rot, gauche=gauche, partie="dos"), main(P, pose, s, rot=rot, gauche=gauche, partie="pouce"))


def disque(cx, cy, r, col=COL, angle=0, id="vinyle", op=1):
    """Disque vu de face ou de dessus (même dessin : c'est ce qui permet le raccord)."""
    g = "".join(f'<circle cx="{cx}" cy="{cy}" r="{r*k:.1f}" fill="none" stroke="#33334A" stroke-width="{max(0.6, r/120):.1f}"/>' for k in (0.5, 0.58, 0.66, 0.74, 0.82, 0.9))
    lr = r * 0.33
    lab = (f'<g id="etiquette" transform="rotate({angle} {cx} {cy})"><circle cx="{cx}" cy="{cy}" r="{lr:.1f}" style="fill:var(--couleur-vinyle, {col})" fill="{col}"/>'
           f'<path d="M{cx-lr*0.7:.1f} {cy+lr*0.15:.1f} H{cx+lr*0.7:.1f} M{cx-lr*0.55:.1f} {cy+lr*0.4:.1f} H{cx+lr*0.55:.1f}" stroke="{DARK}" stroke-opacity="0.5" stroke-width="{max(1, r/60):.1f}"/>'
           f'<path d="M{cx-lr*0.5:.1f} {cy-lr*0.35:.1f} H{cx+lr*0.5:.1f}" stroke="{DARK}" stroke-width="{max(1.5, r/40):.1f}" stroke-linecap="round"/></g>')
    return (f'<g id="{id}" opacity="{op}"><circle cx="{cx}" cy="{cy}" r="{r}" fill="#0E0E16" stroke="{col}" stroke-opacity="0.85" stroke-width="{max(1, r/70):.1f}"/>{g}'
            f'<path d="M{cx-r*0.66:.1f} {cy-r*0.6:.1f} A{r*0.9:.1f} {r*0.9:.1f} 0 0 1 {cx+r*0.1:.1f} {cy-r*0.89:.1f}" stroke="#FFF" stroke-opacity="0.12" stroke-width="{r*0.08:.1f}" fill="none" stroke-linecap="round"/>'
            f'{lab}<circle cx="{cx}" cy="{cy}" r="{max(1.5, r*0.03):.1f}" fill="{INK}"/></g>')


def pochette(x, y, w, col=COL, rot=0, id="pochette", op=1):
    """Pochette du vinyle (même couleur que le disque)."""
    c = f' transform="rotate({rot} {x+w/2} {y+w/2})"' if rot else ""
    return (f'<g id="{id}" opacity="{op}"{c}><rect x="{x}" y="{y}" width="{w}" height="{w}" rx="{w*0.03:.1f}" style="fill:var(--couleur-vinyle, {col})" fill="{col}"/>'
            f'<rect x="{x}" y="{y}" width="{w}" height="{w}" rx="{w*0.03:.1f}" fill="url(#gPochette)"/>'
            f'<circle cx="{x+w*0.62:.1f}" cy="{y+w*0.5:.1f}" r="{w*0.3:.1f}" fill="{DARK}" fill-opacity="0.35"/>'
            + "".join(f'<path d="M{x+w*0.1:.1f} {y+w*(0.2+i*0.08):.1f} H{x+w*0.42:.1f}" stroke="{INK}" stroke-opacity="0.7" stroke-width="{max(1, w/60):.1f}" stroke-linecap="round"/>' for i in range(3))
            + f'<rect x="{x}" y="{y}" width="{w}" height="{w}" rx="{w*0.03:.1f}" fill="none" stroke="#FFFFFF" stroke-opacity="0.35" stroke-width="{max(1, w/90):.1f}"/></g>')


def tranche(x, y, col=COL, op=1, h=96):
    return f'<rect x="{x-8}" y="{y}" width="16" height="{h}" rx="2.5" fill="{col}" opacity="{op}"/>'


def fleche(d, col=LAV, w=2.5, op=0.9):
    return (f'<path d="{d}" fill="none" stroke="{col}" stroke-opacity="{op}" stroke-width="{w}" stroke-dasharray="6 5" stroke-linecap="round" marker-end="url(#pointe)"/>')


# ------------------------------------------------------------------ vue de dessus (après le raccord)
TOP_S = 1.25; TOP_X, TOP_Y = 720 - 240 * TOP_S, 450 - 220 * TOP_S   # platine centrée, plateau en (720, 450)
DCX, DCY, DR = 720, 450, 182 * TOP_S                                # disque posé


def bras(angle):
    """Bras de lecture (repos = -30°, lecture = 0°), en coordonnées locales de la platine."""
    return (f'<g id="bras-platine" transform="rotate({angle} 480 86)"><rect x="496" y="128" width="26" height="62" rx="7" fill="#2C2C3A"/>'
            f'<path d="M480 86 L466 246 L366 300" stroke="#D9D6E8" stroke-width="8" fill="none" stroke-linecap="round" stroke-linejoin="round"/>'
            f'<rect id="cellule" x="330" y="290" width="44" height="26" rx="5" fill="{INK}" transform="rotate(-24 352 303)"/>'
            f'<circle cx="480" cy="86" r="30" fill="#24242F" stroke="{INK}" stroke-opacity="0.4" stroke-width="2"/><circle cx="480" cy="86" r="11" fill="#D9D6E8"/></g>')


def bras_tete(angle):
    """Position (vue de dessus, coordonnées scène) de la tête du bras."""
    a = math.radians(angle); dx, dy = 352 - 480, 303 - 86
    lx, ly = 480 + dx * math.cos(a) - dy * math.sin(a), 86 + dx * math.sin(a) + dy * math.cos(a)
    return TOP_X + lx * TOP_S, TOP_Y + ly * TOP_S


def rpm_pos(which):
    return (TOP_X + (445 if which == 33 else 503) * TOP_S, TOP_Y + 388 * TOP_S)


def platine_dessus(angle_bras=-30, rpm=None, col=COL):
    on33 = rpm == 33
    s = f'<g id="platine-dessus" transform="translate({TOP_X} {TOP_Y}) scale({TOP_S})">'
    s += f'<ellipse cx="280" cy="230" rx="330" ry="270" fill="url(#gHaloTop)"/>'
    s += (f'<g id="socle"><rect x="4" y="4" width="552" height="432" rx="28" fill="#1A1426" stroke="{PINK}" stroke-opacity="0.25" stroke-width="12"/>'
          f'<rect x="4" y="4" width="552" height="432" rx="28" fill="none" stroke="{PINK}" stroke-width="2.5"/></g>')
    s += f'<circle id="plateau" cx="240" cy="220" r="192" fill="#1F1F29" stroke="{INK}" stroke-opacity="0.2" stroke-width="2"/><circle cx="240" cy="220" r="5" fill="{INK}"/>'
    s += (f'<g id="bouton-start"><circle cx="56" cy="384" r="22" fill="#24242F" stroke="{INK}" stroke-opacity="0.4" stroke-width="2"/><circle cx="56" cy="384" r="7" fill="{PINK if rpm else "#555"}"/></g>')
    s += (f'<g id="selecteur-rpm"><rect x="420" y="372" width="50" height="32" rx="8" fill="{PINK if on33 else "#2A2A36"}" stroke="{PINK}" stroke-width="2"/>'
          f'<rect x="478" y="372" width="50" height="32" rx="8" fill="#2A2A36" stroke="{PINK}" stroke-width="2"/>'
          f'<text x="445" y="394" font-family="Nunito" font-size="15" font-weight="700" fill="{INK}" text-anchor="middle">33</text>'
          f'<text x="503" y="394" font-family="Nunito" font-size="15" font-weight="700" fill="{INK}" text-anchor="middle">45</text></g>')
    return s + "</g>"


def decor_dessus():
    """Le dessus du meuble vu d'en haut : ampli (stéréo) et casque à droite, plante en haut à gauche."""
    s = f'<rect x="-400" y="-300" width="2240" height="1500" fill="#0E0A18"/>'
    s += f'<rect id="dessus-meuble" x="-200" y="110" width="1840" height="720" fill="#1B1230"/>'
    s += "".join(f'<path d="M-200 {y} H1640" stroke="#241A3D" stroke-width="2"/>' for y in range(150, 830, 46))
    s += f'<path d="M-200 830 H1640" stroke="{LAV}" stroke-width="3" stroke-opacity="0.8"/><path d="M-200 830 H1640" stroke="{LAV}" stroke-width="12" stroke-opacity="0.15"/>'
    # ampli (stéréo) vu de dessus
    ax, ay = 1170, 300
    s += (f'<g id="ampli-dessus"><rect x="{ax}" y="{ay}" width="230" height="150" rx="10" fill="#120B1E" stroke="{SOLEIL}" stroke-width="2.5"/>'
          f'<rect x="{ax}" y="{ay}" width="230" height="150" rx="10" fill="none" stroke="{SOLEIL}" stroke-opacity="0.2" stroke-width="10"/>'
          + "".join(f'<path d="M{ax+20} {ay+20+i*12} H{ax+210}" stroke="{SOLEIL}" stroke-opacity="0.25" stroke-width="2"/>' for i in range(5))
          + f'<rect x="{ax+20}" y="{ay+92}" width="70" height="38" rx="4" fill="{SOLEIL}" fill-opacity="0.85"/>'
          + f'<circle cx="{ax+140}" cy="{ay+111}" r="16" fill="none" stroke="{SOLEIL}" stroke-width="2.5"/><circle cx="{ax+190}" cy="{ay+111}" r="16" fill="none" stroke="{SOLEIL}" stroke-width="2.5"/></g>')
    # casque
    cx, cy = 1290, 610
    s += (f'<g id="casque-dessus" fill="none" stroke="{BLEU}" stroke-width="3"><path d="M{cx-70} {cy} A70 52 0 0 1 {cx+70} {cy}"/>'
          f'<rect x="{cx-92}" y="{cy-8}" width="40" height="58" rx="18" fill="#101528"/><rect x="{cx+52}" y="{cy-8}" width="40" height="58" rx="18" fill="#101528"/>'
          f'<path d="M{cx-70} {cy} A70 52 0 0 1 {cx+70} {cy}" stroke-opacity="0.2" stroke-width="12"/></g>')
    # plante (feuilles vues du dessus)
    px, py = 130, 190
    s += '<g id="plante-dessus">' + "".join(
        f'<ellipse cx="{px+70*math.cos(math.radians(a)):.0f}" cy="{py+70*math.sin(math.radians(a)):.0f}" rx="62" ry="20" fill="#1E6B4F" stroke="#2DD4BF" stroke-opacity="0.6" stroke-width="2" transform="rotate({a} {px+70*math.cos(math.radians(a)):.0f} {py+70*math.sin(math.radians(a)):.0f})"/>'
        for a in range(0, 360, 45)) + f'<circle cx="{px}" cy="{py}" r="34" fill="#3B2A1E" stroke="#6B4A33" stroke-width="3"/></g>'
    return s


def ombre(cx, cy, r, dx=18, dy=22, op=0.45):
    return f'<circle cx="{cx+dx}" cy="{cy+dy}" r="{r}" fill="#000" fill-opacity="{op}" filter="url(#flou)"/>'


# ------------------------------------------------------------------ cadrage : une « caméra » = un viewBox
def cadre(vb, body, x, y, w=720, h=450):
    return (f'<svg x="{x}" y="{y}" width="{w}" height="{h}" viewBox="{vb[0]} {vb[1]} {vb[2]} {vb[3]}" preserveAspectRatio="xMidYMid slice">'
            f'{body}</svg><rect x="{x}" y="{y}" width="{w}" height="{h}" rx="6" fill="none" stroke="{INK}" stroke-opacity="0.25"/>')


VB_ACCUEIL = (0, 0, 1440, 900)
VB_PRISE = (250, 370, 600, 375)
VB_SORTIE = (380, 330, 560, 350)
VB_RETOURNE = (575, 330, 330, 206)
VB_DESSUS = (80, 40, 1360, 850)
VB_PROJET = (0, 0, 1440, 900)


# ------------------------------------------------------------------ images clés (aller)
def f_accueil():
    b = SCENE_BODY
    b += f'<rect x="{SX-13}" y="{SY-14}" width="26" height="110" rx="9" fill="{COL}" fill-opacity="0.4"/>' + tranche(SX, SY - 8) + \
        f'<rect x="{SX-8}" y="{SY-8}" width="16" height="96" rx="2.5" fill="none" stroke="#FFF" stroke-width="1.5"/>'
    b += G3.cursor(SX, SY + 8, s=0.32)
    return VB_ACCUEIL, b


def f_trajet():
    """Plan de l'accueil avec le trajet de la caméra et des mains."""
    b = SCENE_BODY + f'<rect x="-400" y="-100" width="2300" height="1100" fill="{BG}" fill-opacity="0.45"/>'
    for i, (vb, lab) in enumerate([(VB_PRISE, "2"), (VB_SORTIE, "3"), (VB_RETOURNE, "4")]):
        b += f'<rect x="{vb[0]}" y="{vb[1]}" width="{vb[2]}" height="{vb[3]}" fill="none" stroke="{SOLEIL}" stroke-width="3" stroke-dasharray="10 6"/>'
        b += f'<circle cx="{vb[0]+18}" cy="{vb[1]+18}" r="14" fill="{SOLEIL}"/>' + T(vb[0] + 18, vb[1] + 24, lab, 16, BG, 800, "middle")
    b += fleche(f"M{SX} {SY+40} C{SX} {SY-80} {PLX-140} {PLY-110} {PLX} {PLY-60}", PINK, 4)
    b += f'<circle cx="{SX}" cy="{SY+40}" r="8" fill="{PINK}"/><circle cx="{PLX}" cy="{PLY-30}" r="10" fill="none" stroke="{PINK}" stroke-width="3"/>'
    b += T(PLX + 30, PLY - 60, "puis bascule en vue de dessus", 20, PINK, 700)
    return VB_ACCUEIL, b


def f_prise():
    b = SCENE_BODY + f'<rect x="{SX-8}" y="{SY}" width="16" height="96" fill="#0B0814"/>'
    d, p = tenue((SX, SY - 36), "pince", 0.3, rot=-10)
    b += d + tranche(SX, SY - 46) + p
    b += fleche(f"M{SX+24} {SY+20} V{SY-30}", LAV)
    return VB_PRISE, b


def f_sortie():
    b = SCENE_BODY + f'<rect x="{SX-8}" y="{SY}" width="16" height="96" fill="#0B0814"/>'
    px, py, w = 470, 360, 104
    dg, pg = tenue((px + 6, py + w / 2 + 6), "pince", 0.27, rot=-60, gauche=True)
    dd, pd = tenue((px + w / 2 + 98, py + w / 2 + 10), "tient", 0.27, rot=-70)
    b += dg + dd + disque(px + w / 2 + 52, py + w / 2, 48) + pochette(px, py, w) + pg + pd
    b += fleche(f"M{px+w+60} {py-14} H{px+w+120}", LAV)
    return VB_SORTIE, b


def f_retourne():
    b = SCENE_BODY + f'<rect x="{SX-8}" y="{SY}" width="16" height="96" fill="#0B0814"/>'
    b += pochette(560, 452, 64, rot=-6, op=0.95)           # pochette posée contre la platine
    cx, cy, r = PLX + 20, 430, 54
    dg, pg = tenue((cx - r + 12, cy + 4), "tient", 0.25, rot=-70, gauche=True)
    dd, pd = tenue((cx + r - 12, cy + 8), "tient", 0.25, rot=-70)
    b += dg + dd + disque(cx, cy, r, angle=25) + pg + pd
    for k in (0.25, 0.6):   # étapes du demi-tour (le disque s'aplatit puis s'élargit)
        b += f'<ellipse cx="{cx}" cy="{cy}" rx="{r*k:.1f}" ry="{r}" fill="none" stroke="{LAV}" stroke-opacity="0.7" stroke-width="1.5" stroke-dasharray="4 4"/>' 
    b += f'<path d="M{cx-r-30} {cy-r+6} A{r+34} {r+34} 0 0 1 {cx+r+20} {cy-r-4}" fill="none" stroke="{LAV}" stroke-width="2.5" marker-end="url(#pointe)"/>'
    return VB_RETOURNE, b


def top(body):
    return decor_dessus() + body


def f_dessus_tenu():
    s = 1.12
    b = top(platine_dessus(-30) + f'<g transform="translate({TOP_X} {TOP_Y}) scale({TOP_S})">{bras(-30)}</g>' + pochette(40, 420, 300, rot=-10) + ombre(DCX, DCY, DR, 40, 50, 0.5)
            + "".join(tenue((DCX - DR * s + 4, DCY + 20), "tient", 0.75, rot=-70, gauche=True)[:1]) + "".join(tenue((DCX + DR * s - 4, DCY + 30), "tient", 0.75, rot=-70)[:1])
            + disque(DCX, DCY - 10, DR * s, angle=25)
            + tenue((DCX - DR * s + 4, DCY + 20), "tient", 0.75, rot=-70, gauche=True)[1] + tenue((DCX + DR * s - 4, DCY + 30), "tient", 0.75, rot=-70)[1])
    return VB_DESSUS, b


def f_pose():
    b = top(platine_dessus(-30) + pochette(40, 420, 300, rot=-10) + ombre(DCX, DCY, DR, 6, 8, 0.4) + disque(DCX, DCY, DR, angle=25) + f'<g transform="translate({TOP_X} {TOP_Y}) scale({TOP_S})">{bras(-30)}</g>'
            + main((DCX - DR - 40, DCY + 120), melange("tient", "ouverte", 0.75), 0.72, rot=-55, gauche=True, op=0.95, prise="ouverte")
            + main((DCX + DR + 40, DCY + 110), melange("tient", "ouverte", 0.75), 0.72, rot=-55, op=0.95, prise="ouverte")
            + fleche(f"M{DCX-DR-10} {DCY+60} l-60 60", LAV) + fleche(f"M{DCX+DR+10} {DCY+60} l60 50", LAV))
    return VB_DESSUS, b


def f_bras():
    hx, hy = bras_tete(0); gx, gy = bras_tete(-30)
    b = top(f'<g opacity="0.35" transform="translate({TOP_X} {TOP_Y}) scale({TOP_S})">{bras(-30)}</g>'
            + platine_dessus(0) + pochette(40, 420, 300, rot=-10) + disque(DCX, DCY, DR, angle=60)
            + f'<g transform="translate({TOP_X} {TOP_Y}) scale({TOP_S})">{bras(0)}</g>'
            + fleche(f"M{gx+20} {gy+40} Q{(gx+hx)/2+60} {(gy+hy)/2+90} {hx+30} {hy+30}", LAV)
            + main((hx + 6, hy + 8), "pince", 0.7, rot=-10))
    return VB_DESSUS, b


def f_33():
    px, py = rpm_pos(33)
    b = top(platine_dessus(0, 33) + pochette(40, 420, 300, rot=-10) + disque(DCX, DCY, DR, angle=110)
            + f'<g transform="translate({TOP_X} {TOP_Y}) scale({TOP_S})">{bras(0)}</g>'
            + f'<circle cx="{px}" cy="{py}" r="34" fill="none" stroke="{PINK}" stroke-width="3" stroke-opacity="0.8"/>'
            + main((px, py - 4), "pointe", 0.62, rot=-8))
    return VB_DESSUS, b


def f_lecture():
    arcs = "".join(f'<path d="M{DCX+DR*k*math.cos(math.radians(a)):.0f} {DCY+DR*k*math.sin(math.radians(a)):.0f} A{DR*k:.0f} {DR*k:.0f} 0 0 1 {DCX+DR*k*math.cos(math.radians(a+40)):.0f} {DCY+DR*k*math.sin(math.radians(a+40)):.0f}" fill="none" stroke="{INK}" stroke-opacity="0.5" stroke-width="3" stroke-linecap="round"/>'
                   for k, a in [(0.95, 200), (0.95, 20), (0.78, 110), (0.78, 290)])
    b = top(platine_dessus(0, 33) + pochette(40, 420, 300, rot=-10) + disque(DCX, DCY, DR, angle=170) + arcs
            + f'<g transform="translate({TOP_X} {TOP_Y}) scale({TOP_S})">{bras(0)}</g>'
            + main((DCX + 380, DCY + 330), "ouverte", 0.7, rot=20, op=0.45) + main((DCX - 360, DCY + 340), "ouverte", 0.7, rot=20, gauche=True, op=0.45)
            + fleche(f"M{DCX+330} {DCY+200} l50 110", LAV) + fleche(f"M{DCX-320} {DCY+200} l-50 110", LAV))
    return VB_DESSUS, b


def f_projet():
    return VB_PROJET, page_vinyle("A", "lecture")


# ------------------------------------------------------------------ images clés (retour)
def r_reprise():
    hx, hy = bras_tete(-30)
    b = top(f'<g opacity="0.3" transform="translate({TOP_X} {TOP_Y}) scale({TOP_S})">{bras(0)}</g>'
            + platine_dessus(-30) + pochette(40, 420, 300, rot=-10)
            + tenue((DCX - DR + 2, DCY + 20), "tient", 0.72, rot=-70, gauche=True)[0] + disque(DCX, DCY, DR, angle=240)
            + f'<g transform="translate({TOP_X} {TOP_Y}) scale({TOP_S})">{bras(-30)}</g>'
            + main((hx + 6, hy + 8), "pince", 0.7, rot=-10)
            + tenue((DCX - DR + 2, DCY + 20), "tient", 0.72, rot=-70, gauche=True)[1])
    return VB_DESSUS, b


def r_souleve():
    s = 1.12
    b = top(platine_dessus(-30) + f'<g transform="translate({TOP_X} {TOP_Y}) scale({TOP_S})">{bras(-30)}</g>' + pochette(40, 420, 300, rot=-10) + ombre(DCX, DCY, DR, 40, 50, 0.5)
            + tenue((DCX - 120 - DR * s + 4, DCY + 10), "tient", 0.75, rot=-70, gauche=True)[0] + tenue((DCX - 120 + DR * s - 4, DCY + 20), "tient", 0.75, rot=-70)[0]
            + disque(DCX - 120, DCY - 20, DR * s, angle=260)
            + tenue((DCX - 120 - DR * s + 4, DCY + 10), "tient", 0.75, rot=-70, gauche=True)[1] + tenue((DCX - 120 + DR * s - 4, DCY + 20), "tient", 0.75, rot=-70)[1]
            + fleche(f"M{DCX-140} {DCY+300} l-150 40", LAV, 3))
    return VB_DESSUS, b


def r_range_pochette():
    b = SCENE_BODY + f'<rect x="{SX-8}" y="{SY}" width="16" height="96" fill="#0B0814"/>'
    px, py, w = 470, 380, 104
    dg, pg = tenue((px + 6, py + w / 2 + 6), "pince", 0.27, rot=-60, gauche=True)
    dd, pd = tenue((px + w / 2 + 76, py + w / 2 + 10), "tient", 0.27, rot=-70)
    b += dg + dd + disque(px + w / 2 + 30, py + w / 2, 48) + pochette(px, py, w) + pg + pd
    b += fleche(f"M{px+w+90} {py-14} H{px+w+30}", LAV)
    return VB_SORTIE, b


def r_range_casier():
    b = SCENE_BODY + f'<rect x="{SX-8}" y="{SY}" width="16" height="96" fill="#0B0814"/>' + tranche(SX, SY - 40)
    b += main((SX + 2, SY - 34), "pointe", 0.3, rot=-6)
    b += fleche(f"M{SX+30} {SY-60} V{SY-6}", LAV)
    return (150, 220, 1140, 712), b


def r_accueil():
    return VB_ACCUEIL, SCENE_BODY


# ------------------------------------------------------------------ page projet : disque fixe en fond + scratch
def page_vinyle(option="A", etat="lecture"):
    """Page projet (1440 x 900). Option A : demi-disque en gros plan à gauche. Option B : disque entier, transparent, sous le contenu."""
    ang = {"lecture": 30, "bas": 75, "haut": -15, "arret": 45}[etat]
    if option == "A":
        cx, cy, r, op = 60, 470, 600, 0.6
    else:
        cx, cy, r, op = 560, 470, 430, 0.28
    b = f'<rect x="-300" y="-200" width="2040" height="1300" fill="{BG}"/>'
    b += f'<g id="vinyle-fond" opacity="{op}">{disque(cx, cy, r, angle=ang)}</g><!--MAIN-FOND-->'
    if option == "A":   # fondu noir : le disque reste un fond, le texte passe par-dessus sans le combattre
        b += (f'<linearGradient id="gFonduDisque" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="{BG}" stop-opacity="0.15"/>'
              f'<stop offset="0.22" stop-color="{BG}" stop-opacity="0.35"/><stop offset="0.42" stop-color="{BG}" stop-opacity="0.85"/>'
              f'<stop offset="0.6" stop-color="{BG}" stop-opacity="0.97"/></linearGradient><rect x="-300" y="0" width="1740" height="900" fill="url(#gFonduDisque)"/>'
              f'<linearGradient id="gFonduHautBas" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="{BG}" stop-opacity="0.6"/><stop offset="0.25" stop-color="{BG}" stop-opacity="0"/>'
              f'<stop offset="0.8" stop-color="{BG}" stop-opacity="0"/><stop offset="1" stop-color="{BG}" stop-opacity="0.7"/></linearGradient><rect x="-300" y="0" width="1740" height="900" fill="url(#gFonduHautBas)"/>')
    # contenu (par-dessus le disque)
    b += f'<rect x="0" y="0" width="1440" height="72" fill="{BG}" fill-opacity="0.92"/><path d="M0 72 H1440" stroke="{PINK}" stroke-opacity="0.35"/>'
    b += T(48, 46, "Louise Bury", 26, PINK, 400, fam="Tilt Neon")
    b += f'<rect x="420" y="21" width="130" height="30" rx="15" fill="none" stroke="{INK}" stroke-opacity="0.6"/>' + T(485, 41, "← Bibliothèque", 13, INK, 600, "middle")
    nx = 590
    for i, (n, c) in enumerate(COULEURS):
        b += f'<circle cx="{nx}" cy="36" r="5" fill="{c}" fill-opacity="{1 if i == 0 else 0.5}"/>' + T(nx + 11, 40, n, 12, INK, 800 if i == 0 else 600, op=1 if i == 0 else 0.55)
        nx += 30 + len(n) * 7
    x0 = 430 if option == "A" else 640   # option A : contenu décalé à gauche, sur le disque
    b += f'<rect x="{x0-24}" y="84" width="788" height="44" rx="22" fill="{SURF}" fill-opacity="0.9" stroke="{INK}" stroke-opacity="0.12"/>'
    for i, (lab, w) in enumerate([("Contexte", 110), ("Problématique", 150), ("Réalisations", 136), ("Résultats", 110)]):
        xx = x0 + 4 + sum([110, 150, 136, 110][:i]) + i * 10
        if i == 0:
            b += f'<rect x="{xx}" y="90" width="{w}" height="32" rx="16" fill="{PINK}" fill-opacity="0.18" stroke="{PINK}" stroke-opacity="0.8"/>'
        b += T(xx + w / 2, 111, lab, 14.5, INK, 800 if i == 0 else 600, "middle", op=1 if i == 0 else 0.6)
    b += T(x0, 186, "ÉTUDE DE CAS · TRANSPORT B2B", 14, SOLEIL, 800, ls=4)
    b += T(x0, 246, "Lancement du produit", 48, PINK, 400, fam="Tilt Neon") + T(x0, 304, "Connect", 48, PINK, 400, fam="Tilt Neon")
    for i, w in enumerate([720, 690, 420]):
        b += f'<rect x="{x0}" y="{336+i*30}" width="{w}" height="12" rx="6" fill="{INK}" fill-opacity="0.3"/>'
    b += f'<rect x="{x0}" y="440" width="740" height="200" rx="16" fill="{SURF}" fill-opacity="0.88" stroke="{INK}" stroke-opacity="0.14"/>'
    for i in range(6):
        xx = x0 + 28 + (i % 2) * 370; yy = 486 + (i // 2) * 56
        b += f'<rect x="{xx}" y="{yy-12}" width="90" height="9" rx="4" fill="{PINK}" fill-opacity="0.7"/><rect x="{xx}" y="{yy+6}" width="220" height="12" rx="6" fill="{INK}" fill-opacity="0.55"/>'
    for i in range(4):
        b += f'<rect x="{x0+i*188}" y="664" width="176" height="130" rx="14" fill="{PINK}" fill-opacity="0.12" stroke="{PINK}" stroke-opacity="0.35"/>'
        b += f'<rect x="{x0+i*188+18}" y="690" width="70" height="30" rx="6" fill="{SOLEIL}" fill-opacity="0.75"/>'
    # barre de défilement
    pos_curseur = {"lecture": 120, "bas": 260, "haut": 200, "arret": 240}[etat]
    b += f'<rect x="1426" y="80" width="6" height="810" rx="3" fill="{INK}" fill-opacity="0.08"/><rect x="1426" y="{80+pos_curseur}" width="6" height="140" rx="3" fill="{INK}" fill-opacity="0.45"/>'
    # main qui scratche
    if option == "A":
        P, s, rot = (240, 650), 0.9, -36
    else:
        P, s, rot = (300, 330), 0.9, -18
    d = math.hypot(P[0] - cx, P[1] - cy); a0 = math.degrees(math.atan2(P[1] - cy, P[0] - cx))
    def arc(a1, a2):
        x1, y1 = cx + d * math.cos(math.radians(a1)), cy + d * math.sin(math.radians(a1))
        x2, y2 = cx + d * math.cos(math.radians(a2)), cy + d * math.sin(math.radians(a2))
        sweep = 1 if a2 > a1 else 0
        return f'<path d="M{x1:.0f} {y1:.0f} A{d:.0f} {d:.0f} 0 0 {sweep} {x2:.0f} {y2:.0f}" fill="none" stroke="{SOLEIL}" stroke-width="5" stroke-linecap="round" marker-end="url(#pointeJaune)"/>'
    mf = ""   # la main fait partie du fond : elle passe sous le fondu noir, comme le disque
    if etat in ("bas", "haut"):
        mf = main(P, "scratch", s, rot=rot, pression=True, op=0.85)
    elif etat == "arret":
        mf = main((P[0] - 60, P[1] + 120), melange("scratch", "ouverte", 0.6), s, rot=rot - 10, op=0.5, prise="ouverte")
    b = b.replace("<!--MAIN-FOND-->", f'<g id="main-fond">{mf}</g>')
    if etat == "bas":
        b += arc(a0 - 22, a0 + 26)
        b += f'<path d="M1400 {80+pos_curseur+40} v60" stroke="{SOLEIL}" stroke-width="4" marker-end="url(#pointeJaune)"/>'
    elif etat == "haut":
        b += arc(a0 + 22, a0 - 26)
        b += f'<path d="M1400 {80+pos_curseur+100} v-60" stroke="{SOLEIL}" stroke-width="4" marker-end="url(#pointeJaune)"/>'
    elif etat == "arret":
        b += fleche(f"M{P[0]+10} {P[1]-40} L{P[0]-50} {P[1]+60}", LAV, 4)
    return b


def planche_page():
    W = 1600; PW, PH = 720, 450; X1, X2 = 60, 820
    o = T(60, 80, "Page projet · le disque en fond et le scratch au défilement", 34, PINK, 400, fam="Tilt Neon")
    o += T(60, 114, "Option A retenue : un demi-disque en gros plan, en vrai fond (fondu noir), le contenu décalé à gauche passe par-dessus.", 17, INK, 400, op=0.75)
    y = 170

    def panneau(x, y, titre, lignes, body):
        s = T(x, y, titre, 22, INK, 800)
        for i, l in enumerate(lignes):
            s += T(x, y + 28 + i * 21, l, 15, INK, 400, op=0.75)
        return s + cadre((0, 0, 1440, 900), body, x, y + 70, PW, PH)

    def carte(x, y, titre, items):
        s = f'<rect x="{x}" y="{y}" width="{PW}" height="{PH+70}" rx="12" fill="{SURF}" stroke="{LAV}" stroke-opacity="0.5"/>' + T(x + 30, y + 46, titre, 22, LAV, 800)
        for i, (k, v) in enumerate(items):
            s += T(x + 30, y + 100 + i * 64, k, 16, INK, 800) + T(x + 30, y + 124 + i * 64, v, 15, INK, 400, op=0.75)
        return s
    o += panneau(X1, y, "1 · Lecture", ["Le visiteur lit : pas de main. Le disque, très atténué,", "tourne doucement dans le sens horaire (33 tours)."], page_vinyle("A", "lecture"))
    o += carte(X2, y - 22, "Les couches, du fond vers l'avant", [
        ("1. Le disque", "Demi-disque fixe à gauche, opacité 60 %, il tourne en continu."),
        ("2. Le fondu noir", "Dégradé de gauche à droite + haut et bas : le disque s'efface sous le texte."),
        ("3. La main", "Elle fait partie du fond : sous le fondu noir, comme le disque. Seulement pendant le défilement."),
        ("4. Le contenu", "Décalé à gauche, il chevauche le disque : les deux forment un seul ensemble."),
        ("Le disque ne capte aucun clic", "C'est un fond : rien ne gêne la lecture ni la navigation.")])
    y += PH + 140
    etats = [("bas", "2 · Défilement vers le bas", ["La main se pose et appuie (doigts écrasés, traits de pression)", "puis scratche dans le sens horaire, à la vitesse du défilement."]),
             ("haut", "3 · Défilement vers le haut", ["Même geste, sens anti-horaire : le disque recule", "avec la page."]),
             ("arret", "4 · Arrêt du défilement", ["0,6 s après le dernier mouvement, la main se détend,", "puis repart par le bas. Le disque reprend sa rotation normale."])]
    for i, (e, titre, lignes) in enumerate(etats):
        x = X1 if i % 2 == 0 else X2
        o += panneau(x, y, titre, lignes, page_vinyle("A", e))
        if i % 2 == 1:
            y += PH + 140
    o += carte(X2, y - 22, "Règles", [
        ("La main suit le défilement", "Sa vitesse de rotation dépend de la distance défilée."),
        ("Pendant les animations de wireframes", "La main reste hors champ, pour ne pas distraire."),
        ("« Réduire les animations »", "Disque immobile, pas de main."),
        ("Mobile", "Disque plus petit et encore plus atténué, sans main."),
        ("Petit écran (< 768 px)", "Le contenu reprend toute la largeur, le disque passe en fond centré.")])
    y += PH + 140
    H = y
    defs = DEFS.replace("</defs>", f'<marker id="pointeJaune" viewBox="0 0 10 10" refX="6" refY="5" markerWidth="4" markerHeight="4" orient="auto-start-reverse"><path d="M0 0 L10 5 L0 10 z" fill="{SOLEIL}"/></marker></defs>')
    return (f'<svg width="{W}" height="{H}" viewBox="0 0 {W} {H}" xmlns="http://www.w3.org/2000/svg">'
            f'<style>@import url(\'https://fonts.googleapis.com/css2?family=Tilt+Neon&amp;family=Nunito:wght@400;700;800&amp;display=swap\');</style>'
            f'{defs}<rect width="{W}" height="{H}" fill="#07070C"/>{o}</svg>')


# ------------------------------------------------------------------ mise en page du storyboard
DEFS = (f'<defs><linearGradient id="gPochette" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#FFFFFF" stop-opacity="0.25"/><stop offset="1" stop-color="#000" stop-opacity="0.2"/></linearGradient>'
        f'<radialGradient id="gHaloTop"><stop offset="0" stop-color="{PINK}" stop-opacity="0.25"/><stop offset="1" stop-color="{PINK}" stop-opacity="0"/></radialGradient>'
        f'<filter id="flou" x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur stdDeviation="14"/></filter>'
        f'<marker id="pointe" viewBox="0 0 10 10" refX="6" refY="5" markerWidth="5" markerHeight="5" orient="auto-start-reverse"><path d="M0 0 L10 5 L0 10 z" fill="{LAV}"/></marker></defs>')

ALLER = [
    (f_trajet, "Plan d'ensemble", "", ["Trajet de la caméra (cadres 2, 3, 4) et des mains : un seul sens,", "de la bibliothèque vers la platine, sans aller-retour."]),
    (f_accueil, "1 · Clic sur le vinyle", "0 s", ["Le visiteur clique sur le vinyle rose (Connect).", "La main-curseur disparaît, les mains animées prennent le relais."]),
    (f_prise, "2 · La main prend le vinyle", "0 → 0,4 s", ["Zoom ×2 vers la bibliothèque. La main droite pince la tranche", "et tire le vinyle hors du casier."]),
    (f_sortie, "3 · Deuxième main, sortie du disque", "0,4 → 0,9 s", ["La caméra suit, en montant vers la platine.", "Main gauche : tient la pochette. Main droite : sort le disque."]),
    (f_retourne, "4 · Le disque tourne dans les mains", "0,9 → 1,2 s", ["Pochette posée contre la platine. Demi-tour rapide du disque", "(0,3 s, pendant que la caméra plonge dessus)."]),
    (f_dessus_tenu, "5 · Raccord : vue de dessus", "1,2 → 1,4 s", ["Le disque garde sa taille et sa place pendant la bascule.", "Le bras de lecture est déjà là, au repos, dès cette image."]),
    (f_pose, "6 · Pose du disque", "1,4 → 1,65 s", ["Le disque descend (l'ombre se resserre), les mains s'ouvrent.", "Autour : ampli (stéréo), casque, plante, pochette posée."]),
    (f_bras, "7 · Bras de lecture", "1,65 → 2,0 s", ["La main droite pince la tête du bras et le pivote", "de sa position de repos jusqu'au bord du disque."]),
    (f_33, "8 · 33 tours", "2,0 → 2,2 s", ["L'index appuie sur « 33 » : le bouton s'allume en rose.", "Le disque commence à tourner."]),
    (f_lecture, "9 · Les mains s'en vont", "2,2 → 2,5 s", ["Les mains sortent par le bas de l'écran.", "Le disque tourne, le bras est posé."]),
    (f_projet, "10 · La page projet s'affiche", "2,5 → 3,0 s", ["Le disque grossit et glisse à gauche, en fond (option A).", "Le contenu apparaît par-dessus. Voir la planche « page projet »."]),
]
RETOUR = [
    (r_reprise, "R1 · Retour à la bibliothèque", "0 → 0,3 s", ["Le contenu s'efface, le disque revient au centre.", "Main droite : remet le bras au repos. Main gauche : saisit le disque."]),
    (r_souleve, "R2 · Les mains soulèvent le disque", "0,3 → 0,65 s", ["Le disque grossit (il monte vers la caméra) et file", "vers la pochette : raccord vers la vue de face."]),
    (r_range_pochette, "R3 · Le disque rentre dans la pochette", "0,65 → 1,05 s", ["Vue de face, cadre 3. Main gauche : tient la pochette.", "Main droite : glisse le disque dedans."]),
    (r_range_casier, "R4 · Rangement et dézoom", "1,05 → 1,5 s", ["La pochette redevient une tranche, l'index la pousse", "dans le casier. La caméra recule vers l'accueil."]),
    (r_accueil, "R5 · Bibliothèque", "1,5 → 1,8 s", ["Les mains disparaissent, la main-curseur revient.", "Le vinyle est rangé à sa place."]),
]


def legende(x, y, titre, temps, lignes):
    s = T(x, y, titre, 22, INK, 800)
    if temps:
        w = len(temps) * 9 + 24
        s += f'<rect x="{x+720-w}" y="{y-22}" width="{w}" height="30" rx="15" fill="{PINK}" fill-opacity="0.15" stroke="{PINK}" stroke-opacity="0.6"/>'
        s += T(x + 720 - w / 2, y - 2, temps, 14, PINK, 800, "middle")
    for i, l in enumerate(lignes):
        s += T(x, y + 28 + i * 21, l, 15, INK, 400, op=0.75)
    return s


def frise_temps(x, y, w, etapes, total, titre):
    s = T(x, y, titre, 15, SOLEIL, 800, ls=3)
    y += 18
    t0 = 0
    for i, (lab, d) in enumerate(etapes):
        xx = x + w * t0 / total; ww = w * d / total
        s += f'<rect x="{xx+1}" y="{y}" width="{ww-2}" height="34" rx="6" fill="{PINK}" fill-opacity="{0.12 + 0.05*(i%2)}" stroke="{PINK}" stroke-opacity="0.5"/>'
        s += T(xx + ww / 2, y + 22, lab, 12, INK, 700, "middle")
        t0 += d
    for k in range(int(total) + 1):
        xx = x + w * k / total
        s += f'<path d="M{xx} {y+38} v8" stroke="{INK}" stroke-opacity="0.5"/>' + T(xx, y + 62, f"{k} s", 12, INK, 400, "middle", op=0.6)
    return s


def storyboard():
    W = 1600; X1, X2 = 60, 820; PW, PH = 720, 450; ROW = PH + 140
    out = ""
    y = 80
    out += T(60, y, "Animation de lancement d'un vinyle · storyboard", 36, PINK, 400, fam="Tilt Neon")
    out += T(60, y + 36, "Exemple avec le vinyle Connect (rose). Même animation pour les 7 vinyles : seule la couleur change.", 17, INK, 400, op=0.75)
    y += 90
    out += frise_temps(60, y, 1480, [("prise", 0.4), ("sortie", 0.5), ("tour", 0.3), ("raccord", 0.2), ("pose", 0.25),
                                      ("bras", 0.35), ("33", 0.2), ("mains", 0.3), ("page projet", 0.5)], 3.0, "ALLER : ENVIRON 3 SECONDES")
    y += 110
    out += frise_temps(60, y, 1480 * 1.8 / 3.0, [("R1", 0.3), ("R2", 0.35), ("R3", 0.4), ("R4", 0.45), ("R5", 0.3)], 1.8, "RETOUR : ENVIRON 1,8 SECONDE")
    y += 120
    out += T(60, y, "ALLER", 18, SOLEIL, 800, ls=4); y += 50
    for i, (fn, titre, temps, lignes) in enumerate(ALLER):
        x = X1 if i % 2 == 0 else X2
        vb, body = fn()
        out += legende(x, y, titre, temps, lignes) + cadre(vb, body, x, y + 70, PW, PH)
        if i % 2 == 1 or i == len(ALLER) - 1:
            y += ROW
    y += 20
    out += T(60, y, "RETOUR", 18, SOLEIL, 800, ls=4); y += 50
    for i, (fn, titre, temps, lignes) in enumerate(RETOUR):
        x = X1 if i % 2 == 0 else X2
        vb, body = fn()
        out += legende(x, y, titre, temps, lignes) + cadre(vb, body, x, y + 70, PW, PH)
        if i % 2 == 1 or i == len(RETOUR) - 1:
            y += ROW
    # règles
    x = X2; yy = y - ROW + 70
    regles = [("Clic pendant l'aller", "L'animation saute à la fin : page projet affichée, disque en lecture."),
              ("Clic pendant le retour", "La bibliothèque s'affiche directement, vinyle rangé."),
              ("« Réduire les animations »", "Aucune animation : fondu simple vers la page ou l'accueil."),
              ("Mobile", "Version courte (prise + pose) ou simple fondu : à trancher en 7.2."),
              ("Arrivée directe sur #connect", "Pas d'animation, la page projet s'affiche."),
              ("Bouton « Passer »", "Visible et accessible au clavier pendant toute l'animation.")]
    out += f'<rect x="{x}" y="{yy}" width="{PW}" height="{PH}" rx="12" fill="{SURF}" stroke="{LAV}" stroke-opacity="0.5"/>'
    out += T(x + 30, yy + 46, "Règles d'interruption", 22, LAV, 800)
    for i, (k, v) in enumerate(regles):
        out += T(x + 30, yy + 96 + i * 58, k, 16, INK, 800) + T(x + 30, yy + 118 + i * 58, v, 15, INK, 400, op=0.75)
    H = y + 40
    return (f'<svg width="{W}" height="{H}" viewBox="0 0 {W} {H}" xmlns="http://www.w3.org/2000/svg">'
            f'<style>@import url(\'https://fonts.googleapis.com/css2?family=Tilt+Neon&amp;family=Nunito:wght@400;700;800&amp;display=swap\');</style>'
            f'{DEFS}<rect width="{W}" height="{H}" fill="#07070C"/>{out}</svg>')


# ------------------------------------------------------------------ planche des éléments animables
def planche():
    W, H = 1600, 2190
    o = f'<rect width="{W}" height="{H}" fill="#07070C"/>'
    o += T(60, 80, "Éléments animables · un calque nommé par élément", 34, PINK, 400, fam="Tilt Neon")
    o += T(60, 114, "Les éléments colorés utilisent la variable CSS --couleur-vinyle : un seul fichier sert pour les 7 vinyles.", 17, INK, 400, op=0.75)

    def bloc(x, y, w, h, titre, ids, vb, body):
        s = f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="12" fill="{SURF}" stroke="{INK}" stroke-opacity="0.15"/>'
        s += T(x + 24, y + 38, titre, 20, INK, 800)
        s += T(x + 24, y + 62, ids, 13, LAV, 700)
        s += f'<svg x="{x+20}" y="{y+80}" width="{w-40}" height="{h-100}" viewBox="{vb}">{body}</svg>'
        return s
    o += bloc(60, 150, 720, 560, "Platine vue de dessus", "#socle  #plateau  #bras-platine  #cellule  #selecteur-rpm  #bouton-start",
              f"{TOP_X-20} {TOP_Y-20} {560*TOP_S+40} {440*TOP_S+40}",
              platine_dessus(-30) + f'<g opacity="0.3" transform="translate({TOP_X} {TOP_Y}) scale({TOP_S})">{bras(0)}</g>'
              + f'<g transform="translate({TOP_X} {TOP_Y}) scale({TOP_S})">{bras(-30)}</g>')
    o += bloc(820, 150, 720, 560, "Disque et pochette", "#vinyle  #etiquette  #pochette  #tranche", "0 0 720 440",
              disque(200, 220, 180) + pochette(410, 90, 240) + tranche(690, 110, h=240))
    poses = [("pince", "pince (saisir)"), ("tient", "tient (porter)"), ("ouverte", "ouverte (lâcher)"), ("pointe", "pointe (appuyer)"), ("scratch", "scratch (pression)")]
    body = ""
    for i, (p, lab) in enumerate(poses):
        cx = 150 + i * 285
        body += f'<g transform="translate({cx-95} 10) scale(0.85)">{main_svg(p, pression=(p == "scratch"))}</g>' + T(cx, 255, lab, 20, INK, 700, "middle")
    # gestuelle : prendre et porter
    y0 = 330
    body += T(20, y0, "Prendre le vinyle : la main s'approche, se referme, puis porte le disque (doigts derrière, pouce devant)", 20, SOLEIL, 800)
    etapes = [("ouverte", 70, "1. approche"), (melange("ouverte", "pince", 0.55), 30, "2. se referme"), ("pince", 0, "3. saisit la pochette"), ("tient", 0, "4. porte le disque")]
    for i, (pose, ecart, lab) in enumerate(etapes):
        bx = 40 + i * 350; by = y0 + 40
        if i == 3:
            dcx, dcy, dr = bx + 100, by + 130, 95
            d_, p_ = tenue((dcx + dr - 12, dcy + 10), "tient", 0.62, rot=-70)
            body += d_ + disque(dcx, dcy, dr) + p_
        else:
            P = (bx + 150 + ecart * 0.6, by + 110)
            nom = "ouverte" if i == 0 else "pince"
            d_, p_ = tenue(P, pose, 0.62, rot=-70) if i == 2 else (main(P, pose, 0.62, rot=-70, prise=nom), "")
            body += d_ + pochette(bx + 10, by + 40, 140, rot=-3) + p_
        body += T(bx + 140, by + 330, lab, 18, INK, 700, "middle")
    # gestuelle : lâcher et scratcher
    y1 = 760
    body += T(20, y1, "Poser puis lâcher : les doigts se déplient progressivement", 20, SOLEIL, 800)
    for i, tt in enumerate([0, 0.35, 0.7, 1]):
        bx = 40 + i * 200
        body += f'<g transform="translate({bx} {y1+30}) scale(0.72)">{main_svg(melange("tient", "ouverte", tt))}</g>'
        body += T(bx + 80, y1 + 230, f"{int(tt*100)} %", 16, INK, 700, "middle", op=0.7)
    body += T(860, y1, "Scratch : la main se pose, appuie, puis glisse", 20, SOLEIL, 800)
    for i, (pose, pr, lab) in enumerate([("ouverte", False, "se pose"), ("scratch", True, "appuie"), ("scratch", True, "glisse")]):
        bx = 860 + i * 190
        body += f'<rect x="{bx}" y="{y1+150}" width="170" height="60" rx="8" fill="#0E0E16" stroke="{PINK}" stroke-opacity="0.5"/>'
        body += f'<g transform="translate({bx+10} {y1+(10 if pr else -10)}) scale(0.68)">{main_svg(pose, pression=pr)}</g>'
        if i == 2:
            body += f'<path d="M{bx+20} {y1+60} q-14 30 0 60 M{bx+10} {y1+70} q-10 20 0 40" fill="none" stroke="{INK}" stroke-opacity="0.6" stroke-width="3" stroke-linecap="round"/>'
        body += T(bx + 85, y1 + 230, lab, 16, INK, 700, "middle", op=0.7)
    o += bloc(60, 740, 1480, 1080, "Mains (gant blanc, contour néon) · même dessin pour la main-curseur de l'accueil",
              "Paume + 5 doigts à 2 phalanges (.doigt, .phalange) : GSAP passe d'une pose à l'autre en continu, d'où des gestes souples",
              "0 0 1440 1000", body)
    sw = ""
    for i, (nom, c) in enumerate(COULEURS):
        cx = 70 + i * 140
        sw += pochette(cx - 50, 30, 100, col=c) + disque(cx, 210, 56, col=c) + T(cx, 300, nom, 15, INK, 700, "middle")
    o += bloc(60, 1850, 1480, 300, "Les 7 couleurs : pochette, tranche, étiquette", "--couleur-vinyle", "0 0 1000 320", sw)
    return f'<svg width="{W}" height="{H}" viewBox="0 0 {W} {H}" xmlns="http://www.w3.org/2000/svg">{DEFS}{o}</svg>'


if __name__ == "__main__":
    out = sys.argv[2]
    open(f"{out}/storyboard-lancement-vinyle.svg", "w", encoding="utf-8").write(storyboard())
    open(f"{out}/elements-animation-vinyle.svg", "w", encoding="utf-8").write(planche())
    open(f"{out}/page-projet-vinyle.svg", "w", encoding="utf-8").write(planche_page())
    tx, ty = bout(POSES_MAIN["pointe"][0])
    open(f"{out}/main-pointe.svg", "w", encoding="utf-8").write(
        f'<svg width="240" height="260" viewBox="-10 -10 240 260" xmlns="http://www.w3.org/2000/svg"><g id="main-pointe">{main_svg("pointe")}</g></svg>')
    print(f"bout de l'index : {(tx+10)/240*100:.1f} % / {(ty+10)/260*100:.1f} %")
    print("ok")
