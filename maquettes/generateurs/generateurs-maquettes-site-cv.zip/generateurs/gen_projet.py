"""Maquette SVG de la page projet « Lancement du produit Connect » (desktop 1440 px).
Vinyle fixe en arrière-plan (il tourne), contenu qui défile à droite.
Sorties : page complète + écrans successifs (défilement)."""
import sys
from html import escape

INK = "#F5F3FF"; BG = "#0B0B12"; SURF = "#17171F"; SURF2 = "#1E1A2B"
PINK = "#FF4FA0"; SOLEIL = "#FFC46B"; BLEU = "#3B82F6"; VIOLET = "#8B5CF6"
VNEON = "#B23FE0"; ORANGE = "#FB8C80"; LAVANDE = "#C084FC"; DARK = "#2A0E5A"
BODY = "Nunito, Inter, sans-serif"; NEON = "'Tilt Neon', Nunito, sans-serif"

W = 1440
LX = 48          # colonne gauche (panneau fixe)
CX, CW = 640, 740  # colonne de contenu

DEFS = f"""<defs>
<style>@import url('https://fonts.googleapis.com/css2?family=Monoton&amp;family=Tilt+Neon&amp;family=Nunito:wght@400;600;700;800&amp;display=swap');</style>
<linearGradient id="gNom" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#FFC46B"/><stop offset="0.3" stop-color="#FF8A6B"/><stop offset="0.6" stop-color="#FF4FA0"/><stop offset="1" stop-color="#B23FE0"/></linearGradient>
<linearGradient id="gSun" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#FFC46B"/><stop offset="0.5" stop-color="#FF8A6B"/><stop offset="1" stop-color="#FF4FA0"/></linearGradient>
<linearGradient id="gFond" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#0B0B12"/><stop offset="0.5" stop-color="#120B1F"/><stop offset="1" stop-color="#0B0B12"/></linearGradient>
<linearGradient id="gCarte" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#FF4FA0" stop-opacity="0.16"/><stop offset="1" stop-color="#8B5CF6" stop-opacity="0.06"/></linearGradient>
<radialGradient id="gHalo"><stop offset="0" stop-color="#FF4FA0" stop-opacity="0.35"/><stop offset="1" stop-color="#FF4FA0" stop-opacity="0"/></radialGradient>
</defs>"""


# ------------------------------------------------------------------ primitives
def t(x, y, s, size=16, fam=BODY, weight=400, fill=INK, op=1.0, anchor="start", ls=0, italic=False, id=None):
    i = f' id="{id}"' if id else ""
    st = ' font-style="italic"' if italic else ""
    return (f'<text{i} x="{x}" y="{y}" font-family="{fam}" font-size="{size}" font-weight="{weight}"{st} '
            f'fill="{fill}" fill-opacity="{op}" text-anchor="{anchor}" letter-spacing="{ls}">{escape(s)}</text>')


def wrap_lines(s, size, width, k=0.53):
    max_c = max(8, int(width / (size * k)))
    lines, cur = [], ""
    for w in s.split():
        if len(cur) + len(w) + 1 > max_c and cur:
            lines.append(cur); cur = w
        else:
            cur = f"{cur} {w}".strip()
    if cur: lines.append(cur)
    return lines


def para(x, y, s, size=16, width=CW, lh=None, **kw):
    """Paragraphe avec retour à la ligne. Renvoie (svg, y du bas)."""
    lh = lh or round(size * 1.55)
    ls = wrap_lines(s, size, width, 0.55 if kw.get("weight", 400) >= 700 else 0.53)
    out = "".join(t(x, y + i * lh, l, size, **kw) for i, l in enumerate(ls))
    return out, y + (len(ls) - 1) * lh


def bullets(x, y, items, width, size=15, color=PINK, gap=10, op=0.85):
    out = ""
    for it in items:
        out += f'<circle cx="{x+4}" cy="{y-5}" r="3.5" fill="{color}"/>'
        s, y = para(x + 18, y, it, size, width - 18, op=op)
        out += s
        y += round(size * 1.55) + gap
    return out, y


def card(x, y, w, h, stroke=INK, sop=0.14, fill=SURF, fop=0.9, r=16, glow=False, dash=None, id=None):
    i = f' id="{id}"' if id else ""
    d = f' stroke-dasharray="{dash}"' if dash else ""
    g = ""
    if glow:
        g = (f'<rect x="{x-6}" y="{y-6}" width="{w+12}" height="{h+12}" rx="{r+6}" fill="none" stroke="{stroke}" stroke-opacity="0.12" stroke-width="12"/>'
             f'<rect x="{x-2}" y="{y-2}" width="{w+4}" height="{h+4}" rx="{r+2}" fill="none" stroke="{stroke}" stroke-opacity="0.3" stroke-width="4"/>')
    return (f'<g{i}>{g}<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{r}" fill="{fill}" fill-opacity="{fop}" '
            f'stroke="{stroke}" stroke-opacity="{sop}" stroke-width="1.5"{d}/></g>')


def chip(x, y, label, color=INK, size=13, fill_op=0.0, h=30, bold=False):
    w = int(len(label) * size * 0.56) + 28
    return (f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{h/2}" fill="{color}" fill-opacity="{fill_op}" stroke="{color}" stroke-opacity="0.6" stroke-width="1.2"/>'
            + t(x + w / 2, y + h / 2 + size * 0.36, label, size, anchor="middle", weight=700 if bold else 600, op=0.92)), w


def neon_text(x, y, s, size, color=PINK, fam=NEON, anchor="start", id=None):
    i = f' id="{id}"' if id else ""
    base = f'x="{x}" y="{y}" font-family="{fam}" font-size="{size}" text-anchor="{anchor}"'
    s = escape(s)
    return (f'<g{i}><text {base} fill="none" stroke="{color}" stroke-opacity="0.22" stroke-width="{size*0.22:.1f}" stroke-linejoin="round">{s}</text>'
            f'<text {base} fill="{color}">{s}</text>'
            f'<text {base} fill="none" stroke="#FFFFFF" stroke-opacity="0.55" stroke-width="{max(size*0.02,0.6):.1f}">{s}</text></g>')


def icone(kind, cx, cy, color, r=18):
    """Petites icônes au trait, style néon."""
    s = f'<circle cx="{cx}" cy="{cy}" r="{r}" fill="{color}" fill-opacity="0.12" stroke="{color}" stroke-width="1.5"/>'
    st = f'stroke="{color}" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"'
    if kind == "formulaire":
        s += f'<rect x="{cx-7}" y="{cy-9}" width="14" height="18" rx="2" {st}/><path d="M{cx-3} {cy-3} H{cx+3} M{cx-3} {cy+2} H{cx+3}" {st}/>'
    elif kind == "telephone":
        s += f'<path d="M{cx-7} {cy-7} q0 14 14 14 l2 -4 l-4 -3 l-2 2 q-5 -2 -7 -7 l2 -2 l-3 -4 z" {st}/>'
    elif kind == "chrono":
        s += f'<circle cx="{cx}" cy="{cy+1}" r="8" {st}/><path d="M{cx} {cy+1} V{cy-4} M{cx-3} {cy-10} H{cx+3}" {st}/>'
    elif kind == "match":
        s += f'<circle cx="{cx-4}" cy="{cy}" r="6" {st}/><circle cx="{cx+4}" cy="{cy}" r="6" {st}/>'
    elif kind == "calendrier":
        s += f'<rect x="{cx-8}" y="{cy-7}" width="16" height="15" rx="2" {st}/><path d="M{cx-8} {cy-2} H{cx+8} M{cx-4} {cy-10} V{cy-5} M{cx+4} {cy-10} V{cy-5}" {st}/>'
    elif kind == "equipe":
        s += f'<circle cx="{cx-4}" cy="{cy-3}" r="3.5" {st}/><circle cx="{cx+5}" cy="{cy-3}" r="3.5" {st}/><path d="M{cx-10} {cy+8} q6 -8 12 0 M{cx} {cy+8} q5 -8 11 0" {st}/>'
    elif kind == "chantier":
        s += f'<path d="M{cx-8} {cy+7} L{cx} {cy-8} L{cx+8} {cy+7} Z M{cx} {cy-2} V{cy+2}" {st}/><circle cx="{cx}" cy="{cy+5}" r="0.8" fill="{color}"/>'
    elif kind == "deux":
        s += f'<rect x="{cx-9}" y="{cy-7}" width="8" height="14" rx="2" {st}/><rect x="{cx+1}" y="{cy-7}" width="8" height="14" rx="2" {st}/>'
    elif kind == "check":
        s += f'<path d="M{cx-7} {cy} l5 5 l9 -10" {st}/>'
    return s


# ------------------------------------------------------------------ vinyle en arrière-plan (fixe, il tourne)
VX, VY, VR = 250, 520, 400   # centre et rayon du vinyle, en coordonnées d'écran


def vinyle_fond(angle=0):
    cx, cy, r = VX, VY, VR
    s = '<g id="vinyle-fond">'
    s += f'<circle cx="{cx}" cy="{cy}" r="{r*1.35:.0f}" fill="url(#gHalo)"/>'
    s += f'<circle cx="{cx}" cy="{cy}" r="{r}" fill="#0E0E16" stroke="{PINK}" stroke-opacity="0.55" stroke-width="2"/>'
    s += f'<g id="disque-rotation" transform="rotate({angle} {cx} {cy})">'
    rr = r * 0.4
    while rr < r * 0.97:
        s += f'<circle cx="{cx}" cy="{cy}" r="{rr:.0f}" fill="none" stroke="#2E2E44" stroke-width="1.2"/>'
        rr += r * 0.045
    lr = r * 0.33
    s += (f'<g id="etiquette"><circle cx="{cx}" cy="{cy}" r="{lr:.0f}" fill="url(#gSun)"/>'
          f'<text x="{cx}" y="{cy-lr*0.28:.0f}" font-family="{NEON}" font-size="{r*0.085:.0f}" fill="{DARK}" text-anchor="middle">CONNECT</text>'
          f'<rect x="{cx-lr*0.75:.0f}" y="{cy+lr*0.18:.0f}" width="{lr*1.5:.0f}" height="4" fill="{DARK}" fill-opacity="0.45"/>'
          f'<rect x="{cx-lr*0.62:.0f}" y="{cy+lr*0.34:.0f}" width="{lr*1.24:.0f}" height="4" fill="{DARK}" fill-opacity="0.45"/>'
          f'<rect x="{cx-lr*0.48:.0f}" y="{cy+lr*0.5:.0f}" width="{lr*0.96:.0f}" height="4" fill="{DARK}" fill-opacity="0.45"/></g>')
    s += '</g>'
    s += f'<path d="M{cx-r*0.72:.0f} {cy-r*0.55:.0f} A{r*0.9:.0f} {r*0.9:.0f} 0 0 1 {cx+r*0.1:.0f} {cy-r*0.89:.0f}" stroke="#FFF" stroke-opacity="0.10" stroke-width="{r*0.08:.0f}" fill="none" stroke-linecap="round"/>'
    s += f'<path d="M{cx+r*0.72:.0f} {cy+r*0.55:.0f} A{r*0.9:.0f} {r*0.9:.0f} 0 0 1 {cx-r*0.1:.0f} {cy+r*0.89:.0f}" stroke="#FFF" stroke-opacity="0.05" stroke-width="{r*0.06:.0f}" fill="none" stroke-linecap="round"/>'
    s += f'<circle cx="{cx}" cy="{cy}" r="7" fill="{INK}"/>'
    return s + '</g>'


# ------------------------------------------------------------------ barres de navigation
SECTIONS = [("Contexte", "contexte"), ("Problématique", "problematique"),
            ("Réalisations", "realisations"), ("Résultats", "resultats")]


def barre_haut():
    s = '<g id="barre-haut">'
    s += f'<rect x="0" y="0" width="{W}" height="72" fill="{BG}" fill-opacity="0.92"/>'
    s += f'<line x1="0" y1="72" x2="{W}" y2="72" stroke="{PINK}" stroke-opacity="0.25"/>'
    s += neon_text(LX, 47, "Louise Bury", 26)
    c, w = chip(420, 21, "← Bibliothèque", INK, 13)
    s += c
    x = 580
    for lbl, col, on in [("Connect", PINK, True), ("Indice de prix", SOLEIL, False), ("Benchmarks", BLEU, False),
                         ("Checkout Picard", VNEON, False), ("Expériences", ORANGE, False), ("Formations", VIOLET, False), ("Contact", INK, False)]:
        s += f'<circle cx="{x}" cy="36" r="5" fill="{col}" fill-opacity="{1 if on else 0.5}"/>'
        s += t(x + 10, 40, lbl, 12, weight=800 if on else 600, op=1 if on else 0.55)
        x += 22 + int(len(lbl) * 7.0)
    c, w = chip(1296, 21, "Son coupé", INK, 12)
    s += c
    return s + "</g>"


def sous_nav(active=0):
    """Sommaire des sections du projet : fixe, la section en cours s'allume."""
    s = '<g id="sommaire-sections">'
    s += f'<rect x="{CX-24}" y="84" width="{CW+48}" height="44" rx="22" fill="{SURF}" fill-opacity="0.85" stroke="{INK}" stroke-opacity="0.12"/>'
    x = CX + 4
    for i, (lbl, _) in enumerate(SECTIONS):
        on = i == active
        w = int(len(lbl) * 8.6) + 32
        if on:
            s += f'<rect x="{x}" y="90" width="{w}" height="32" rx="16" fill="{PINK}" fill-opacity="0.18" stroke="{PINK}" stroke-opacity="0.8"/>'
        s += t(x + w / 2, 111, lbl, 14.5, weight=800 if on else 600, op=1 if on else 0.6, anchor="middle")
        x += w + 10
    return s + "</g>"


def note(x, y, lines, w=480, id=None):
    """Annotation de maquette (pas du contenu du site)."""
    h = 36 + len(lines) * 21
    s = f'<g class="annotation"{f" id={chr(34)}{id}{chr(34)}" if id else ""}>'
    s += f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="10" fill="{LAVANDE}" fill-opacity="0.06" stroke="{LAVANDE}" stroke-opacity="0.7" stroke-dasharray="5 4"/>'
    s += t(x + 16, y + 24, "✎ NOTE DE MAQUETTE", 11, weight=800, fill=LAVANDE, ls=2)
    for i, l in enumerate(lines):
        s += t(x + 16, y + 46 + i * 21, l, 13.5, fill=LAVANDE, op=0.95)
    return s + "</g>"


def entete_section(y, titre, id):
    s = f'<g id="titre-{id}">'
    s += f'<line x1="{CX}" y1="{y}" x2="{CX+CW}" y2="{y}" stroke="url(#gNom)" stroke-width="2" stroke-opacity="0.6"/>'
    s += neon_text(CX, y + 72, titre, 48)
    return s + "</g>", y + 116


def wireframe(x, y, w, h, label, kind):
    """Emplacement réservé à une future animation de wireframe."""
    s = f'<g class="emplacement-wireframe" id="wf-{kind}">'
    s += f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="14" fill="{BG}" fill-opacity="0.6" stroke="{BLEU}" stroke-opacity="0.8" stroke-width="1.5" stroke-dasharray="7 6"/>'
    # fenêtre de navigateur schématique
    ix, iy, iw, ih = x + 20, y + 20, w - 40, h - 70
    s += f'<rect x="{ix}" y="{iy}" width="{iw}" height="{ih}" rx="8" fill="{SURF}" stroke="{INK}" stroke-opacity="0.18"/>'
    s += "".join(f'<circle cx="{ix+14+i*12}" cy="{iy+12}" r="3" fill="{INK}" fill-opacity="0.25"/>' for i in range(3))
    g = f'fill="{INK}" fill-opacity="0.13"'
    if kind == "chargeurs":   # formulaire court
        for i in range(3):
            s += f'<rect x="{ix+18}" y="{iy+34+i*34}" width="{iw*0.55:.0f}" height="20" rx="4" {g}/>'
        s += f'<rect x="{ix+18}" y="{iy+138}" width="90" height="22" rx="11" fill="{PINK}" fill-opacity="0.6"/>'
        s += f'<rect x="{ix+iw*0.65:.0f}" y="{iy+34}" width="{iw*0.3:.0f}" height="124" rx="6" {g}/>'
    elif kind == "transporteurs":  # recherche + liste de lots
        s += f'<rect x="{ix+18}" y="{iy+30}" width="{iw-36}" height="22" rx="11" {g}/>'
        for i in range(3):
            yy = iy + 64 + i * 32
            s += f'<rect x="{ix+18}" y="{yy}" width="{iw-36}" height="24" rx="5" {g}/>'
            s += f'<rect x="{ix+iw-92}" y="{yy+5}" width="56" height="14" rx="7" fill="{BLEU}" fill-opacity="0.6"/>'
    else:  # back office : tableau
        s += f'<rect x="{ix+18}" y="{iy+30}" width="70" height="18" rx="9" fill="{VIOLET}" fill-opacity="0.6"/><rect x="{ix+96}" y="{iy+30}" width="70" height="18" rx="9" {g}/>'
        for i in range(4):
            yy = iy + 60 + i * 24
            s += "".join(f'<rect x="{ix+18+j*(iw-36)/4:.0f}" y="{yy}" width="{(iw-36)/4-8:.0f}" height="14" rx="3" {g}/>' for j in range(4))
    s += f'<circle cx="{x+30}" cy="{y+h-26}" r="11" fill="{BLEU}" fill-opacity="0.25" stroke="{BLEU}"/><path d="M{x+27} {y+h-31} l8 5 l-8 5 z" fill="{BLEU}"/>'
    s += t(x + 50, y + h - 21, label, 12.5, weight=700, fill=BLEU)
    return s + "</g>"


# ------------------------------------------------------------------ emplacements des animations
SLOTS = []                 # (fichier, x, y, largeur, hauteur) remplis à chaque appel de page()
CTRL = 44                  # hauteur de la barre Pause / progression sous l'animation


def emplacement(fichier, x, y, w, label):
    """Cadre réservé à une animation (iframe dans la version HTML). Renvoie la hauteur."""
    h = round(w * 692 / 1200 + CTRL)
    SLOTS.append((fichier, x, y, w, h))
    s = f'<g class="emplacement-animation" id="anim-{fichier}">'
    s += f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="12" fill="{BG}" stroke="{BLEU}" stroke-opacity="0.7" stroke-width="1.5" stroke-dasharray="7 6"/>'
    s += f'<rect x="{x+12}" y="{y+12}" width="{w-24}" height="{h-CTRL-12}" rx="8" fill="#F4F5F7" fill-opacity="0.9"/>'
    s += f'<circle cx="{x+w/2}" cy="{y+(h-CTRL)/2}" r="26" fill="{BLEU}" fill-opacity="0.25" stroke="{BLEU}"/><path d="M{x+w/2-8} {y+(h-CTRL)/2-12} l20 12 l-20 12 z" fill="{BLEU}"/>'
    s += t(x + w / 2, y + (h - CTRL) / 2 + 50, label, 14, weight=700, fill=BLEU, anchor="middle")
    return s + "</g>", h


# ------------------------------------------------------------------ page
def page():
    SLOTS.clear()
    b = ""
    # ---------- EN-TÊTE DU PROJET
    y = 186
    b += '<g id="entete-projet">'
    b += t(CX, y, "ÉTUDE DE CAS · TRANSPORT B2B", 14, weight=800, fill=SOLEIL, ls=4)
    b += neon_text(CX, y + 66, "Lancement du produit", 50)
    b += neon_text(CX, y + 128, "Connect", 50)
    s, y = para(CX, y + 186, "Une première marketplace de transport n'avait pas trouvé son marché. "
                "J'ai été recrutée pour la relancer en deux mois, en plus simple et plus proche du terrain, "
                "avec le back office qui va avec.", 21, CW, lh=33, op=0.92)
    b += s
    # fiche d'identité
    y += 40
    rows = [("ENTREPRISE", "Upply · start-up supply chain"), ("MON RÔLE", "Product Manager"),
            ("MARCHÉ", "Transport routier · B2B"), ("ÉQUIPE PRODUIT", "1 CPO · 2 UX designers · 1 PM"),
            ("UTILISATEURS", "Chargeurs · transporteurs · sales"), ("DURÉE", "2 mois de build + 2 mois de bêta")]
    b += card(CX, y, CW, 210, fop=0.75, id="fiche-identite")
    for i, (k, v) in enumerate(rows):
        cx = CX + 28 + (i % 2) * 370; cy = y + 46 + (i // 2) * 60
        b += t(cx, cy, k, 11.5, weight=800, fill=PINK, ls=2.5, op=0.9)
        b += t(cx, cy + 24, v, 16.5, weight=600)
    y += 240
    # chiffres clés
    tiles = [("2", "produits lancés", "en parallèle"), ("2 mois", "délai fixé par", "les investisseurs : tenu"),
             ("20", "ordres d'affrètement", "objectif atteint"), ("< 3 min", "pour publier", "un lot (objectif)")]
    tw = (CW - 3 * 16) / 4
    b += '<g id="chiffres-cles">'
    for i, (n, l1, l2) in enumerate(tiles):
        tx = CX + i * (tw + 16)
        b += card(tx, y, tw, 136, stroke=PINK, sop=0.3, fill="url(#gCarte)", fop=1)
        b += t(tx + 20, y + 56, n, 38, fam=NEON, fill="url(#gNom)")
        b += t(tx + 20, y + 88, l1, 14, op=0.8) + t(tx + 20, y + 108, l2, 14, op=0.8)
    b += "</g>"
    y += 136 + 50
    b += t(CX, y, "Défiler ↓ pour découvrir le projet", 13, op=0.45)
    b += "</g>"

    # annotations en face de l'en-tête (colonne gauche, sous le panneau fixe)
    notes = ""

    # ---------- CONTEXTE
    y += 90
    y_ctx = y
    s, y = entete_section(y, "Contexte", "contexte"); b += f'<g id="contexte">{s}'
    b += t(CX, y, "L'entreprise", 22, weight=800); y += 34
    s, y = para(CX, y, "Upply est une start-up qui met la tech au service de la supply chain. À l'époque, elle porte deux produits :", 16.5, CW, op=0.85)
    b += s; y += 30
    pw = (CW - 20) / 2
    prods = [("Smart", BLEU, "Déjà commercialisé", "Comparer ses prix de transport grâce à plus de 2 milliards de données. Il commence à faire ses preuves."),
             ("Marketplace → Connect", PINK, "Le projet", "Mettre en relation chargeurs (un fret à transporter) et transporteurs (un camion disponible) pour conclure un ordre de transport.")]
    for i, (nom, col, tag, desc) in enumerate(prods):
        px = CX + i * (pw + 20)
        b += card(px, y, pw, 190, stroke=col, sop=0.5, fop=0.8)
        b += f'<rect x="{px}" y="{y}" width="{pw}" height="5" rx="2.5" fill="{col}"/>'
        b += t(px + 24, y + 44, nom, 21, fam=NEON, fill=col)
        c, _ = chip(px + 24, y + 60, tag, col, 11.5, 0.12, 24); b += c
        s, _ = para(px + 24, y + 116, desc, 15, pw - 48, op=0.8); b += s
    y += 190 + 60

    b += t(CX, y, "Le point de départ : un premier lancement manqué", 22, weight=800); y += 34
    s, y = para(CX, y, "Construite et commercialisée en 2020, la Marketplace est un échec commercial : "
                "le produit ne répond pas aux attentes du terrain. Quatre raisons ressortent.", 16.5, CW, op=0.85)
    b += s; y += 30
    causes = [("formulaire", "Un formulaire trop long", "Publier un besoin de transport prenait trop de temps."),
              ("telephone", "Des habitudes ancrées", "Carnet d'adresses et négociation au téléphone : difficile à changer."),
              ("chrono", "Des utilisateurs peu digitalisés", "Leur quotidien exige d'aller vite. L'outil les ralentissait."),
              ("match", "Un matching trop rigide", "Il attendait que des critères précis coïncident, alors que le terrain négocie au jour le jour.")]
    cw2 = (CW - 20) / 2
    for i, (ic, ti, de) in enumerate(causes):
        px = CX + (i % 2) * (cw2 + 20); py = y + (i // 2) * 160
        b += card(px, py, cw2, 144, stroke=ORANGE, sop=0.35, fop=0.75)
        b += icone(ic, px + 40, py + 42, ORANGE, 20)
        b += t(px + 76, py + 48, ti, 17, weight=800)
        s, _ = para(px + 24, py + 86, de, 14.5, cw2 - 48, op=0.75); b += s
    y += 320 + 18
    b += t(CX, y, "Résultat : le produit ne se vend pas, et les équipes s'essoufflent.", 16.5, italic=True, fill=ORANGE, op=0.95)
    y += 50
    b += t(CX, y, "L'ANCIEN PARCOURS, RECONSTITUÉ", 12, weight=800, fill=ORANGE, ls=3); y += 18
    o, h = emplacement("wireframe-avant", CX, y, CW, "Animation : l'ancienne Marketplace"); b += o
    y += h + 70

    b += t(CX, y, "Ma mission", 22, weight=800); y += 26
    miss = [("1", "Relancer la marketplace", "beaucoup plus simple, facile à prendre en main"),
            ("2", "Refondre le back office", "des sales et du customer care, pour suivre l'activité"),
            ("3", "Tenir le délai", "fixé par les investisseurs")]
    mw = (CW - 2 * 16) / 3
    for i, (n, ti, de) in enumerate(miss):
        px = CX + i * (mw + 16)
        b += card(px, y, mw, 180, stroke=PINK, sop=0.3, fill="url(#gCarte)", fop=1)
        b += t(px + 22, y + 52, n, 36, fam=NEON, fill="url(#gNom)")
        s, yy = para(px + 22, y + 86, ti, 16, mw - 44, weight=800); b += s
        s, _ = para(px + 22, yy + 22, de, 13.5, mw - 44, op=0.72); b += s
    y += 180 + 24
    c, _ = chip(CX, y, "⚠ Contexte : réorganisation de l'équipe produit et de l'entreprise, tout est à construire", SOLEIL, 13, 0.08, 32)
    b += c + "</g>"
    y += 32 + 120

    # ---------- PROBLÉMATIQUE
    y_prob = y
    s, y = entete_section(y, "Problématique", "problematique"); b += f'<g id="problematique">{s}'
    qh = 190
    b += card(CX, y, CW, qh, stroke=PINK, sop=0.9, fill=SURF2, fop=0.95, r=20, glow=True, id="carte-question")
    b += t(CX + 34, y + 86, "“", 72, fam=NEON, fill=PINK, op=0.8)
    s, yy = para(CX + 80, y + 62, "Comment faire adopter une marketplace à des professionnels du transport peu digitalisés, "
                 "qui doivent négocier vite et ont l'habitude du téléphone ?", 25, CW - 120, lh=36, weight=700)
    b += s
    y += qh + 40
    s, y = bullets(CX, y, ["Comment s'adapter à leurs contraintes quotidiennes, pour qu'ils négocient une offre de transport plus vite qu'au téléphone ?",
                           "Comment donner aux équipes internes un back office qui leur permette de suivre ce qui se passe sur la plateforme ?"],
                   CW, 16.5, PINK, 14)
    b += s; y += 40
    # contraintes + objectifs
    colw = (CW - 24) / 2
    b += card(CX, y, colw, 330, fop=0.75)
    b += t(CX + 26, y + 42, "LES CONTRAINTES", 12, weight=800, fill=SOLEIL, ls=3)
    cons = [("calendrier", "Délai", "2 mois, fixés par les investisseurs"), ("equipe", "Moyens", "Équipes produit et dev réduites"),
            ("chantier", "Organisation", "Équipe produit en réorganisation"), ("deux", "Périmètre", "2 produits en parallèle")]
    for i, (ic, k, v) in enumerate(cons):
        yy = y + 90 + i * 62
        b += icone(ic, CX + 46, yy, SOLEIL, 19)
        b += t(CX + 80, yy - 4, k, 16, weight=800) + t(CX + 80, yy + 18, v, 14, op=0.72)
    ox = CX + colw + 24
    b += card(ox, y, colw, 330, stroke=PINK, sop=0.45, fill="url(#gCarte)", fop=1)
    b += t(ox + 26, y + 42, "COMMENT ON MESURE LE SUCCÈS", 12, weight=800, fill=PINK, ls=3)
    s, yy = para(ox + 26, y + 76, "Bêta de 2 mois avec 4 entreprises choisies par les sales (2 chargeurs, 2 transporteurs).", 14.5, colw - 52, op=0.8)
    b += s
    for i, (n, l) in enumerate([("12", "utilisateurs actifs"), ("20", "ordres d'affrètement")]):
        yy2 = y + 160 + i * 80
        b += t(ox + 26, yy2 + 30, n, 46, fam=NEON, fill="url(#gNom)")
        b += t(ox + 100, yy2 + 12, "OBJECTIF À 2 MOIS", 10.5, weight=800, op=0.5, ls=2)
        b += t(ox + 100, yy2 + 33, l, 15, weight=700)
        if i == 0: b += t(ox + 100, yy2 + 52, "soit 3 par entreprise", 12.5, op=0.6)
    b += "</g>"
    y += 330 + 120

    # ---------- RÉALISATIONS
    y_real = y
    s, y = entete_section(y, "Réalisations", "realisations"); b += f'<g id="realisations">{s}'
    rail_x = CX + 14; rail_top = y
    IX = CX + 52; IW = CW - 52

    def etape(y, n, titre, sous):
        o = f'<circle cx="{rail_x}" cy="{y-8}" r="15" fill="{BG}" stroke="{PINK}" stroke-width="2"/>'
        o += t(rail_x, y - 3, n, 14, weight=800, fill=PINK, anchor="middle")
        o += t(IX, y, titre, 24, weight=800) + t(IX, y + 28, sous, 15, op=0.6, italic=True)
        return o, y + 64

    # étape 1
    s, y = etape(y, "1", "Comprendre", "Discovery : partir du terrain"); b += s
    dw = (IW - 20) / 2
    disc_ = [("Connect", PINK, "« Une plateforme simple et facile à utiliser »",
              ["Ateliers avec les sales et le customer care pour comprendre le monde du transport",
               "Ateliers de conception avec l'équipe produit, les métiers, puis les développeurs",
               "Benchmark concurrentiel",
               "Parcours prototypés et validés avec les bêta-testeurs"]),
             ("Back office", VIOLET, "« Suivre en temps réel ce qui se passe sur Connect »",
              ["Ateliers avec les sales et le customer care pour comprendre leurs besoins",
               "Ateliers de conception avec l'équipe produit, puis les développeurs"])]
    hmax = 0
    parts = []
    for i, (nom, col, motto, items) in enumerate(disc_):
        px = IX + i * (dw + 20)
        o = t(px + 24, y + 40, nom.upper(), 12.5, weight=800, fill=col, ls=3)
        so, yy = para(px + 24, y + 72, motto, 15.5, dw - 48, italic=True, weight=700, fill=col)
        o += so
        so, yy = bullets(px + 24, yy + 40, items, dw - 48, 14.5, col, 6)
        o += so
        parts.append((px, col, o)); hmax = max(hmax, yy - y)
    for px, col, o in parts:
        b += card(px, y, dw, hmax, stroke=col, sop=0.35, fop=0.75) + o
    y += hmax + 70

    # étape 2
    s, y = etape(y, "2", "Découper en MVP", "2 mois, une petite équipe : aller à l'essentiel"); b += s
    b += card(IX, y, IW, 250, stroke=PINK, sop=0.35, fop=0.75, id="mvp-connect")
    b += t(IX + 24, y + 38, "MVP CONNECT", 12.5, weight=800, fill=PINK, ls=3)
    b += t(IX + 24, y + 66, "Un ordre de transport doit pouvoir se conclure de bout en bout sur la plateforme.", 15.5, weight=700)
    steps = [("Chargeur", "publie un lot"), ("Transporteur", "envoie une offre"), ("Plateforme", "génère l'ordre d'affrètement")]
    sw = (IW - 48 - 2 * 46) / 3
    for i, (qui, quoi) in enumerate(steps):
        sx = IX + 24 + i * (sw + 46); sy = y + 100
        last = i == 2
        b += f'<rect x="{sx}" y="{sy}" width="{sw}" height="110" rx="14" fill="{PINK if last else INK}" fill-opacity="{0.16 if last else 0.04}" stroke="{PINK}" stroke-opacity="{0.9 if last else 0.4}" stroke-width="1.5"/>'
        b += t(sx + 18, sy + 32, f"0{i+1}", 13, weight=800, fill=PINK)
        b += t(sx + 18, sy + 60, qui, 17, weight=800)
        s, _ = para(sx + 18, sy + 84, quoi, 14, sw - 36, op=0.78); b += s
        if not last:
            ax = sx + sw + 8
            b += f'<path d="M{ax} {sy+55} H{ax+28} M{ax+20} {sy+47} L{ax+29} {sy+55} L{ax+20} {sy+63}" stroke="{PINK}" stroke-width="2.5" fill="none" stroke-linecap="round" stroke-linejoin="round"/>'
    y += 250 + 20
    b += card(IX, y, IW, 120, stroke=VIOLET, sop=0.35, fop=0.75, id="mvp-bo")
    b += t(IX + 24, y + 38, "MVP BACK OFFICE", 12.5, weight=800, fill=VIOLET, ls=3)
    b += t(IX + 24, y + 66, "Les équipes internes consultent toute l'activité :", 15.5, weight=700)
    cx_ = IX + 24
    for lbl in ["Lots publiés", "Offres envoyées", "Ordres d'affrètement"]:
        c, w = chip(cx_, y + 80, lbl, VIOLET, 13, 0.15, 28); b += c; cx_ += w + 12
    y += 120 + 26
    b += t(IX, y, "→ Roadmap et priorisation des epics construites à partir de ce découpage.", 15, op=0.75, italic=True)
    y += 76

    # étape 3
    y_livre = y
    s, y = etape(y, "3", "Ce qu'on a livré", "Des choix produit au service de la rapidité"); b += s
    livres = [("chargeurs", PINK, "Chargeurs", "Publier un lot en moins de 3 minutes",
               ["Formulaire réduit : le minimum de critères, on en ajoutera si besoin",
                "Adresses complétées automatiquement (Google)",
                "Un lot récurrent se duplique en un clic",
                "Liste des lots épurée, statuts clairs",
                "E-mail dès qu'un transporteur fait une offre"], "Animation : parcours chargeur"),
              ("transporteurs", BLEU, "Transporteurs", "Trouver le bon lot et négocier en direct",
               ["Recherche simple : destination et marchandise en première vue",
                "Offre courte et suivi simplifié, pour négocier en direct",
                "Recherches enregistrées : e-mail quand un nouveau lot correspond"], "Animation : parcours transporteur"),
              ("back-office", VIOLET, "Équipes internes", "Un back office repensé",
               ["Une vue chargeurs et une vue transporteurs",
                "Le détail de chaque lot et de chaque offre (MVP)"], "Animation : suivre l'activité")]
    for kind, col, qui, titre, items, anim in livres:
        o = t(IX + 24, y + 40, qui.upper(), 12.5, weight=800, fill=col, ls=3)
        so, yy = para(IX + 24, y + 74, titre, 22, IW - 48, fam=NEON, fill=col); o += so
        half = (len(items) + 1) // 2; colw = (IW - 48 - 24) / 2
        s1, y1 = bullets(IX + 24, yy + 40, items[:half], colw, 14.5, col, 4)
        s2, y2 = bullets(IX + 24 + colw + 24, yy + 40, items[half:], colw, 14.5, col, 4)
        o += s1 + s2; yy = max(y1, y2)
        if kind != "back-office":
            so, hh = emplacement(f"wireframe-{kind.rstrip('s')}", IX + 24, yy - 4, IW - 48, anim); o += so
            yy += hh + 20
        h = yy - y + 4
        b += card(IX, y, IW, h, stroke=col, sop=0.35, fop=0.75, id=f"livre-{kind}") + o
        y += h + 22
    y += 54

    # étape 4
    s, y = etape(y, "4", "Lancer et apprendre", "Une bêta suivie pendant 2 mois"); b += s
    loop = [("Lancement", "auprès des 4 entreprises bêta"), ("Entretiens", "pour recueillir les retours"),
            ("Indicateurs", "ordres d'affrètement, utilisateurs actifs"), ("Améliorations", "à partir des retours")]
    lw = (IW - 3 * 30) / 4
    for i, (k, v) in enumerate(loop):
        lx = IX + i * (lw + 30)
        b += card(lx, y, lw, 140, stroke=PINK, sop=0.35, fill="url(#gCarte)", fop=1)
        b += t(lx + 18, y + 40, k, 16.5, weight=800)
        s, _ = para(lx + 18, y + 66, v, 13.5, lw - 36, op=0.75); b += s
        if i < 3:
            ax = lx + lw + 4
            b += f'<path d="M{ax} {y+60} H{ax+22} M{ax+15} {y+53} L{ax+22} {y+60} L{ax+15} {y+67}" stroke="{PINK}" stroke-width="2" fill="none" stroke-linecap="round"/>'
    b += f'<path d="M{IX+IW-lw/2} {y+144} V{y+170} H{IX+lw/2} V{y+148} M{IX+lw/2-7} {y+154} L{IX+lw/2} {y+146} L{IX+lw/2+7} {y+154}" stroke="{PINK}" stroke-opacity="0.6" stroke-width="1.8" fill="none" stroke-dasharray="5 5" stroke-linecap="round"/>'
    b += t(IX + IW / 2, y + 192, "on itère", 12.5, op=0.55, anchor="middle", italic=True)
    y += 210
    b += f'<line x1="{rail_x}" y1="{rail_top+7}" x2="{rail_x}" y2="{y-60}" stroke="{PINK}" stroke-opacity="0.3" stroke-width="2" stroke-dasharray="3 6"/>'
    b += "</g>"
    y += 70

    # ---------- RÉSULTATS
    y_res = y
    s, y = entete_section(y, "Résultats", "resultats"); b += f'<g id="resultats">{s}'
    rw = (CW - 20) / 2
    res = [("Délai tenu", "Connect et le back office lancés dans les 2 mois attendus par les investisseurs."),
           ("20 ordres d'affrètement", "générés pendant la bêta : l'objectif est atteint.")]
    for i, (k, v) in enumerate(res):
        rx = CX + i * (rw + 20)
        b += card(rx, y, rw, 170, stroke=PINK, sop=0.8, fill=SURF2, fop=0.95, glow=True)
        b += icone("check", rx + 46, y + 50, PINK, 22)
        b += t(rx + 82, y + 58, k, 22, fam=NEON, fill=PINK)
        s, _ = para(rx + 28, y + 106, v, 15.5, rw - 56, op=0.85); b += s
    y += 170 + 24
    # indicateurs : objectif vs réel
    b += card(CX, y, CW, 200, fop=0.8, id="indicateurs-reels")
    b += t(CX + 28, y + 42, "INDICATEURS À 2 MOIS", 12, weight=800, fill=SOLEIL, ls=3)
    rows = [("Ordres d'affrètement", 20, 20, "20 / 20 · objectif atteint", PINK),
            ("Utilisateurs actifs", 4, 12, "4 / 12 · en dessous de l'objectif", ORANGE)]
    for i, (lbl, reel, obj, txt, col) in enumerate(rows):
        yy = y + 96 + i * 62
        b += t(CX + 28, yy, lbl, 15.5, weight=700)
        bx, bw_ = CX + 230, 240
        b += f'<rect x="{bx}" y="{yy-12}" width="{bw_}" height="12" rx="6" fill="{INK}" fill-opacity="0.08"/>'
        fill = "url(#gNom)" if col == PINK else col
        b += f'<rect x="{bx}" y="{yy-12}" width="{bw_*reel/obj:.0f}" height="12" rx="6" fill="{fill}"/>'
        b += f'<line x1="{bx+bw_}" y1="{yy-20}" x2="{bx+bw_}" y2="{yy+6}" stroke="{INK}" stroke-opacity="0.6" stroke-width="2"/>'
        b += t(bx + bw_ + 16, yy, txt, 14, weight=700, fill=col)
    y += 200 + 24
    # verbatim
    b += card(CX, y, CW, 200, stroke=PINK, sop=0.45, fill="url(#gCarte)", fop=1, id="verbatim")
    b += t(CX + 28, y + 42, "CE QUE DISAIENT LES BÊTA-TESTEURS", 12, weight=800, fill=PINK, ls=3)
    b += t(CX + 28, y + 118, "« Simple, intuitif et facile. »", 46, fam=NEON, fill="url(#gNom)")
    b += t(CX + 28, y + 164, "Les mots qui revenaient le plus souvent dans leurs retours.", 15, op=0.7, italic=True)
    y += 200 + 24
    # ce que j'en retiens
    o, yy = para(CX + 28, y + 80, "Le produit tenait sa promesse : les utilisateurs engagés publiaient des lots et faisaient des offres, "
                 "et l'objectif d'ordres d'affrètement a été atteint.", 16, CW - 56, op=0.88)
    o2, yy = para(CX + 28, yy + 40, "Le vrai défi était ailleurs : l'adoption. Il fallait convaincre davantage d'utilisateurs "
                  "dans chaque entreprise. Nous avons donc concentré la discovery suivante sur cette question : donner envie "
                  "d'adopter l'outil, au sein des entreprises clientes comme auprès de nouvelles entreprises.", 16, CW - 56, op=0.88)
    hh = yy - y + 36
    b += card(CX, y, CW, hh, stroke=LAVANDE, sop=0.6, fop=0.85, id="ce-que-j-en-retiens")
    b += t(CX + 28, y + 44, "CE QUE J'EN RETIENS", 12, weight=800, fill=LAVANDE, ls=3) + o + o2
    b += "</g>"
    y += hh + 110

    # ---------- PIED DE PAGE
    b += '<g id="pied-projet">'
    c, w = chip(CX, y + 44, "← Retour à la bibliothèque", INK, 15, 0.0, 44); b += c
    nx = CX + CW - 360
    b += card(nx, y, 360, 130, stroke=SOLEIL, sop=0.6, fop=0.8, id="projet-suivant")
    b += f'<circle cx="{nx+64}" cy="{y+65}" r="42" fill="#0E0E16" stroke="#33334A"/><circle cx="{nx+64}" cy="{y+65}" r="30" fill="none" stroke="#33334A"/><circle cx="{nx+64}" cy="{y+65}" r="15" fill="{SOLEIL}"/>'
    b += t(nx + 124, y + 52, "PROJET SUIVANT →", 11.5, weight=800, fill=SOLEIL, ls=2.5)
    b += t(nx + 124, y + 80, "Refonte de la page", 17, weight=800) + t(nx + 124, y + 102, "indice de prix", 17, weight=800)
    b += "</g>"
    H = y + 220

    marks = {"ctx": y_ctx, "prob": y_prob, "real": y_real, "livre": y_livre, "res": y_res}
    return b, H, marks


def etoiles(w, h, n, seed=7):
    import random
    rnd = random.Random(seed)
    return '<g id="etoiles">' + "".join(
        f'<circle cx="{rnd.random()*w:.0f}" cy="{rnd.random()*h:.0f}" r="{0.5+rnd.random():.1f}" fill="{INK}" fill-opacity="{0.1+rnd.random()*0.3:.2f}"/>'
        for _ in range(n)) + "</g>"


def page_complete():
    """Toute la page d'un coup (référence du contenu). Le vinyle est dessiné en haut, à sa place à l'écran."""
    b, H, m = page()
    notes = note(LX, 960, ["Le vinyle est fixe en arrière-plan : seul le contenu",
                           "défile. Il tourne en continu (et plus vite au scroll)."], id="note-vinyle")
    notes += note(LX, 1080, ["Sommaire des sections fixe sous la barre du haut :",
                             "la section en cours s'allume, un clic y mène."], id="note-sommaire")
    notes += note(LX, 1200, ["En-tête : accroche + fiche d'identité + chiffres clés.",
                             "Le recruteur a l'essentiel en moins de 30 s."], id="note-entete")
    notes += note(LX, m["prob"] + 120, ["Au scroll, la carte question s'allume (néon rose).",
                                        "Les cartes Contraintes / Succès apparaissent ensuite."], id="note-problematique")
    notes += note(LX, SLOTS[0][2], ["Animation de l'ancienne Marketplace (reconstitution) :",
                                       "elle montre le « avant » juste après les 4 raisons",
                                       "de l'échec. Lecture en boucle, bouton Pause."], id="note-avant")
    notes += note(LX, m["livre"], ["Une animation par parcours (chargeur, transporteur).",
                                   "Back office : pas de wireframe, le bloc reste en texte.",
                                   "Version HTML : les animations tournent dans la page."], id="note-wireframes")
    notes += note(LX, m["res"] + 120, ["Barres : objectif vs réel. Le verbatim et",
                                       "« Ce que j'en retiens » clôturent l'histoire."], id="note-resultats")
    body = (f'<rect width="{W}" height="{H}" fill="url(#gFond)"/>' + etoiles(W, H, 260)
            + vinyle_fond(0) + f'<g id="contenu">{b}</g>' + f'<g id="annotations">{notes}</g>'
            + sous_nav(0) + barre_haut())
    return f'<svg width="{W}" height="{H}" viewBox="0 0 {W} {H}" xmlns="http://www.w3.org/2000/svg">{DEFS}{body}</svg>'


def ecrans():
    """Écrans successifs (1440 x 900) : le vinyle et les barres restent fixes, le contenu défile."""
    b, H, m = page()
    vues = [(0, 0, 0, "Arrivée sur le projet : accroche, fiche d'identité, chiffres clés"),
            (m["ctx"] - 140, 0, 50, "Contexte : le vinyle a tourné, il n'a pas bougé"),
            (m["prob"] - 140, 1, 100, "Problématique : la carte question s'allume"),
            (m["real"] - 140, 2, 150, "Réalisations : frise comprendre → découper → livrer → apprendre"),
            (m["livre"] - 140, 2, 200, "Ce qu'on a livré : emplacements des animations de wireframes"),
            (m["res"] - 140, 3, 250, "Résultats : objectifs vs réel, verbatim, ce que j'en retiens")]
    VH, CAP, GAP = 900, 64, 48
    total = len(vues) * (CAP + VH + GAP)
    out = f'<rect width="{W}" height="{total}" fill="#06060A"/>'
    for i, (off, active, angle, legende) in enumerate(vues):
        y0 = i * (CAP + VH + GAP)
        out += t(LX, y0 + 40, f"Écran {i+1}", 20, weight=800, fill=PINK)
        out += t(LX + 100, y0 + 40, legende, 18, op=0.8)
        out += (f'<svg x="0" y="{y0+CAP}" width="{W}" height="{VH}" viewBox="0 0 {W} {VH}">'
                f'<rect width="{W}" height="{VH}" fill="url(#gFond)"/>' + etoiles(W, VH, 90, seed=3)
                + vinyle_fond(angle) + f'<g transform="translate(0 {-off})">{b}</g>'
                + sous_nav(active) + barre_haut() + '</svg>')
        out += f'<rect x="0.5" y="{y0+CAP+0.5}" width="{W-1}" height="{VH-1}" fill="none" stroke="{INK}" stroke-opacity="0.2"/>'
    return f'<svg width="{W}" height="{total}" viewBox="0 0 {W} {total}" xmlns="http://www.w3.org/2000/svg">{DEFS}{out}</svg>'


def page_html(dossier_wf):
    """Maquette HTML : la page SVG + les animations de wireframes dans leurs emplacements."""
    import re
    svg = page_complete()
    H = int(re.search(r'height="(\d+)"', svg).group(1))
    frames = ""
    for fichier, x, y, w, h in SLOTS:
        src = open(f"{dossier_wf}/{fichier}.html", encoding="utf-8").read()
        src = src.replace("padding:24px 16px", "padding:0").replace("margin-top:10px", "margin-top:6px")
        frames += (f'<iframe title="{fichier}" style="position:absolute;left:{x}px;top:{y}px;width:{w}px;height:{h}px;'
                   f'border:0;border-radius:12px;background:#0B0B12" srcdoc="{escape(src, quote=True)}"></iframe>')
    return f"""<!DOCTYPE html>
<html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Maquette page projet : Lancement du produit Connect</title>
<style>html,body{{margin:0;background:#0B0B12;overflow-x:hidden}}#page{{position:relative;width:{W}px;height:{H}px;transform-origin:0 0}}#page>svg{{display:block}}</style>
</head><body><div id="page">{svg}{frames}</div>
<script>
function ajuster(){{ const s = Math.min(1, window.innerWidth / {W}); const p = document.getElementById('page');
  p.style.transform = 'scale(' + s + ')'; document.body.style.height = ({H} * s) + 'px'; }}
window.addEventListener('resize', ajuster); ajuster();
</script></body></html>"""


if __name__ == "__main__":
    with open(sys.argv[1], "w", encoding="utf-8") as f:
        f.write(page_complete())
    if len(sys.argv) > 3:
        with open(sys.argv[3], "w", encoding="utf-8") as f:
            f.write(page_html(sys.argv[4]))
    with open(sys.argv[2], "w", encoding="utf-8") as f:
        f.write(ecrans())
    print("ok", sys.argv[1:])
